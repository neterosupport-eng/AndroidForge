import com.google.gms.googleservices.GoogleServicesPlugin.MissingGoogleServicesStrategy

plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
  alias(libs.plugins.google.devtools.ksp)
  alias(libs.plugins.google.services)
}

android {
  namespace = "com.example"
  compileSdk = 36

  defaultConfig {
    applicationId = "com.aistudio.netero.network.xpkq"
    minSdk = 24
    targetSdk = 36
    versionCode = 60
    versionName = "1.0.60"

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  signingConfigs {
    create("release") {
      val keystorePath = System.getenv("NETERO_RELEASE_KEYSTORE") ?: ""
      val storePasswordEnv = System.getenv("NETERO_RELEASE_STORE_PASSWORD") ?: ""
      val keyAliasEnv = System.getenv("NETERO_RELEASE_KEY_ALIAS") ?: "netero_key"
      val keyPasswordEnv = System.getenv("NETERO_RELEASE_KEY_PASSWORD") ?: ""
      if (keystorePath.isNotBlank() && file(keystorePath).exists() && storePasswordEnv.isNotBlank() && keyPasswordEnv.isNotBlank()) {
        storeFile = file(keystorePath)
        storePassword = storePasswordEnv
        keyAlias = keyAliasEnv
        keyPassword = keyPasswordEnv
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = true
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")

      // Only attach the release keystore when all required signing values are supplied.
      // This allows an unsigned release AAB to be built for testing/inspection when
      // the private Play signing keystore is not present. A Play Store upload still
      // requires a properly signed AAB using the project's permanent release key.
      val keystorePath = System.getenv("NETERO_RELEASE_KEYSTORE") ?: ""
      val storePasswordEnv = System.getenv("NETERO_RELEASE_STORE_PASSWORD") ?: ""
      val keyPasswordEnv = System.getenv("NETERO_RELEASE_KEY_PASSWORD") ?: ""
      if (keystorePath.isNotBlank() && file(keystorePath).exists() &&
          storePasswordEnv.isNotBlank() && keyPasswordEnv.isNotBlank()) {
        signingConfig = signingConfigs.getByName("release")
      }
    }
    debug { }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_11
    targetCompatibility = JavaVersion.VERSION_11
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
  lint {
    checkReleaseBuilds = false
    abortOnError = false
  }
}

googleServices { missingGoogleServicesStrategy = MissingGoogleServicesStrategy.WARN }

// Some unused dependencies are commented out below instead of being removed.
// This makes it easy to add them back in the future if needed.
dependencies {
  implementation(platform(libs.androidx.compose.bom))
  
  implementation(platform(libs.firebase.bom))
  implementation("com.google.firebase:firebase-storage")
  implementation("com.google.firebase:firebase-messaging")
  implementation("com.google.firebase:firebase-functions")
  implementation("com.google.code.gson:gson:2.10.1")

  implementation("io.coil-kt:coil-compose:2.5.0")


  implementation(libs.accompanist.permissions)
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.camera.camera2)
  implementation(libs.androidx.camera.core)
  implementation(libs.androidx.camera.lifecycle)
  implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  // implementation(libs.androidx.datastore.preferences)
  implementation(libs.androidx.lifecycle.runtime.compose)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.androidx.lifecycle.viewmodel.compose)
  implementation(libs.androidx.navigation.compose)
  implementation(libs.androidx.room.ktx)
  implementation(libs.androidx.room.runtime)
  // implementation(libs.coil.compose)
  implementation(libs.converter.moshi)
  implementation(libs.firebase.ai)
  // Uncomment to use Firestore:
  implementation(libs.firebase.firestore)

  // Firebase Auth is used only for an internal anonymous backend session.
  // The user-facing login is Netero email OTP; Google/phone sign-in is not used.
  implementation(libs.firebase.auth)
  implementation(libs.zxing.core)
  implementation(libs.play.app.update)
  implementation(libs.play.app.update.ktx)
    implementation("com.google.mlkit:barcode-scanning:17.3.0")
    implementation("com.google.mlkit:text-recognition:16.0.0")
  implementation("com.revenuecat.purchases:purchases:9.0.0")
  implementation(libs.firebase.appcheck.recaptcha)
  implementation(libs.firebase.appcheck.playintegrity)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  implementation("org.jetbrains.kotlinx:kotlinx-coroutines-play-services:1.10.2")
  implementation(libs.logging.interceptor)
  implementation(libs.moshi.kotlin)
  implementation(libs.okhttp)
  implementation("com.google.android.gms:play-services-location:21.2.0")
  implementation(libs.retrofit)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
  "ksp"(libs.androidx.room.compiler)
  // "ksp"(libs.moshi.kotlin.codegen)
}
