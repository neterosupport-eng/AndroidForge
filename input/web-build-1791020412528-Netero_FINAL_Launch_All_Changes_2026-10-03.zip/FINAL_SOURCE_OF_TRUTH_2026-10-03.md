NETERO FINAL SOURCE OF TRUTH — 2026-10-03

Verified in this source package:
- Refresh button removed from the main screens.
- Instagram-style pull-down refresh implemented for Home, Connections, Rooms and Discover.
- Pull-to-refresh calls the relevant refresh/AI refresh callbacks.
- Firestore snapshot listeners are present for chats, connections, notifications, rooms, profile views and live profile sync.
- One-to-one chat sends through the Firebase callable `sendNeteroMessage` and receives through live Firestore snapshot listeners.
- OTP request may use a temporary anonymous session only to authorize the OTP callable.
- Successful OTP verification now returns a Firebase custom token tied to `user_<verified-email>` and the app signs in with that token, replacing the temporary anonymous session with a persistent identity.
- Normal `refreshCloudData()` no longer creates an anonymous Firebase user.
- In-progress profile fields are persisted as a local draft and restored when Profile Setup opens.
- Avatar selection/upload updates the image field without replacing the form's saved name/username values.
- Existing Netero visual theme files were preserved.

Important deployment note:
- The included Firebase Functions must be deployed for the new custom-token OTP flow to be live in Firebase.
- This package has been source-verified; a full Android APK build/device test was not performed in this environment.
