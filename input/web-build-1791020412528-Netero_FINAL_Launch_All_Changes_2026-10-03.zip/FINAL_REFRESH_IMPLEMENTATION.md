# Netero Final Refresh Implementation — 2026-10-03

- Refresh button: removed.
- Pull-down refresh: implemented on Home, Connections, Rooms, and Discover.
- Pull gesture only accumulates unconsumed downward scroll at the top of the scrollable content, then triggers refresh on release after the threshold.
- Home, Connections, and Rooms trigger `NeteroViewModel.refreshCloudData()`.
- Discover triggers its existing AI matchmaking refresh callback.
- Existing real-time Firestore listeners remain in place; pull-to-refresh is an explicit manual sync gesture, not a replacement for live updates.
- Existing theme/colors/branding were not changed by this patch.
