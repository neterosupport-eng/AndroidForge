Netero authentication/onboarding fix — 2026-10-03

- Email OTP verification now exchanges the temporary OTP session for a persistent Firebase custom-token identity based on the verified email.
- Normal refresh no longer creates an anonymous Firebase user.
- Incomplete profile setup remains resumable through local draft persistence.
- Profile setup fields use rememberSaveable and draft persistence so avatar changes do not clear name/username.
- Pull-to-refresh remains enabled on Home, Connections, Rooms and Discover with no refresh button.
