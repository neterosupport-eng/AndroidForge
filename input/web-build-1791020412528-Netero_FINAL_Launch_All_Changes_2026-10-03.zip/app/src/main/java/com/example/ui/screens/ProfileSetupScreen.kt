package com.example.ui.screens
import androidx.compose.ui.platform.LocalContext

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.material.icons.filled.Add
import androidx.compose.foundation.layout.Arrangement

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.compose.material3.CircularProgressIndicator
import coil.compose.AsyncImage
import android.net.Uri

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.AlternateEmail
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Domain
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.DatePicker
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.NeteroTheme

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileSetupScreen(
    onUploadImage: (android.net.Uri, (Boolean) -> Unit) -> Unit = { _, _ -> },
    userProfile: UserProfile,
    onSaveProfile: (
        username: String,
        fullName: String,
        headline: String,
        jobTitle: String,
        company: String,
        industry: String,
        bio: String,
        location: String,
        phone: String,
        email: String,
        dateOfBirth: String,
        website: String,
        linkedinUrl: String,
        businessUrl: String,
        portfolioUrl: String,
        themeColorHex: String,
        isStudent: Boolean
    ) -> Unit,
    onEnhanceBio: (
        name: String,
        jobTitle: String,
        company: String,
        industry: String,
        currentBio: String,
        onResult: (String) -> Unit
    ) -> Unit,
    onNavigateBack: () -> Unit,
    onNavigateNext: () -> Unit,
    onNavigateToPaywall: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    
    var fullName by rememberSaveable { mutableStateOf(userProfile.fullName) }
    var username by rememberSaveable { mutableStateOf(userProfile.username) }
    var headline by rememberSaveable { mutableStateOf(userProfile.headline) }
    var jobTitle by rememberSaveable { mutableStateOf(userProfile.jobTitle) }
    var company by rememberSaveable { mutableStateOf(userProfile.company) }
    var industry by rememberSaveable { mutableStateOf(userProfile.industry) }
    var bio by rememberSaveable { mutableStateOf(userProfile.bio) }
    var location by rememberSaveable { mutableStateOf(userProfile.location) }
    var phone by rememberSaveable { mutableStateOf(userProfile.phone) }
    val savedEmail = remember {
        val legacy = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE).getString("user_email", "") ?: ""
        if (legacy.isNotBlank()) legacy else (context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).getString("user_email", "") ?: "")
    }
    var email by rememberSaveable { mutableStateOf(userProfile.email.ifBlank { savedEmail }) }
    var dateOfBirth by rememberSaveable { mutableStateOf(userProfile.dateOfBirth) }
    var website by rememberSaveable { mutableStateOf(userProfile.website) }
    var linkedinUrl by rememberSaveable { mutableStateOf(userProfile.linkedinUrl) }
    var businessUrl by rememberSaveable { mutableStateOf(userProfile.businessUrl) }
    var portfolioUrl by rememberSaveable { mutableStateOf(userProfile.portfolioUrl) }
    var isStudent by rememberSaveable { mutableStateOf(userProfile.isStudent) }
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()

    var selectedTheme by rememberSaveable { mutableStateOf(userProfile.themeColorHex) }
    var isEnhancingBio by remember { mutableStateOf(false) }
    val isFormValid = fullName.isNotBlank() && username.isNotBlank() && headline.isNotBlank() && jobTitle.isNotBlank() && company.isNotBlank() && industry.isNotBlank()

    val currentProfile = UserProfile(
        fullName = fullName,
        username = username,
        headline = headline,
        jobTitle = jobTitle,
        company = company,
        industry = industry,
        bio = bio,
        location = location,
        phone = phone,
        email = email,
        dateOfBirth = dateOfBirth,
        website = website,
        linkedinUrl = linkedinUrl,
        businessUrl = businessUrl,
        portfolioUrl = portfolioUrl
    )
    val completionPercentage = currentProfile.completionPercentage


    if (showDatePicker) {
        DatePickerDialog(
            onDismissRequest = { showDatePicker = false },
            confirmButton = {
                TextButton(onClick = {
                    datePickerState.selectedDateMillis?.let { millis ->
                        val sdf = java.text.SimpleDateFormat("dd/MM/yyyy", java.util.Locale.getDefault())
                        dateOfBirth = sdf.format(java.util.Date(millis))
                    }
                    showDatePicker = false
                }) { Text("OK") }
            },
            dismissButton = {
                TextButton(onClick = { showDatePicker = false }) { Text("Cancel") }
            }
        ) {
            DatePicker(state = datePickerState)
        }
    }

    val scope = rememberCoroutineScope()
    var isUploading by remember { mutableStateOf(false) }
    var showPhotoSourceDialog by remember { mutableStateOf(false) }
    var showPresetAvatarsSheet by remember { mutableStateOf(false) }
    var localImageUri by rememberSaveable { mutableStateOf(userProfile.profileImageUrl) }

    // Keep an in-progress profile draft separate from the completed profile. This lets
    // users leave/reopen the app during onboarding without losing fields, and prevents
    // avatar uploads (which update userProfile) from resetting the form.
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
        fun draft(key: String, fallback: String): String = prefs.getString("draft_$key", null)?.let { if (it.isNotBlank()) it else fallback } ?: fallback
        if (fullName.isBlank()) fullName = draft("name", fullName)
        if (username.isBlank()) username = draft("username", username)
        if (headline.isBlank()) headline = draft("headline", headline)
        if (jobTitle.isBlank()) jobTitle = draft("title", jobTitle)
        if (company.isBlank()) company = draft("company", company)
        if (industry.isBlank()) industry = draft("industry", industry)
        if (bio.isBlank()) bio = draft("bio", bio)
        if (location.isBlank()) location = draft("location", location)
        if (phone.isBlank()) phone = draft("phone", phone)
        if (email.isBlank()) email = draft("email", email)
        if (dateOfBirth.isBlank()) dateOfBirth = draft("dob", dateOfBirth)
        if (website.isBlank()) website = draft("website", website)
        if (linkedinUrl.isBlank()) linkedinUrl = draft("linkedin", linkedinUrl)
        if (businessUrl.isBlank()) businessUrl = draft("business", businessUrl)
        if (portfolioUrl.isBlank()) portfolioUrl = draft("portfolio", portfolioUrl)
        if (localImageUri.isBlank()) localImageUri = draft("image_uri", userProfile.profileImageUrl)
    }

    LaunchedEffect(fullName, username, headline, jobTitle, company, industry, bio, location, phone, email, dateOfBirth, website, linkedinUrl, businessUrl, portfolioUrl, localImageUri, isStudent) {
        context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).edit()
            .putString("draft_name", fullName)
            .putString("draft_username", username)
            .putString("draft_headline", headline)
            .putString("draft_title", jobTitle)
            .putString("draft_company", company)
            .putString("draft_industry", industry)
            .putString("draft_bio", bio)
            .putString("draft_location", location)
            .putString("draft_phone", phone)
            .putString("draft_email", email)
            .putString("draft_dob", dateOfBirth)
            .putString("draft_website", website)
            .putString("draft_linkedin", linkedinUrl)
            .putString("draft_business", businessUrl)
            .putString("draft_portfolio", portfolioUrl)
            .putBoolean("draft_is_student", isStudent)
            .putString("draft_image_uri", localImageUri)
            .apply()
    }

    val getContentLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                isUploading = true
                localImageUri = uri.toString()
                try {
                    onUploadImage(uri) { success ->
                        isUploading = false
                        val message = if (success) "Photo uploaded successfully!" else "Could not upload photo"
                        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    isUploading = false
                    android.widget.Toast.makeText(context, "Could not load photo: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    val photoPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                isUploading = true
                localImageUri = uri.toString()
                try {
                    onUploadImage(uri) { success ->
                        isUploading = false
                        val message = if (success) "Photo uploaded successfully!" else "Could not upload photo"
                        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    isUploading = false
                    android.widget.Toast.makeText(context, "Could not load photo", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "Build NETERO Profile",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onNavigateBack,
                        modifier = Modifier.testTag("back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            val totalSteps = 5
            var currentStep by rememberSaveable { mutableStateOf(0) }

            // Progress Header
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Step ${currentStep + 1} of $totalSteps",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Box(
                            modifier = Modifier
                                .clip(CircleShape)
                                .background(AccentBlue.copy(alpha = 0.2f))
                                .padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Text(
                                text = "Setup Wizard",
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    LinearProgressIndicator(
                        progress = { (currentStep + 1) / totalSteps.toFloat() },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(8.dp)
                            .clip(CircleShape),
                        color = MaterialTheme.colorScheme.primary,
                        trackColor = MaterialTheme.colorScheme.surfaceVariant,
                        strokeCap = StrokeCap.Round
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(8.dp))
            
            when (currentStep) {
                0 -> {
                    Text(
                        text = "1. Identity & Avatar",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(104.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .border(2.dp, AccentBlue, CircleShape)
                                    .clickable { showPhotoSourceDialog = true },
                                contentAlignment = Alignment.Center
                            ) {
                                val currentImg = localImageUri.ifBlank { userProfile.profileImageUrl }
                                if (currentImg.isNotBlank()) {
                                    coil.compose.AsyncImage(
                                        model = com.example.utils.AttachmentHelper.getDisplayableImageModel(currentImg),
                                        contentDescription = "Profile Picture",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.Person,
                                        contentDescription = "Add Profile Picture",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(52.dp)
                                    )
                                }
                                if (isUploading) {
                                    CircularProgressIndicator(modifier = Modifier.size(28.dp), color = AccentBlue)
                                }
                                Box(
                                    modifier = Modifier
                                        .align(Alignment.BottomEnd)
                                        .clip(CircleShape)
                                        .background(AccentBlue)
                                        .padding(6.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Add,
                                        contentDescription = "Add",
                                        tint = androidx.compose.ui.graphics.Color.White,
                                        modifier = Modifier.size(14.dp)
                                    )
                                }
                            }
                            
                            OutlinedButton(
                                onClick = { showPhotoSourceDialog = true },
                                shape = RoundedCornerShape(20.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = AccentBlue)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = if (localImageUri.isNotBlank() || userProfile.profileImageUrl.isNotBlank()) "Change Photo" else "Upload Profile Photo",
                                    style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                                )
                            }
                        }
                    }
                    NeteroTextField(
                        value = fullName,
                        onValueChange = { fullName = it },
                        label = "Full Name",
                        placeholder = "e.g., Alex",
                        icon = Icons.Default.Person,
                        testTag = "full_name_input"
                    )
                    NeteroTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = "NETERO Username",
                        placeholder = "e.g., Alex@123",
                        icon = Icons.Default.AlternateEmail,
                        testTag = "username_input"
                    )
                }
                1 -> {
                    Text(
                        text = "2. Professional Status",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    NeteroTextField(
                        value = headline,
                        onValueChange = { headline = it },
                        label = "Professional Headline",
                        placeholder = "e.g., Building the future of real-world networking",
                        icon = Icons.Default.Info,
                        testTag = "headline_input"
                    )
                    if (isStudent) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(modifier = Modifier.weight(1f)) {
                                NeteroTextField(
                                    value = jobTitle,
                                    onValueChange = { jobTitle = it },
                                    label = "Degree / Major",
                                    placeholder = "e.g., BSc Computer Science",
                                    icon = Icons.Default.School,
                                    testTag = "degree_input"
                                )
                            }
                            Box(modifier = Modifier.weight(1f)) {
                                NeteroTextField(
                                    value = company,
                                    onValueChange = { company = it },
                                    label = "University / College",
                                    placeholder = "e.g., Stanford University",
                                    icon = Icons.Default.AccountBalance,
                                    testTag = "university_input"
                                )
                            }
                        }
                    } else {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Box(modifier = Modifier.weight(1f)) {
                            NeteroTextField(
                                value = jobTitle,
                                onValueChange = { jobTitle = it },
                                label = "Job Title",
                                placeholder = "e.g., Founder",
                                icon = Icons.Default.Work,
                                testTag = "job_title_input"
                            )
                        }
                        Box(modifier = Modifier.weight(1f)) {
                            NeteroTextField(
                                value = company,
                                onValueChange = { company = it },
                                label = "Company",
                                placeholder = "e.g., Netero",
                                icon = Icons.Default.Business,
                                testTag = "company_input"
                            )
                        }
                    }
                    NeteroTextField(
                        value = industry,
                        onValueChange = { industry = it },
                        label = "Industry / Sector",
                        placeholder = "e.g., Technology • SaaS",
                        icon = Icons.Default.Domain,
                        testTag = "industry_input"
                    )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .clickable { isStudent = !isStudent }
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        androidx.compose.material3.Checkbox(
                            checked = isStudent,
                            onCheckedChange = { isStudent = it },
                            colors = androidx.compose.material3.CheckboxDefaults.colors(
                                checkedColor = AccentBlue
                            )
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "I am a University Student",
                                style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.Medium),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Show my profile in the Students directory",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
                2 -> {
                    Text(
                        text = "3. Your Bio",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    NeteroTextField(
                        value = bio,
                        onValueChange = { bio = it },
                        label = "Bio",
                        placeholder = "Brief introduction for people who meet you...",
                        icon = Icons.Default.Info,
                        singleLine = false,
                        testTag = "bio_input"
                    )
                    Button(
                        onClick = {
                            if (userProfile.isPro) {
                                isEnhancingBio = true
                                onEnhanceBio(fullName, jobTitle, company, industry, bio) { enhancedBio ->
                                    bio = enhancedBio
                                    isEnhancingBio = false
                                }
                            } else {
                                onNavigateToPaywall()
                            }
                        },
                        enabled = !isEnhancingBio,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("improve_with_ai_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.surfaceVariant,
                            contentColor = AccentBlue,
                            disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            disabledContentColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                        ),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        if (isEnhancingBio) {
                            androidx.compose.material3.CircularProgressIndicator(
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp),
                                strokeWidth = 2.dp
                            )
                        } else {
                            Text(
                                text = "✨ Improve with Asteron AI",
                                style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                }
                3 -> {
                    Text(
                        text = "4. Contact Info",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    NeteroTextField(
                        value = location,
                        onValueChange = { location = it },
                        label = "Country & Region (Location)",
                        placeholder = "e.g., India, UK, USA",
                        icon = Icons.Default.LocationOn,
                        testTag = "location_input"
                    )
                    NeteroTextField(
                        value = phone,
                        onValueChange = { phone = it },
                        label = "Phone Number (Optional)",
                        placeholder = "e.g., +91 98765 43210",
                        icon = Icons.Default.Phone,
                        testTag = "phone_input"
                    )
                    NeteroTextField(
                        value = email,
                        onValueChange = { email = it },
                        label = "Email Address (Optional)",
                        placeholder = "e.g., you@company.com",
                        icon = Icons.Default.Email,
                        testTag = "email_input"
                    )
                    Box(modifier = Modifier.clickable { showDatePicker = true }) {
                        NeteroTextField(
                            value = dateOfBirth,
                            onValueChange = { },
                            label = "Date of Birth (Tap to select)",
                            placeholder = "e.g., DD/MM/YYYY",
                            icon = Icons.Default.Info,
                            testTag = "dob_input"
                        )
                        // Invisible overlay to capture clicks
                        Box(modifier = Modifier.matchParentSize().background(androidx.compose.ui.graphics.Color.Transparent).clickable { showDatePicker = true })
                    }
                }
                4 -> {
                    Text(
                        text = "5. Social Links",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                    NeteroTextField(
                        value = website,
                        onValueChange = { website = it },
                        label = "Website Link",
                        placeholder = "https://yourwebsite.com",
                        icon = Icons.Default.Link,
                        testTag = "website_input"
                    )
                    NeteroTextField(
                        value = portfolioUrl,
                        onValueChange = { portfolioUrl = it },
                        label = "Portfolio / Featured Work Link",
                        placeholder = "e.g., github.com/username or behance.net/portfolio",
                        icon = Icons.Default.Link,
                        testTag = "portfolio_url_input"
                    )
                    NeteroTextField(
                        value = businessUrl,
                        onValueChange = { businessUrl = it },
                        label = "Business / Store / Product Link",
                        placeholder = "https://yourcompany.com",
                        icon = Icons.Default.Business,
                        testTag = "business_url_input"
                    )
                    NeteroTextField(
                        value = linkedinUrl,
                        onValueChange = { linkedinUrl = it },
                        label = "LinkedIn Profile",
                        placeholder = "linkedin.com/in/username",
                        icon = Icons.Default.Person,
                        testTag = "linkedin_input"
                    )
                }

            }

            Spacer(modifier = Modifier.height(16.dp))

            // Navigation Buttons Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                if (currentStep > 0) {
                    OutlinedButton(
                        onClick = { currentStep -= 1 },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                    ) {
                        Text("Back", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }

                if (currentStep < totalSteps - 1) {
                    Button(
                        onClick = { 
                                                        when (currentStep) {
                                0 -> {
                                    if (fullName.isBlank() || username.isBlank()) {
                                        android.widget.Toast.makeText(context, "Full Name and Username are mandatory", android.widget.Toast.LENGTH_SHORT).show()
                                    } else if (username.lowercase() == "rahul26") {
                                        android.widget.Toast.makeText(context, "Username @$username is already taken. Please try another one.", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        currentStep += 1
                                    }
                                }
                                1 -> {
                                    if (jobTitle.isBlank() || company.isBlank() || (!isStudent && industry.isBlank())) {
                                        val errorMsg = if (isStudent) "Degree/Major and University/College are mandatory" else "Job Title, Company, and Industry are mandatory"
                                        android.widget.Toast.makeText(context, errorMsg, android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        currentStep += 1
                                    }
                                }
                                2 -> {
                                    if (bio.isBlank()) {
                                        android.widget.Toast.makeText(context, "Bio is mandatory", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        currentStep += 1
                                    }
                                }
                                3 -> {
                                    if (dateOfBirth.isBlank() || location.isBlank()) {
                                        android.widget.Toast.makeText(context, "Location and Date of Birth are mandatory", android.widget.Toast.LENGTH_SHORT).show()
                                    } else {
                                        currentStep += 1
                                    }
                                }
                                4 -> {
                                    currentStep += 1
                                }
                                else -> currentStep += 1
                            }
                        },
                        modifier = Modifier
                            .weight(1f)
                            .height(56.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentBlue,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Text("Continue", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    }
                } else {
                    Button(
                        onClick = {
                            if (company != userProfile.company && userProfile.company.isNotEmpty()) {
                                android.widget.Toast.makeText(context, "Network Notification Sent: Your connections have been notified that you changed your company from ${userProfile.company} to $company!", android.widget.Toast.LENGTH_LONG).show()
                            } else {
                                android.widget.Toast.makeText(context, "✨ Cloud Sync: Profile updated for all your connections!", android.widget.Toast.LENGTH_LONG).show()
                            }
                            
                            onSaveProfile(
                                username,
                                fullName,
                                headline,
                                jobTitle,
                                company,
                                industry,
                                bio,
                                location,
                                phone,
                                email.ifBlank { savedEmail },
                                dateOfBirth,
                                website,
                                linkedinUrl,
                                businessUrl,
                                portfolioUrl,
                                selectedTheme,
                                isStudent
                            )
                            context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).edit()
                                .remove("profile_setup_in_progress")
                                .remove("draft_name").remove("draft_username").remove("draft_headline")
                                .remove("draft_title").remove("draft_company").remove("draft_industry")
                                .remove("draft_bio").remove("draft_location").remove("draft_phone")
                                .remove("draft_email").remove("draft_dob").remove("draft_website")
                                .remove("draft_linkedin").remove("draft_business").remove("draft_portfolio")
                                .remove("draft_is_student").remove("draft_image_uri")
                                .apply()
                            onNavigateNext()
                        },
                        modifier = Modifier
                            .weight(2f)
                            .height(56.dp)
                            .testTag("save_and_continue_button"),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = AccentBlue,
                            contentColor = MaterialTheme.colorScheme.onPrimary
                        ),
                        shape = RoundedCornerShape(16.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Save Profile",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
            Spacer(modifier = Modifier.height(24.dp))
        }

        if (showPhotoSourceDialog) {
            AlertDialog(
                onDismissRequest = { showPhotoSourceDialog = false },
                title = { Text("Profile Photo", fontWeight = FontWeight.Bold) },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Select how you want to add your profile photo:", style = MaterialTheme.typography.bodyMedium)
                        
                        Button(
                            onClick = {
                                showPhotoSourceDialog = false
                                try {
                                    photoPickerLauncher.launch(
                                        androidx.activity.result.PickVisualMediaRequest(
                                            androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                        )
                                    )
                                } catch (e: Exception) {
                                    try {
                                        getContentLauncher.launch("image/*")
                                    } catch (e2: Exception) {
                                        android.widget.Toast.makeText(context, "Could not open photo picker", android.widget.Toast.LENGTH_SHORT).show()
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.Person, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Upload from Device Gallery")
                        }

                        OutlinedButton(
                            onClick = {
                                showPhotoSourceDialog = false
                                showPresetAvatarsSheet = true
                            },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentBlue)
                            Spacer(Modifier.width(8.dp))
                            Text("Choose Preset Professional Avatar")
                        }
                    }
                },
                confirmButton = {},
                dismissButton = {
                    OutlinedButton(onClick = { showPhotoSourceDialog = false }) { Text("Cancel") }
                }
            )
        }

        if (showPresetAvatarsSheet) {
            val presetAvatars = remember {
                listOf(
                    "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80",
                    "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80",
                    "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80",
                    "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80",
                    "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&auto=format&fit=crop&q=80",
                    "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80"
                )
            }
            ModalBottomSheet(
                onDismissRequest = { showPresetAvatarsSheet = false },
                containerColor = MaterialTheme.colorScheme.surface
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 24.dp, vertical = 16.dp)
                        .padding(bottom = 32.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Text(
                        text = "Choose a Professional Avatar",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = "Tap any curated executive portrait to instantly set as your profile photo:",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        presetAvatars.take(3).forEach { avatarUrl ->
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, AccentBlue, CircleShape)
                                    .clickable {
                                        showPresetAvatarsSheet = false
                                        localImageUri = avatarUrl
                                        isUploading = true
                                        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                            try {
                                                val localUri = com.example.utils.AttachmentHelper.downloadRemoteImageToCache(context, avatarUrl)
                                                if (localUri == null) throw java.io.IOException("Avatar download failed")
                                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                    onUploadImage(localUri) {
                                                        isUploading = false
                                                        android.widget.Toast.makeText(context, "Avatar selected!", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                    isUploading = false
                                                }
                                            }
                                        }
                                    }
                            ) {
                                coil.compose.AsyncImage(
                                    model = avatarUrl,
                                    contentDescription = "Preset Avatar",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceEvenly
                    ) {
                        presetAvatars.drop(3).take(3).forEach { avatarUrl ->
                            Box(
                                modifier = Modifier
                                    .size(88.dp)
                                    .clip(CircleShape)
                                    .border(2.dp, AccentBlue, CircleShape)
                                    .clickable {
                                        showPresetAvatarsSheet = false
                                        localImageUri = avatarUrl
                                        isUploading = true
                                        scope.launch(kotlinx.coroutines.Dispatchers.IO) {
                                            try {
                                                val localUri = com.example.utils.AttachmentHelper.downloadRemoteImageToCache(context, avatarUrl)
                                                if (localUri == null) throw java.io.IOException("Avatar download failed")
                                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                    onUploadImage(localUri) {
                                                        isUploading = false
                                                        android.widget.Toast.makeText(context, "Avatar selected!", android.widget.Toast.LENGTH_SHORT).show()
                                                    }
                                                }
                                            } catch (e: Exception) {
                                                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                                                    isUploading = false
                                                }
                                            }
                                        }
                                    }
                            ) {
                                coil.compose.AsyncImage(
                                    model = avatarUrl,
                                    contentDescription = "Preset Avatar",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NeteroTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    placeholder: String,
    icon: ImageVector,
    singleLine: Boolean = true,
    testTag: String = ""
) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        modifier = Modifier
            .fillMaxWidth()
            .testTag(testTag),
        label = { Text(text = label, color = MaterialTheme.colorScheme.onSurfaceVariant) },
        placeholder = { Text(text = placeholder, color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f)) },
        leadingIcon = {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary
            )
        },
        singleLine = singleLine,
        maxLines = if (singleLine) 1 else 3,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            focusedBorderColor = AccentBlue,
            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
            focusedTextColor = MaterialTheme.colorScheme.onSurface,
            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
        ),
        shape = RoundedCornerShape(12.dp)
    )
}

@Preview(showBackground = true)
@Composable
fun ProfileSetupScreenPreview() {
    NeteroTheme(darkTheme = true) {
        ProfileSetupScreen(
            userProfile = UserProfile(),
            onSaveProfile = { _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _ -> },
            onUploadImage = { _, _ -> },
            onEnhanceBio = { _, _, _, _, _, _ -> },
            onNavigateBack = {},
            onNavigateNext = {}
        )
    }
}
