package com.example.ui.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.geometry.Offset
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/**
 * Instagram-style pull-to-refresh container.
 * There is deliberately no refresh button. Pull down from the top of the
 * scrollable content to trigger [onRefresh]. Live Firestore listeners remain
 * responsible for normal real-time updates.
 */
@Composable
fun PullToRefreshLayout(
    onRefresh: () -> Unit,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    var pullDistance by remember { mutableFloatStateOf(0f) }
    var refreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val threshold = 120f

    val connection = remember(refreshing) {
        object : NestedScrollConnection {
            override fun onPostScroll(
                consumed: Offset,
                available: Offset,
                source: NestedScrollSource
            ): Offset {
                // Positive Y is an unconsumed downward drag. A LazyColumn /
                // verticalScroll only leaves it unconsumed when already at top.
                if (!refreshing && available.y > 0f) {
                    pullDistance = (pullDistance + available.y * 0.55f).coerceAtMost(threshold * 1.5f)
                } else if (available.y < 0f) {
                    pullDistance = 0f
                }
                return Offset.Zero
            }

            override suspend fun onPreFling(available: Offset): Offset {
                if (!refreshing && pullDistance >= threshold) {
                    pullDistance = 0f
                    refreshing = true
                    scope.launch {
                        try {
                            onRefresh()
                        } finally {
                            // Keep the indicator visible long enough to feel like
                            // a real refresh even when Firestore data is already live.
                            delay(650)
                            refreshing = false
                        }
                    }
                } else {
                    pullDistance = 0f
                }
                return Offset.Zero
            }
        }
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .nestedScroll(connection)
    ) {
        content()

        if (pullDistance > 0f || refreshing) {
            val progress = if (refreshing) 1f else (pullDistance / threshold).coerceIn(0f, 1f)
            CircularProgressIndicator(
                progress = progress,
                modifier = Modifier
                    .align(Alignment.TopCenter)
                    .offset { IntOffset(0, (pullDistance.coerceAtMost(threshold) * 0.55f).roundToInt()) },
                strokeWidth = 2.dp,
                color = MaterialTheme.colorScheme.primary
            )
        }
    }
}
