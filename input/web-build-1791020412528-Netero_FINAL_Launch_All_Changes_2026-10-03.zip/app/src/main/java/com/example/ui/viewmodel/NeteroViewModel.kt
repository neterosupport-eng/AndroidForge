package com.example.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.api.CloudSyncManager
import com.example.data.api.GeminiAiHelper
import com.example.data.local.toEntity
import com.example.data.model.ChatMessage
import com.example.data.model.ConnectionContact
import com.example.data.model.ConnectionStatus
import com.example.data.model.PrivacyLevel
import com.example.data.model.RecommendedPerson
import com.example.data.model.Room
import com.example.data.model.RoomDiscussion
import com.example.data.model.RoomMember
import com.example.data.model.RoomOpportunity
import com.example.data.model.RoomSpeaker
import com.example.data.model.RoomType
import com.example.data.model.UserProfile
import com.example.data.model.NeteroLockSettings
import org.json.JSONArray
import org.json.JSONObject
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.tasks.await


data class AppNotification(
    val id: String,
    val title: String,
    val body: String,
    val timeAgo: String
)

data class ConnectionRequest(
    val id: String,
    val senderName: String,
    val senderTitle: String,
    val senderCompany: String,
    val message: String,
    val timeAgo: String,
    val avatarInitial: String,
    val avatarBgHex: Long,
    val timestamp: Long = System.currentTimeMillis(),
    val isQrScan: Boolean = false,
    val senderId: String = id
)

data class AiAssistantMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val isFromUser: Boolean,
    val timestamp: String = "Just now"
)

data class AiChatSession(
    val id: String = java.util.UUID.randomUUID().toString(),
    val title: String,
    val timestamp: Long = System.currentTimeMillis(),
    val messages: List<AiAssistantMessage>
)

class NeteroViewModel(application: android.app.Application) : androidx.lifecycle.AndroidViewModel(application) {
    private var networkSearchJob: Job? = null
    private val connectionDao = com.example.data.local.NeteroDatabase.getDatabase(application).connectionDao()

    private val sharedPrefs = application.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)

    private val cloudSyncManager = CloudSyncManager()
    private var realtimeListenersStarted = false

    private fun loadLocalUserProfile(prefs: android.content.SharedPreferences): UserProfile {
        val app = getApplication<android.app.Application>()
        val legacyPrefs = app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)

        fun getString(key: String): String {
            val v = prefs.getString(key, "") ?: ""
            return if (v.isNotBlank()) v else (legacyPrefs.getString(key, "") ?: "")
        }
        fun getBoolean(key: String): Boolean {
            return prefs.getBoolean(key, false) || legacyPrefs.getBoolean(key, false)
        }

        val name = getString("profile_name")
        val username = getString("profile_username")
        if (name.isBlank() && username.isBlank()) return UserProfile()
        return UserProfile(
            fullName = name,
            username = username,
            headline = getString("profile_headline"),
            jobTitle = getString("profile_title"),
            company = getString("profile_company"),
            industry = getString("profile_industry"),
            bio = getString("profile_bio"),
            location = getString("profile_location"),
            phone = getString("profile_phone"),
            email = getString("profile_email").ifBlank { getString("user_email") },
            dateOfBirth = getString("profile_dob"),
            website = getString("profile_website"),
            businessUrl = getString("profile_business"),
            portfolioUrl = getString("profile_portfolio"),
            linkedinUrl = getString("profile_linkedin"),
            isStudent = getBoolean("profile_is_student"),
            profileImageUrl = getString("profile_image_url").ifBlank {
                val app = getApplication<android.app.Application>()
                val localPic = java.io.File(app.filesDir, "user_avatar.jpg")
                if (localPic.exists()) android.net.Uri.fromFile(localPic).toString() else ""
            }
        )
    }

    private fun saveProfileToLocalPrefs(profile: UserProfile) {
        val app = getApplication<android.app.Application>()
        val legacyPrefs = app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)

        fun applyTo(editor: android.content.SharedPreferences.Editor) {
            val canonical = if (profile.email.isNotBlank()) {
                "user_" + profile.email.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
            } else if (profile.username.isNotBlank()) {
                "user_" + profile.username.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
            } else null
            if (canonical != null) {
                editor.putString("canonical_user_id", canonical)
                editor.putString("persistent_user_uid", canonical)
            }
            editor.putString("profile_name", profile.fullName)
            editor.putString("profile_username", profile.username)
            editor.putString("profile_headline", profile.headline)
            editor.putBoolean("profile_is_student", profile.isStudent)
            editor.putString("profile_title", profile.jobTitle)
            editor.putString("profile_company", profile.company)
            editor.putString("profile_industry", profile.industry)
            editor.putString("profile_bio", profile.bio)
            editor.putString("profile_location", profile.location)
            editor.putString("profile_phone", profile.phone)
            editor.putString("profile_email", profile.email)
            editor.putString("user_email", profile.email)
            editor.putString("profile_dob", profile.dateOfBirth)
            editor.putString("profile_website", profile.website)
            editor.putString("profile_business", profile.businessUrl)
            editor.putString("profile_portfolio", profile.portfolioUrl)
            editor.putString("profile_linkedin", profile.linkedinUrl)
            editor.putString("profile_image_url", profile.profileImageUrl)
            if (profile.fullName.isNotBlank() || profile.username.isNotBlank()) {
                editor.putBoolean("is_logged_in", true)
            }
            editor.apply()
        }

        applyTo(sharedPrefs.edit())
        applyTo(legacyPrefs.edit())
    }

    private val _userProfile = MutableStateFlow(loadLocalUserProfile(sharedPrefs))
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    private val _cloudSyncStatus = MutableStateFlow("⚡ Live Cloud Sync Active")
    val cloudSyncStatus: StateFlow<String> = _cloudSyncStatus.asStateFlow()

    private val _isDarkTheme = MutableStateFlow(sharedPrefs.getBoolean("is_dark_theme", false))
    val isDarkTheme: StateFlow<Boolean> = _isDarkTheme.asStateFlow()

    // Professional Discovery State
    private val _discoverSearchQuery = MutableStateFlow("")
    val discoverSearchQuery: StateFlow<String> = _discoverSearchQuery.asStateFlow()

    private val _selectedDiscoverCategory = MutableStateFlow("All")
    val selectedDiscoverCategory: StateFlow<String> = _selectedDiscoverCategory.asStateFlow()

    private val _recommendedPeople = MutableStateFlow(initialRecommendedPeople())
    val recommendedPeople: StateFlow<List<RecommendedPerson>> = _recommendedPeople.asStateFlow()

    // Rooms State
    private val _roomsList = MutableStateFlow(initialRoomsList())
    val roomsList: StateFlow<List<Room>> = _roomsList.asStateFlow()
    
    private val activeRoomDiscussionJobs = java.util.concurrent.ConcurrentHashMap<String, kotlinx.coroutines.Job>()
    private val processedNotificationRequestIds = java.util.Collections.synchronizedSet(mutableSetOf<String>())

    fun listenToLiveDiscussions(roomId: String) {
        if (roomId.isBlank() || activeRoomDiscussionJobs.containsKey(roomId)) return
        val job = viewModelScope.launch(Dispatchers.IO) {
            cloudSyncManager.listenToRoomDiscussions(roomId).collect { liveDiscs ->
                _roomsList.update { list ->
                    list.map { r ->
                        if (r.id == roomId) {
                            // The discussions subcollection is the single source
                            // of truth, including the empty state after deletion.
                            r.copy(discussions = liveDiscs)
                        } else r
                    }
                }
            }
        }
        activeRoomDiscussionJobs[roomId] = job
    }

    private fun getCurrentUserId(): String {
        // Firebase Auth UID is the single authoritative backend identity.
        // Email/username remain profile aliases only; they must never become
        // Firestore user-document IDs because the same person can change them.
        return try {
            val authUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
            if (!authUid.isNullOrBlank()) {
                sharedPrefs.edit()
                    .putString("canonical_user_id", authUid)
                    .putString("persistent_user_uid", authUid)
                    .apply()
                return authUid
            }
            val cached = sharedPrefs.getString("persistent_user_uid", null)
                ?: sharedPrefs.getString("canonical_user_id", null)
            cached ?: ""
        } catch (_: Exception) {
            sharedPrefs.getString("persistent_user_uid", null)
                ?: sharedPrefs.getString("canonical_user_id", null)
                ?: ""
        }
    }

    private fun cleanupStaleRequests() {
        val fourteenDaysInMillis = 14L * 24 * 60 * 60 * 1000
        val currentTime = System.currentTimeMillis()
        _connectionRequests.update { list ->
            list.filter { request ->
                (currentTime - request.timestamp) <= fourteenDaysInMillis
            }
        }
    }

    private fun checkAndArchiveRooms() {
        val formatter = java.text.SimpleDateFormat("dd/MM/yyyy HH:mm", java.util.Locale.getDefault())
        val now = java.util.Date()

        _roomsList.update { list ->
            list.map { room ->
                if (room.type == com.example.data.model.RoomType.EVENT && room.endDate.isNotEmpty() && room.endTime.isNotEmpty()) {
                    try {
                        val endDateTimeStr = "${room.endDate} ${room.endTime}"
                        val endDateTime = formatter.parse(endDateTimeStr)
                        if (endDateTime != null) {
                            val archiveTime = java.util.Date(endDateTime.time + 24 * 60 * 60 * 1000L)
                            if (now.after(archiveTime)) {
                                room.copy(isArchived = true)
                            } else room
                        } else room
                    } catch (e: Exception) {
                        room
                    }
                } else room
            }
        }
    }

    private val _selectedRoomId = MutableStateFlow<String?>(null)
    val selectedRoomId: StateFlow<String?> = _selectedRoomId.asStateFlow()

    // Connections State
    private val _connectionsList = MutableStateFlow(initialConnectionsList())
    val connectionsList: StateFlow<List<ConnectionContact>> = _connectionsList.asStateFlow()

    init {
        viewModelScope.launch {
            connectionDao.getAllConnections().collect { entities ->
                val contacts = entities.map { it.toContact() }
                _connectionsList.value = contacts
            }
        }
    }


    private val _connectionRequests = MutableStateFlow(initialConnectionRequests())
    val connectionRequests: StateFlow<List<ConnectionRequest>> = _connectionRequests.asStateFlow()

    private val _sentConnectionRequestIds = MutableStateFlow<Set<String>>(emptySet())
    val sentConnectionRequestIds: StateFlow<Set<String>> = _sentConnectionRequestIds.asStateFlow()

    private fun isAlreadyConnected(person: RecommendedPerson): Boolean {
        val normalizedId = person.id.trim().lowercase()
        val normalizedUsername = person.username.trim().lowercase()
        val normalizedEmail = person.email?.trim()?.lowercase().orEmpty()
        val normalizedPhone = person.phone?.replace(Regex("[^0-9+]"), "").orEmpty()
        return _connectionsList.value.any { c ->
            c.id.trim().lowercase() == normalizedId ||
            c.name.trim().equals(person.name.trim(), ignoreCase = true) ||
            (normalizedUsername.isNotBlank() && c.id.trim().lowercase() == normalizedUsername) ||
            (normalizedEmail.isNotBlank() && c.email.trim().lowercase() == normalizedEmail) ||
            (normalizedPhone.length >= 7 && c.phone.replace(Regex("[^0-9+]"), "").endsWith(normalizedPhone.takeLast(7)))
        } || _userProfile.value.connectionIds.any { id ->
            val clean = id.trim().lowercase()
            clean == normalizedId ||
            (normalizedUsername.isNotBlank() && clean == normalizedUsername)
        }
    }

    private fun resolveConnectionStatus(person: RecommendedPerson): ConnectionStatus {
        if (isAlreadyConnected(person)) return ConnectionStatus.CONNECTED
        if (_sentConnectionRequestIds.value.contains(person.id)) return ConnectionStatus.PENDING
        return person.status
    }

    private val _connectionsSearchQuery = MutableStateFlow("")
    val connectionsSearchQuery: StateFlow<String> = _connectionsSearchQuery.asStateFlow()

    private val _selectedConnectionFilter = MutableStateFlow("All")
    val selectedConnectionFilter: StateFlow<String> = _selectedConnectionFilter.asStateFlow()

    private val _selectedContactForSheet = MutableStateFlow<ConnectionContact?>(null)
    val selectedContactForSheet: StateFlow<ConnectionContact?> = _selectedContactForSheet.asStateFlow()

    // Messaging State
    private val _chatMessages = MutableStateFlow<Map<String, List<ChatMessage>>>(initialChatMessages())
    val chatMessages: StateFlow<Map<String, List<ChatMessage>>> = _chatMessages.asStateFlow()


    private val _notifications = MutableStateFlow<List<AppNotification>>(emptyList())
    val notifications: StateFlow<List<AppNotification>> = _notifications.asStateFlow()

    private val _networkNotifications = kotlinx.coroutines.flow.MutableSharedFlow<String>()
    val networkNotifications: kotlinx.coroutines.flow.SharedFlow<String> = _networkNotifications.asSharedFlow()

    private val _profileViews = MutableStateFlow<List<Pair<String, String>>>(emptyList())
    val profileViews: StateFlow<List<Pair<String, String>>> = _profileViews.asStateFlow()

    // Ask Anything AI Assistant State
    private val _aiAssistantMessages = MutableStateFlow<List<AiAssistantMessage>>(
        listOf(
            AiAssistantMessage(
                text = "Hello! 👋 I'm your Asteron AI Assistant. Ask me anything about networking strategies, startup elevator pitches, cold emails, resume feedback, or tech event icebreakers!",
                isFromUser = false
            )
        )
    )
    val aiAssistantMessages: StateFlow<List<AiAssistantMessage>> = _aiAssistantMessages.asStateFlow()

    private val _aiChatSessions = MutableStateFlow<List<AiChatSession>>(emptyList())
    val aiChatSessions: StateFlow<List<AiChatSession>> = _aiChatSessions.asStateFlow()

    private val _isAiThinking = MutableStateFlow(false)
    val isAiThinking: StateFlow<Boolean> = _isAiThinking.asStateFlow()

    // AI Behavioral & Learned Intent Profile
    private val _aiLearnedProfile = MutableStateFlow(loadAiLearnedProfile())
    val aiLearnedProfile: StateFlow<com.example.data.model.AiLearnedProfile> = _aiLearnedProfile.asStateFlow()

    private fun loadAiLearnedProfile(): com.example.data.model.AiLearnedProfile {
        return try {
            val app = getApplication<android.app.Application>()
            val prefs = app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
            val learnedJson = prefs.getString("ai_learned_profile_json", "")
            if (!learnedJson.isNullOrBlank()) {
                val obj = org.json.JSONObject(learnedJson)
                val interests = (0 until (obj.optJSONArray("interests")?.length() ?: 0)).mapNotNull { obj.optJSONArray("interests")?.optString(it) }
                val searches = (0 until (obj.optJSONArray("searches")?.length() ?: 0)).mapNotNull { obj.optJSONArray("searches")?.optString(it) }
                val industries = (0 until (obj.optJSONArray("industries")?.length() ?: 0)).mapNotNull { obj.optJSONArray("industries")?.optString(it) }
                val roles = (0 until (obj.optJSONArray("roles")?.length() ?: 0)).mapNotNull { obj.optJSONArray("roles")?.optString(it) }
                val synergies = (0 until (obj.optJSONArray("synergies")?.length() ?: 0)).mapNotNull { obj.optJSONArray("synergies")?.optString(it) }
                val persona = obj.optString("persona", "")
                val timestamp = obj.optLong("timestamp", 0L)
                com.example.data.model.AiLearnedProfile(
                    learnedInterests = interests,
                    recentSearchQueries = searches,
                    targetIndustries = industries,
                    targetRoles = roles,
                    aiNetworkingPersona = persona,
                    aiTargetSynergies = synergies,
                    lastAnalyzedTimestamp = timestamp
                )
            } else {
                com.example.data.model.AiLearnedProfile()
            }
        } catch (e: Exception) {
            com.example.data.model.AiLearnedProfile()
        }
    }

    fun saveAiLearnedProfile(profile: com.example.data.model.AiLearnedProfile) {
        _aiLearnedProfile.value = profile
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            try {
                val app = getApplication<android.app.Application>()
                val prefs = app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                val obj = org.json.JSONObject().apply {
                    put("interests", org.json.JSONArray(profile.learnedInterests))
                    put("searches", org.json.JSONArray(profile.recentSearchQueries))
                    put("industries", org.json.JSONArray(profile.targetIndustries))
                    put("roles", org.json.JSONArray(profile.targetRoles))
                    put("synergies", org.json.JSONArray(profile.aiTargetSynergies))
                    put("persona", profile.aiNetworkingPersona)
                    put("timestamp", profile.lastAnalyzedTimestamp)
                }
                prefs.edit().putString("ai_learned_profile_json", obj.toString()).apply()
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun recordSearchQuery(query: String) {
        if (query.isBlank()) return
        val clean = query.trim()
        val current = _aiLearnedProfile.value
        val updatedSearches = (listOf(clean) + current.recentSearchQueries.filter { !it.equals(clean, ignoreCase = true) }).take(10)
        
        val lower = clean.lowercase()
        val industryKeywords = listOf("saas", "fintech", "healthtech", "ai", "edtech", "marketing", "design", "investor", "founder", "engineering")
        val matchedIndustries = industryKeywords.filter { lower.contains(it) }
        val updatedIndustries = (current.targetIndustries + matchedIndustries).distinct().take(15)
        val updatedInterests = (current.learnedInterests + listOf(clean)).distinct().take(25)

        val updated = current.copy(
            recentSearchQueries = updatedSearches,
            targetIndustries = updatedIndustries,
            learnedInterests = updatedInterests
        )
        saveAiLearnedProfile(updated)
    }

    fun analyzeProfileWithAi(profile: UserProfile = _userProfile.value) {
        if (profile.fullName.isBlank() && profile.jobTitle.isBlank()) return
        viewModelScope.launch {
            try {
                val analysisObj = com.example.data.api.GeminiAiHelper.analyzeUserProfileDeeply(profile)
                val persona = analysisObj.optString("networkingPersona")
                val synergiesArray = analysisObj.optJSONArray("targetSynergies")
                val synergies = if (synergiesArray != null) {
                    (0 until synergiesArray.length()).mapNotNull { synergiesArray.optString(it) }
                } else emptyList()
                val kwArray = analysisObj.optJSONArray("focusKeywords")
                val focusKeywords = if (kwArray != null) {
                    (0 until kwArray.length()).mapNotNull { kwArray.optString(it) }
                } else emptyList()

                val currentLearned = _aiLearnedProfile.value
                val updatedInterests = (currentLearned.learnedInterests + focusKeywords).distinct().take(20)
                val updatedSynergies = (currentLearned.aiTargetSynergies + synergies).distinct().take(10)

                val updatedProfile = currentLearned.copy(
                    aiNetworkingPersona = if (persona.isNotBlank()) persona else currentLearned.aiNetworkingPersona,
                    aiTargetSynergies = updatedSynergies,
                    learnedInterests = updatedInterests,
                    lastAnalyzedTimestamp = System.currentTimeMillis()
                )
                saveAiLearnedProfile(updatedProfile)

                curateDiscoverListWithAi()
            } catch (e: Exception) {
                android.util.Log.e("NeteroViewModel", "Error analyzing profile with AI", e)
            }
        }
    }

    init {
        checkAndArchiveRooms()
        cleanupStaleRequests()
    }


    fun createNewRoom(name: String, desc: String, type: RoomType, loc: String, tags: List<String>, pwdBool: Boolean, pwdStr: String, sd: String, st: String, ed: String, et: String) {
        viewModelScope.launch {
            val room = Room(
                id = java.util.UUID.randomUUID().toString(),
                name = name,
                description = desc,
                type = type,
                location = loc,
                tags = tags,
                password = pwdStr,
                startDate = sd,
                startTime = st,
                endDate = ed,
                endTime = et,
                memberCount = 1,
                isJoined = true,
                isCreatedByMe = true,
                adminId = getCurrentUserId()
            )
            val created = cloudSyncManager.createNewRoom(room)
            if (created) {
                _roomsList.update { current -> (current.filterNot { it.id == room.id } + room) }
                listenToLiveDiscussions(room.id)
                _cloudSyncStatus.value = "✅ Room created"
            } else {
                _cloudSyncStatus.value = "❌ Room could not be saved"
            }
        }
    }


    fun setProfileImageUrl(url: String) {
        _userProfile.update { it.copy(profileImageUrl = url) }
        saveProfileToLocalPrefs(_userProfile.value)
        viewModelScope.launch {
            val currentId = getCurrentUserId()
            cloudSyncManager.syncProfileToCloud(currentId, _userProfile.value)
        }
    }

    fun uploadProfileImage(uri: android.net.Uri, onComplete: ((Boolean) -> Unit)? = null) {
        val app = getApplication<android.app.Application>()
        val previousUrl = _userProfile.value.profileImageUrl
        _userProfile.update { it.copy(profileImageUrl = uri.toString()) }
        saveProfileToLocalPrefs(_userProfile.value)

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            _cloudSyncStatus.value = "📸 Uploading image..."
            val currentId = getCurrentUserId()
            val resolver = app.contentResolver
            val uploadUri = com.example.utils.AttachmentHelper.prepareImageForUpload(app, uri) ?: uri
            val url = cloudSyncManager.uploadProfileImage(currentId, resolver, uploadUri)
            if (uploadUri != uri) {
                runCatching { java.io.File(android.net.Uri.parse(uploadUri.toString()).path ?: "").delete() }
            }
            if (!url.isNullOrBlank()) {
                _userProfile.update { it.copy(profileImageUrl = url) }
                saveProfileToLocalPrefs(_userProfile.value)
                val synced = cloudSyncManager.syncProfileToCloud(currentId, _userProfile.value)
                if (synced) {
                    _cloudSyncStatus.value = "✅ Image Uploaded"
                    onComplete?.invoke(true)
                } else {
                    _userProfile.update { it.copy(profileImageUrl = previousUrl) }
                    saveProfileToLocalPrefs(_userProfile.value)
                    _cloudSyncStatus.value = "❌ Could not save image to your profile"
                    onComplete?.invoke(false)
                }
            } else {
                _userProfile.update { it.copy(profileImageUrl = previousUrl) }
                saveProfileToLocalPrefs(_userProfile.value)
                _cloudSyncStatus.value = "❌ Image upload failed"
                onComplete?.invoke(false)
            }
        }
    }

    fun removeProfilePhoto() {
        val app = getApplication<android.app.Application>()
        val previousUrl = _userProfile.value.profileImageUrl
        _userProfile.update { it.copy(profileImageUrl = "") }
        saveProfileToLocalPrefs(_userProfile.value)
        viewModelScope.launch {
            _cloudSyncStatus.value = "🗑️ Removing photo..."
            val currentId = getCurrentUserId()
            val storageDeleted = cloudSyncManager.deleteProfileImage(currentId)
            val cloudSaved = cloudSyncManager.syncProfileToCloud(currentId, _userProfile.value)
            if (storageDeleted && cloudSaved) {
                try { java.io.File(app.filesDir, "user_avatar.jpg").delete() } catch (_: Exception) {}
                _cloudSyncStatus.value = "✅ Photo Removed"
            } else {
                _userProfile.update { it.copy(profileImageUrl = previousUrl) }
                saveProfileToLocalPrefs(_userProfile.value)
                _cloudSyncStatus.value = "❌ Could not remove photo completely"
            }
        }
    }

    fun refreshCloudData() {
        viewModelScope.launch {
            // 1. Immediately restore from local preferences if current in-memory profile is blank
            if (_userProfile.value.fullName.isBlank()) {
                val localSaved = loadLocalUserProfile(sharedPrefs)
                if (localSaved.fullName.isNotBlank()) {
                    _userProfile.value = localSaved
                } else {
                    val app = getApplication<android.app.Application>()
                    val legacy = loadLocalUserProfile(app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE))
                    if (legacy.fullName.isNotBlank()) {
                        _userProfile.value = legacy
                        saveProfileToLocalPrefs(legacy)
                    }
                }
            }

            // 2. Immediately restore connections from local database
            launch(Dispatchers.IO) {
                try {
                    val localEntities = connectionDao.getAllConnectionsList()
                    if (localEntities.isNotEmpty()) {
                        _connectionsList.value = localEntities.map { it.toContact() }
                    }
                } catch (_: Exception) {}
            }

            // Firebase Auth should already contain the persistent verified user after OTP login.
            // Never create an anonymous identity during normal app refresh, because that can split
            // one account into multiple backend identities and break message/profile persistence.
            val currentId = getCurrentUserId()
            if (realtimeListenersStarted) {
                _cloudSyncStatus.value = "⚡ Live Cloud Sync Active"
                return@launch
            }
            realtimeListenersStarted = true

            // If local profile is still blank, restore it from Firestore by ID, email, or username before listening to feeds
            if (_userProfile.value.fullName.isBlank()) {
                withContext(Dispatchers.IO) {
                    try {
                        val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                        var doc = db.collection("netero_profiles").document(currentId).get().await()
                        if (!doc.exists() && _userProfile.value.username.isNotBlank()) {
                            doc = db.collection("netero_profiles").document(_userProfile.value.username).get().await()
                        }
                        if (!doc.exists()) {
                            val app = getApplication<android.app.Application>()
                            val p1Email = app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE).getString("user_email", "") ?: ""
                            val p2Email = app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).getString("user_email", "") ?: ""
                            val authEmail = FirebaseAuth.getInstance().currentUser?.email ?: ""
                            val emailToLookup = authEmail.ifBlank { p1Email.ifBlank { p2Email } }
                            if (emailToLookup.isNotBlank()) {
                                var query = db.collection("netero_profiles").whereEqualTo("email", emailToLookup.trim().lowercase()).limit(1).get().await()
                                if (query.isEmpty) {
                                    query = db.collection("netero_profiles").whereEqualTo("email", emailToLookup.trim()).limit(1).get().await()
                                }
                                if (!query.isEmpty) {
                                    doc = query.documents.first()
                                } else {
                                    val all = db.collection("netero_profiles").limit(50).get().await()
                                    val match = all.documents.firstOrNull { d ->
                                        val e = d.getString("email") ?: ""
                                        e.trim().equals(emailToLookup.trim(), ignoreCase = true)
                                    }
                                    if (match != null) doc = match
                                }
                            }
                        }
                        if (doc != null && doc.exists()) {
                            val restored = cloudSyncManager.parseUserProfile(doc)
                            if (restored.fullName.isNotBlank()) {
                                _userProfile.value = restored
                                saveProfileToLocalPrefs(restored)
                            }
                        }
                    } catch (_: Exception) {}
                }
            }

            // Sync the current FCM token under the Firebase Auth UID (on real devices with Google Play Services).
            val isEmulatorDevice = android.os.Build.FINGERPRINT.startsWith("generic")
                || android.os.Build.FINGERPRINT.startsWith("unknown")
                || android.os.Build.MODEL.contains("google_sdk")
                || android.os.Build.MODEL.contains("Emulator")
                || android.os.Build.MODEL.contains("Android SDK built for x86")
                || android.os.Build.MODEL.contains("Cuttlefish")
                || android.os.Build.HARDWARE.contains("goldfish")
                || android.os.Build.HARDWARE.contains("ranchu")
                || android.os.Build.HARDWARE.contains("vsoc")
                || android.os.Build.HARDWARE.contains("cutf")
                || android.os.Build.PRODUCT.contains("sdk")
                || android.os.Build.PRODUCT.contains("cuttlefish")
                || android.os.Build.PRODUCT.contains("cf_")
                || android.os.Build.DEVICE.contains("vsoc")
                || android.os.Build.DEVICE.contains("cutf")

            if (!isEmulatorDevice) {
                try {
                    val gApi = com.google.android.gms.common.GoogleApiAvailability.getInstance()
                    val playServicesOk = gApi.isGooglePlayServicesAvailable(getApplication()) == com.google.android.gms.common.ConnectionResult.SUCCESS
                    if (playServicesOk) {
                        val token = com.google.firebase.messaging.FirebaseMessaging.getInstance().token.await()
                        if (token.isNotBlank()) {
                            val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                            db.collection("users").document(currentId).set(
                                mapOf("fcmToken" to token, "fcmTokenUpdatedAt" to System.currentTimeMillis()),
                                com.google.firebase.firestore.SetOptions.merge()
                            ).await()
                            db.collection("netero_profiles").document(currentId).set(
                                mapOf("fcmToken" to token, "authUid" to currentId),
                                com.google.firebase.firestore.SetOptions.merge()
                            ).await()
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.d("NeteroViewModel", "FCM token not available: ${e.message}")
                }
            }

            // Only sync local profile to cloud if local profile actually has user data
            if (_userProfile.value.fullName.isNotBlank()) {
                cloudSyncManager.syncProfileToCloud(currentId, _userProfile.value)
            }
            
            // Start listening to the cloud profile (live updates)
            launch {
                cloudSyncManager.listenToUserProfile(currentId).collect { remoteProfile ->
                    if (remoteProfile != null && remoteProfile.fullName.isNotBlank()) {
                        _userProfile.value = remoteProfile
                        saveProfileToLocalPrefs(remoteProfile)
                    }
                }
            }
            if (_userProfile.value.username.isNotBlank() && _userProfile.value.username != currentId) {
                launch {
                    cloudSyncManager.listenToUserProfile(_userProfile.value.username).collect { remoteProfile ->
                        if (remoteProfile != null && remoteProfile.fullName.isNotBlank()) {
                            _userProfile.value = remoteProfile
                            saveProfileToLocalPrefs(remoteProfile)
                        }
                    }
                }
            }

            launch(Dispatchers.IO) { cloudSyncManager.cleanCorruptProfiles() }
            launch { fetchSupportTickets() }

            launch { 
                cloudSyncManager.listenToDiscoverFeed(currentId, _userProfile.value.username, _userProfile.value.email).collect { feed -> 
                    val myIds = _userProfile.value.connectionIds.toSet()
                    val myUsername = _userProfile.value.username.trim().lowercase()
                    val myFullName = _userProfile.value.fullName.trim().lowercase()
                    val myEmail = _userProfile.value.email.trim().lowercase()
                    val updatedFeed = feed.filter { 
                        (myUsername.isBlank() || it.username.trim().lowercase() != myUsername) && 
                        (myFullName.isBlank() || !it.name.trim().equals(myFullName, ignoreCase = true)) &&
                        (myEmail.isBlank() || (it.email?.isNotBlank() == true && !it.email.trim().equals(myEmail, ignoreCase = true))) &&
                        it.id != currentId && 
                        !isAlreadyConnected(it) &&
                        it.name.isNotBlank() && 
                        it.name.trim() != "." && 
                        it.name.trim() != ".." &&
                        it.name.length >= 2 &&
                        it.name.any { char -> char.isLetter() }
                    }.map { person -> 
                        val mutualCount = person.connectionIds.intersect(myIds).size
                        person.copy(
                            mutualConnectionsCount = mutualCount, 
                            matchReason = if (mutualCount > 0) "Industry Match • $mutualCount Mutual Connections" else "Industry Match"
                        ) 
                    }
                    _recommendedPeople.value = updatedFeed
                    checkAndRun24hAiCuration()
                } 
            }
            var isInitialRequestLoad = true
            val handleRequests: (List<com.example.ui.viewmodel.ConnectionRequest>) -> Unit = { requests ->
                val validRequests = requests.filter { r ->
                    r.senderName.isNotBlank() && 
                    r.senderName.trim() != "." && 
                    r.senderName.trim() != ".." && 
                    r.senderName.length >= 2 && 
                    r.senderName.any { char -> char.isLetter() }
                }
                _connectionRequests.update { cur -> (cur + validRequests).distinctBy { it.id } }
                if (isInitialRequestLoad) {
                    validRequests.forEach { processedNotificationRequestIds.add(it.id) }
                    isInitialRequestLoad = false
                } else {
                    val newOnes = validRequests.filter { processedNotificationRequestIds.add(it.id) }
                    newOnes.forEach { req ->
                        com.example.utils.NotificationHelper.showConnectionRequestNotification(
                            context = getApplication(),
                            senderName = req.senderName,
                            senderTitle = req.senderTitle,
                            requestId = req.id
                        )
                    }
                }
            }

            launch { 
                cloudSyncManager.listenToConnectionRequests(currentId).collect { handleRequests(it) }
            }
            if (_userProfile.value.username.isNotBlank() && _userProfile.value.username != currentId) {
                launch {
                    cloudSyncManager.listenToConnectionRequests(_userProfile.value.username).collect { handleRequests(it) }
                }
            }
            val activeUidForReq = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
            if (!activeUidForReq.isNullOrBlank() && activeUidForReq != currentId && activeUidForReq != _userProfile.value.username) {
                launch {
                    cloudSyncManager.listenToConnectionRequests(activeUidForReq).collect { handleRequests(it) }
                }
            }

            launch(Dispatchers.IO) {
                cloudSyncManager.listenToConnections(currentId).collect { remoteConnections ->
                    if (remoteConnections.isNotEmpty()) {
                        remoteConnections.forEach { contact ->
                            connectionDao.insertConnection(contact.toEntity())
                        }
                        _connectionsList.update { currentList ->
                            val map = currentList.associateBy { it.id }.toMutableMap()
                            remoteConnections.forEach { rc ->
                                map[rc.id] = rc
                            }
                            map.values.toList()
                        }
                        _recommendedPeople.update { list ->
                            list.filterNot { person ->
                                remoteConnections.any { it.id == person.id || it.name.equals(person.name, ignoreCase = true) || (it.email.isNotBlank() && it.email.equals(person.email, ignoreCase = true)) }
                            }
                        }
                    }
                }
            }
            if (_userProfile.value.username.isNotBlank() && _userProfile.value.username != currentId) {
                launch(Dispatchers.IO) {
                    cloudSyncManager.listenToConnections(_userProfile.value.username).collect { remoteConnections ->
                        if (remoteConnections.isNotEmpty()) {
                            remoteConnections.forEach { contact ->
                                connectionDao.insertConnection(contact.toEntity())
                            }
                            _connectionsList.update { currentList ->
                                val map = currentList.associateBy { it.id }.toMutableMap()
                                remoteConnections.forEach { rc ->
                                    map[rc.id] = rc
                                }
                                map.values.toList()
                            }
                            _recommendedPeople.update { list ->
                                list.filterNot { person ->
                                    remoteConnections.any { it.id == person.id || it.name.equals(person.name, ignoreCase = true) || (it.email.isNotBlank() && it.email.equals(person.email, ignoreCase = true)) }
                                }
                            }
                        }
                    }
                }
            }

            val activeUidForConn = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid
            if (!activeUidForConn.isNullOrBlank() && activeUidForConn != currentId && activeUidForConn != _userProfile.value.username) {
                launch(Dispatchers.IO) {
                    cloudSyncManager.listenToConnections(activeUidForConn).collect { remoteConnections ->
                        if (remoteConnections.isNotEmpty()) {
                            remoteConnections.forEach { contact ->
                                connectionDao.insertConnection(contact.toEntity())
                            }
                            _connectionsList.update { currentList ->
                                val map = currentList.associateBy { it.id }.toMutableMap()
                                remoteConnections.forEach { rc ->
                                    map[rc.id] = rc
                                }
                                map.values.toList()
                            }
                            _recommendedPeople.update { list ->
                                list.filterNot { person ->
                                    remoteConnections.any { 
                                        it.id == person.id || 
                                        it.name.equals(person.name, ignoreCase = true) || 
                                        (it.email.isNotBlank() && it.email.equals(person.email, ignoreCase = true)) ||
                                        (person.username.isNotBlank() && it.id.equals(person.username, ignoreCase = true))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Continuous Real-Time Profile Live-Sync for all existing connections
            // Automatically updates contact's name (e.g. Rahul -> Rahul Reddy), company, title, industry, or details without needing to re-scan
            launch(Dispatchers.IO) {
                cloudSyncManager.listenToAllProfiles().collect { allProfiles ->
                    if (allProfiles.isNotEmpty()) {
                        val currentConnections = _connectionsList.value
                        val profilesById = allProfiles.filter { it.id.isNotBlank() }.associateBy { it.id.lowercase() }
                        val profilesByUsername = allProfiles.filter { it.username.isNotBlank() }.associateBy { it.username.lowercase() }
                        val profilesByEmail = allProfiles.filter { it.email.isNotBlank() }.associateBy { it.email.lowercase() }
                        val profilesByPhone = allProfiles.filter { it.phone.isNotBlank() }.associateBy { it.phone.replace(Regex("[^0-9+]"), "") }
                        // Only use a name fallback when that name is unique; otherwise a
                        // shared name could update the wrong saved connection. Stable UID,
                        // username, email, and phone matches remain preferred.
                        val uniqueProfilesByName = allProfiles
                            .filter { it.fullName.isNotBlank() }
                            .groupBy { it.fullName.trim().lowercase() }
                            .filterValues { it.size == 1 }
                            .mapValues { it.value.first() }

                        currentConnections.forEach { contact ->
                            val cleanContactPhone = contact.phone.replace(Regex("[^0-9+]"), "")
                            val cleanContactId = contact.id.removePrefix("c_").removePrefix("req_").lowercase()
                            val noteUid = Regex("UID:([a-zA-Z0-9_.-]+)").find(contact.notes)?.groupValues?.get(1)?.lowercase()
                            val noteUser = Regex("USER:([a-zA-Z0-9_.-]+)").find(contact.notes)?.groupValues?.get(1)?.lowercase()

                            val matchingProfile = profilesById[cleanContactId]
                                ?: profilesByUsername[cleanContactId]
                                ?: (if (noteUid != null) profilesById[noteUid] ?: profilesByUsername[noteUid] else null)
                                ?: (if (noteUser != null) profilesByUsername[noteUser] ?: profilesById[noteUser] else null)
                                ?: (if (contact.email.isNotBlank()) profilesByEmail[contact.email.lowercase()] else null)
                                ?: (if (cleanContactPhone.isNotBlank()) profilesByPhone[cleanContactPhone] else null)
                                ?: uniqueProfilesByName[contact.name.trim().lowercase()]

                            if (matchingProfile != null) {
                                val newName = matchingProfile.fullName.ifBlank { contact.name }
                                val newTitle = matchingProfile.jobTitle.ifBlank { contact.jobTitle }
                                val newCompany = matchingProfile.company.ifBlank { contact.company }
                                val newEmail = matchingProfile.email.ifBlank { contact.email }
                                val newPhone = matchingProfile.phone.ifBlank { contact.phone }
                                val newLinkedin = matchingProfile.linkedinUrl.ifBlank { contact.linkedin }
                                val newIndustry = matchingProfile.industry

                                val updatedTags = if (newIndustry.isNotBlank() && !contact.tags.contains(newIndustry)) {
                                    val base = contact.tags.filter { it == contact.source || it == "QR" }
                                    (base + newIndustry).distinct()
                                } else {
                                    contact.tags
                                }

                                val hasChanged = contact.name != newName ||
                                        contact.jobTitle != newTitle ||
                                        contact.company != newCompany ||
                                        contact.email != newEmail ||
                                        contact.phone != newPhone ||
                                        contact.linkedin != newLinkedin ||
                                        (newIndustry.isNotBlank() && !contact.tags.contains(newIndustry))

                                if (hasChanged) {
                                    val updatedContact = contact.copy(
                                        name = newName,
                                        jobTitle = newTitle,
                                        company = newCompany,
                                        email = newEmail,
                                        phone = newPhone,
                                        linkedin = newLinkedin,
                                        tags = updatedTags,
                                        avatarInitial = newName.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }.mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString("").ifBlank { newName.take(2).uppercase() }
                                    )
                                    connectionDao.updateConnection(updatedContact.toEntity())
                                    cloudSyncManager.syncConnectionToCloud(currentId, updatedContact)
                                }
                            }
                        }
                    }
                }
            }
            launch { cloudSyncManager.listenToProfileViews(currentId).collect { _profileViews.value = it } }
            launch { cloudSyncManager.listenToNotifications(currentId).collect { _notifications.value = it } }

            // Start listening to AI messages
            launch {
                cloudSyncManager.listenToAiMessages(currentId).collect { remoteMsgs ->
                    if (remoteMsgs.isNotEmpty()) {
                        _aiAssistantMessages.value = listOf(
                            AiAssistantMessage(
                                text = "Hello! 👋 I'm your Asteron AI Assistant. Ask me anything about networking strategies, startup elevator pitches, cold emails, resume feedback, or tech event icebreakers!",
                                isFromUser = false
                            )
                        ) + remoteMsgs
                    }
                }
            }
            // Start listening to chat messages
            launch {
                cloudSyncManager.listenToChatMessages(currentId).collect { remoteMessages ->
                    _chatMessages.update { map ->
                        val newMap = map.toMutableMap()
                        val currentConns = _connectionsList.value
                        remoteMessages.groupBy { it.contactId }.forEach { (senderContactId, msgs) ->
                            val current = newMap[senderContactId] ?: emptyList()
                            val combined = (msgs + current).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                            newMap[senderContactId] = combined

                            // Also index under the recipient's local contact ID for that sender if different
                            val matchingContact = currentConns.find { 
                                it.id == senderContactId || 
                                it.id.removePrefix("c_").removePrefix("req_") == senderContactId.removePrefix("c_").removePrefix("req_") ||
                                (it.notes.contains("UID:$senderContactId")) ||
                                (it.notes.contains("USER:$senderContactId"))
                            }
                            if (matchingContact != null && matchingContact.id != senderContactId) {
                                val currentForLocalId = newMap[matchingContact.id] ?: emptyList()
                                newMap[matchingContact.id] = (msgs + currentForLocalId).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                            }
                        }
                        newMap
                    }
                }
            }
            if (_userProfile.value.username.isNotBlank() && _userProfile.value.username != currentId) {
                launch {
                    cloudSyncManager.listenToChatMessages(_userProfile.value.username).collect { remoteMessages ->
                        _chatMessages.update { map ->
                            val newMap = map.toMutableMap()
                            val currentConns = _connectionsList.value
                            remoteMessages.groupBy { it.contactId }.forEach { (senderContactId, msgs) ->
                                val current = newMap[senderContactId] ?: emptyList()
                                val combined = (msgs + current).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                                newMap[senderContactId] = combined

                                val matchingContact = currentConns.find { 
                                    it.id == senderContactId || 
                                    it.id.removePrefix("c_").removePrefix("req_") == senderContactId.removePrefix("c_").removePrefix("req_") ||
                                    (it.notes.contains("UID:$senderContactId")) ||
                                    (it.notes.contains("USER:$senderContactId"))
                                }
                                if (matchingContact != null && matchingContact.id != senderContactId) {
                                    val currentForLocalId = newMap[matchingContact.id] ?: emptyList()
                                    newMap[matchingContact.id] = (msgs + currentForLocalId).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                                }
                            }
                            newMap
                        }
                    }
                }
            }
            val activeAuthUid = FirebaseAuth.getInstance().currentUser?.uid
            if (!activeAuthUid.isNullOrBlank() && activeAuthUid != currentId && activeAuthUid != _userProfile.value.username) {
                launch {
                    cloudSyncManager.listenToChatMessages(activeAuthUid).collect { remoteMessages ->
                        _chatMessages.update { map ->
                            val newMap = map.toMutableMap()
                            val currentConns = _connectionsList.value
                            remoteMessages.groupBy { it.contactId }.forEach { (senderContactId, msgs) ->
                                val current = newMap[senderContactId] ?: emptyList()
                                val combined = (msgs + current).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                                newMap[senderContactId] = combined

                                val matchingContact = currentConns.find { 
                                    it.id == senderContactId || 
                                    it.id.removePrefix("c_").removePrefix("req_") == senderContactId.removePrefix("c_").removePrefix("req_") ||
                                    (it.notes.contains("UID:$senderContactId")) ||
                                    (it.notes.contains("USER:$senderContactId"))
                                }
                                if (matchingContact != null && matchingContact.id != senderContactId) {
                                    val currentForLocalId = newMap[matchingContact.id] ?: emptyList()
                                    newMap[matchingContact.id] = (msgs + currentForLocalId).distinctBy { it.id }.sortedBy { it.sentAtMillis }
                                }
                            }
                            newMap
                        }
                    }
                }
            }
            // Start listening to live rooms
            launch {
                val currentName = _userProfile.value.fullName.trim()
                val currentUsername = _userProfile.value.username.trim()
                cloudSyncManager.listenToRooms().collect { remoteRooms ->
                    _roomsList.update { localRooms ->
                        val localMap = localRooms.associateBy { it.id }
                        remoteRooms.map { remote ->
                            val local = localMap[remote.id]
                            val isMember = remote.adminId == currentId || 
                                (currentUsername.isNotBlank() && remote.adminId.equals(currentUsername, ignoreCase = true)) ||
                                remote.members.any { m ->
                                    m.id == currentId || 
                                    (currentUsername.isNotBlank() && m.id.equals(currentUsername, ignoreCase = true)) ||
                                    (currentName.isNotBlank() && m.name.equals(currentName, ignoreCase = true))
                                } ||
                                remote.speakers.any { s ->
                                    s.id == currentId ||
                                    (currentUsername.isNotBlank() && s.id.equals(currentUsername, ignoreCase = true)) ||
                                    (currentName.isNotBlank() && s.name.equals(currentName, ignoreCase = true))
                                } || (local?.isJoined == true)
                            val isReq = remote.joinRequests.any { it.id == currentId || (currentUsername.isNotBlank() && it.id == currentUsername) }
                            val isCreated = remote.adminId == currentId || (currentUsername.isNotBlank() && remote.adminId.equals(currentUsername, ignoreCase = true))
                            remote.copy(
                                isJoined = isMember,
                                isJoinRequested = isReq,
                                isCreatedByMe = isCreated,
                                discussions = if (remote.discussions.isNotEmpty()) remote.discussions else (local?.discussions ?: emptyList())
                            )
                        }
                    }
                }
            }

            _cloudSyncStatus.value = "⚡ Live Cloud Sync Active"
        }
    }

    init {
        // Load from local storage first (Persistent MVP)
        val prefs = application.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
        val savedName = prefs.getString("profile_name", "") ?: ""
        if (savedName.isNotBlank()) {
            _userProfile.update { it.copy(
                fullName = savedName,
                username = prefs.getString("profile_username", "") ?: "",
                headline = prefs.getString("profile_headline", "") ?: "",
                isStudent = prefs.getBoolean("profile_is_student", false),
                jobTitle = prefs.getString("profile_title", "") ?: "",
                company = prefs.getString("profile_company", "") ?: "",
                industry = prefs.getString("profile_industry", "") ?: "",
                bio = prefs.getString("profile_bio", "") ?: "",
                location = prefs.getString("profile_location", "") ?: "",
                phone = prefs.getString("profile_phone", "") ?: "",
                email = prefs.getString("profile_email", "") ?: "",
                dateOfBirth = prefs.getString("profile_dob", "") ?: "",
                website = prefs.getString("profile_website", "") ?: "",
                businessUrl = prefs.getString("profile_business", "") ?: "",
                portfolioUrl = prefs.getString("profile_portfolio", "") ?: "",
                linkedinUrl = prefs.getString("profile_linkedin", "") ?: "",
                neteroLock = NeteroLockSettings(
                    phoneVisibility = PrivacyLevel.valueOf(prefs.getString("lock_phone", PrivacyLevel.CONNECTIONS_ONLY.name) ?: PrivacyLevel.CONNECTIONS_ONLY.name),
                    emailVisibility = PrivacyLevel.valueOf(prefs.getString("lock_email", PrivacyLevel.CONNECTIONS_ONLY.name) ?: PrivacyLevel.CONNECTIONS_ONLY.name),
                    socialVisibility = PrivacyLevel.valueOf(prefs.getString("lock_social", PrivacyLevel.PUBLIC.name) ?: PrivacyLevel.PUBLIC.name),
                    profileDiscovery = PrivacyLevel.valueOf(prefs.getString("lock_profile", PrivacyLevel.PUBLIC.name) ?: PrivacyLevel.PUBLIC.name),
                    portfolioVisibility = PrivacyLevel.valueOf(prefs.getString("lock_portfolio", PrivacyLevel.PUBLIC.name) ?: PrivacyLevel.PUBLIC.name),
                    roomVisibility = prefs.getBoolean("lock_room", true)
                )
            )}
        }

        refreshCloudData()
        startLiveSyncForConnections()
    }

    fun askAiAnything(prompt: String) {
        if (prompt.isBlank() || _isAiThinking.value) return
        val userMsg = AiAssistantMessage(text = prompt, isFromUser = true)
        _aiAssistantMessages.update { it + userMsg }
        viewModelScope.launch { cloudSyncManager.syncAiMessageToCloud(getCurrentUserId(), java.util.UUID.randomUUID().toString(), prompt, true) }
        _isAiThinking.value = true

        viewModelScope.launch {
            val userProfileData = _userProfile.value
            val currentUid = getCurrentUserId()

            // 1. Analyze the question intent & update learned behavioral profile
            val intentObj = try {
                com.example.data.api.GeminiAiHelper.analyzeQuestionIntent(prompt)
            } catch (e: Exception) {
                org.json.JSONObject()
            }
            val inquiredPersonName = intentObj.optString("personName").trim()
            val detectedIndustries = (0 until (intentObj.optJSONArray("industries")?.length() ?: 0))
                .mapNotNull { intentObj.optJSONArray("industries")?.optString(it) }
            val detectedRoles = (0 until (intentObj.optJSONArray("roles")?.length() ?: 0))
                .mapNotNull { intentObj.optJSONArray("roles")?.optString(it) }
            val detectedKeywords = (0 until (intentObj.optJSONArray("keywords")?.length() ?: 0))
                .mapNotNull { intentObj.optJSONArray("keywords")?.optString(it) }

            // Update learned behavior in background
            val currentLearned = _aiLearnedProfile.value
            val updatedSearches = (listOf(prompt) + currentLearned.recentSearchQueries.filter { !it.equals(prompt, ignoreCase = true) }).take(10)
            val updatedIndustries = (currentLearned.targetIndustries + detectedIndustries).distinct().take(15)
            val updatedInterests = (currentLearned.learnedInterests + detectedKeywords).distinct().take(25)
            val updatedRoles = (currentLearned.targetRoles + detectedRoles).distinct().take(10)
            val newLearnedProfile = currentLearned.copy(
                recentSearchQueries = updatedSearches,
                targetIndustries = updatedIndustries,
                learnedInterests = updatedInterests,
                targetRoles = updatedRoles
            )
            saveAiLearnedProfile(newLearnedProfile)

            // 2. Comprehensive Profile Discovery Across All Registered & Cloud Members
            val cloudProfiles = try { cloudSyncManager.searchUsers("") } catch (e: Exception) { emptyList() }
            val directCloudProfiles = try {
                val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                // Asteron should consider the full current Netero member set, not a fixed first-page cap.
                val snap = db.collection("netero_profiles").get().await()
                snap.documents.mapNotNull { doc ->
                    val authUid = doc.getString("authUid")?.trim()
                    if (authUid.isNullOrBlank() || doc.id != authUid) return@mapNotNull null
                    val p = cloudSyncManager.parseUserProfile(doc)
                    if (p.fullName.isNotBlank() && p.fullName.length >= 2 && p.fullName.any { it.isLetter() }) {
                        com.example.data.model.RecommendedPerson(
                            id = doc.id,
                            name = p.fullName,
                            username = p.username,
                            jobTitle = p.jobTitle,
                            company = p.company,
                            industry = p.industry,
                            location = p.location,
                            bio = p.bio,
                            sharedInterests = p.interests + p.skills,
                            email = p.email.takeIf { it.isNotBlank() },
                            phone = p.phone.takeIf { it.isNotBlank() },
                            linkedinUrl = p.linkedinUrl.takeIf { it.isNotBlank() },
                            portfolioUrl = p.portfolioUrl.takeIf { it.isNotBlank() },
                            website = p.website.takeIf { it.isNotBlank() },
                            businessUrl = p.businessUrl.takeIf { it.isNotBlank() },
                            asteronResearchSummary = (doc.get("asteronResearch") as? Map<*, *>)?.get("summary")?.toString() ?: "",
                            avatarInitial = p.fullName.take(2).uppercase()
                        )
                    } else null
                }
            } catch (_: Exception) { emptyList() }
            val localRecommended = _recommendedPeople.value
            
            val allAvailableMembers = (directCloudProfiles + cloudProfiles + localRecommended).distinctBy { 
                if (it.id.isNotBlank()) it.id else it.username.ifBlank { it.name.lowercase() }
            }.filter { p ->
                !isSelfCandidate(p.id, p.username, p.name, p.email, p.phone, userProfileData, currentUid) &&
                p.name.isNotBlank() && p.name.trim() != "." && p.name.length >= 2 && p.name.any { it.isLetter() }
            }

            // Check if user specifically asked about someone by name or username or company or domain tokens
            val promptLower = prompt.lowercase()
            val stopWords = setOf("find", "from", "who", "is", "working", "in", "at", "the", "and", "app", "can", "you", "tell", "me", "about", "for", "with", "there", "someone", "person")
            val promptTokens = promptLower.split(Regex("[^a-zA-Z0-9]+")).filter { it.length >= 2 && it !in stopWords }

            val targetPersonMatches = allAvailableMembers.filter { p ->
                val pNameLower = p.name.lowercase()
                val pUserLower = p.username.lowercase()
                val pCompLower = p.company.lowercase()
                val pIndLower = p.industry.lowercase()
                val pBioLower = p.bio.lowercase()
                val pSkillsLower = p.sharedInterests.joinToString(" ").lowercase()

                val directNameMatch = inquiredPersonName.isNotBlank() && (pNameLower.contains(inquiredPersonName.lowercase()) || pUserLower.contains(inquiredPersonName.lowercase()))
                val tokenMatches = promptTokens.count { t ->
                    pNameLower.contains(t) || pUserLower.contains(t) || pCompLower.contains(t) || pIndLower.contains(t) || pBioLower.contains(t) || pSkillsLower.contains(t)
                }
                directNameMatch || tokenMatches >= 1 || promptLower.contains(pNameLower) || (p.username.isNotBlank() && promptLower.contains(pUserLower))
            }.sortedByDescending { p ->
                val pText = "${p.name} ${p.username} ${p.company} ${p.industry} ${p.jobTitle} ${p.bio}".lowercase()
                promptTokens.count { t -> pText.contains(t) }
            }

            val myConnections = _connectionsList.value
            val connectionMatches = myConnections.filter { c ->
                val cText = "${c.name} ${c.jobTitle} ${c.company} ${c.notes}".lowercase()
                (inquiredPersonName.isNotBlank() && cText.contains(inquiredPersonName.lowercase())) ||
                promptTokens.any { t -> cText.contains(t) } ||
                promptLower.contains(c.name.lowercase())
            }

            // Build targeted profile dossier if user is inquiring about a specific person or profile
            val targetedPersonDossier = buildString {
                if (targetPersonMatches.isNotEmpty() || connectionMatches.isNotEmpty()) {
                    append("🌟 SPECIFIC PROFILES INQUIRED ABOUT / MATCHED FOR USER:\n")
                    targetPersonMatches.take(10).forEach { p ->
                        append("- [REGISTERED USER] Name: ${p.name} (@${p.username}) | Title: ${p.jobTitle} | Company: ${p.company} | Industry/Domain: ${p.industry} | Location: ${p.location} | Skills/Interests: ${p.sharedInterests.joinToString(", ")} | Bio: ${p.bio} | Connection Status: ${p.status} | LinkedIn: ${p.linkedinUrl ?: "N/A"} | Portfolio: ${p.portfolioUrl ?: "N/A"} | Website: ${p.website ?: "N/A"} | Business/Company URL: ${p.businessUrl ?: "N/A"} | Asteron Public Research: ${p.asteronResearchSummary.ifBlank { "Not researched yet" }}\n")
                    }
                    connectionMatches.take(5).forEach { c ->
                        append("- [SAVED CONNECTION IN USER'S NETWORK] Name: ${c.name} | Role: ${c.jobTitle} | Company: ${c.company} | Notes: ${c.notes} | Location Met: ${c.locationMet} | Source: ${c.source}\n")
                    }
                }
            }

            // Relevant candidates for industry/query
            val industryOrTopicMatches = allAvailableMembers.filter { p ->
                detectedIndustries.any { ind -> p.industry.contains(ind, ignoreCase = true) || p.bio.contains(ind, ignoreCase = true) } ||
                detectedRoles.any { role -> p.jobTitle.contains(role, ignoreCase = true) } ||
                detectedKeywords.any { kw -> p.name.contains(kw, ignoreCase = true) || p.company.contains(kw, ignoreCase = true) || p.bio.contains(kw, ignoreCase = true) || p.sharedInterests.any { it.contains(kw, ignoreCase = true) } }
            }

            val prioritizedProfiles = (targetPersonMatches + industryOrTopicMatches + allAvailableMembers).distinctBy { it.id }.take(50)

            val profilesContext = if (prioritizedProfiles.isNotEmpty()) {
                "CURRENT REGISTERED MEMBERS ON NETERO FOR MATCHMAKING:\n" +
                prioritizedProfiles.joinToString("\n") { p ->
                    "- Name: ${p.name} | Title: ${p.jobTitle} | Company: ${p.company} | Industry: ${p.industry} | Location: ${p.location} | Skills/Interests: ${p.sharedInterests.joinToString(", ")} | Bio: ${p.bio}"
                }
            } else {
                "No other members currently registered in the database."
            }

            val connectionsContext = if (myConnections.isNotEmpty()) {
                "CURRENT SAVED CONNECTIONS IN MY NETWORK:\n" +
                myConnections.take(30).joinToString("\n") { c ->
                    val ind = c.tags.firstOrNull { it != "QR" && it != c.source }
                        ?: (if (c.notes.contains("INDUSTRY:")) Regex("INDUSTRY:([^|]+)").find(c.notes)?.groupValues?.get(1)?.trim() else null)
                        ?: "General"
                    "- Name: ${c.name} | Role: ${c.jobTitle} | Company: ${c.company} | Industry: $ind | Notes: ${c.notes} | Location Met: ${c.locationMet}"
                }
            } else {
                "No saved connections yet."
            }

            val userLearnedBehaviorContext = buildString {
                if (newLearnedProfile.targetIndustries.isNotEmpty()) {
                    append("User Inquires Frequently About Industries: ${newLearnedProfile.targetIndustries.joinToString(", ")}\n")
                }
                if (newLearnedProfile.recentSearchQueries.isNotEmpty()) {
                    append("Recent Search Inquiries: ${newLearnedProfile.recentSearchQueries.take(5).joinToString(" | ")}\n")
                }
                if (newLearnedProfile.aiNetworkingPersona.isNotBlank()) {
                    append("User's AI Persona: ${newLearnedProfile.aiNetworkingPersona}\n")
                }
            }

            val systemContext = """
You are Asteron AI, an intelligent, conversational, and highly efficient proprietary networking AI copilot created by Asteron.
You are Asteron's native intelligence engine. Under no circumstances should you ever mention Gemini, Google, OpenAI, or external models. You are Asteron AI.
You work for Asteron, the premier professional networking ecosystem.

CURRENT USER PROFILE:
- Name: ${userProfileData.fullName}
- Title: ${userProfileData.jobTitle} at ${userProfileData.company}
- Industry: ${userProfileData.industry}
- Location: ${userProfileData.location}
- Bio: ${userProfileData.bio}
- Skills: ${userProfileData.skills.joinToString(", ")}
- Interests: ${userProfileData.interests.joinToString(", ")}
- LinkedIn: ${userProfileData.linkedinUrl.ifBlank { "N/A" }}
- Portfolio: ${userProfileData.portfolioUrl.ifBlank { "N/A" }}
- Personal Website: ${userProfileData.website.ifBlank { "N/A" }}
- Business/Company URL: ${userProfileData.businessUrl.ifBlank { "N/A" }}

USER'S LEARNED BEHAVIOR & SEARCH HISTORY:
$userLearnedBehaviorContext

$targetedPersonDossier

$profilesContext

$connectionsContext

CORE MISSION & INTELLIGENCE MANDATE (90%+ NETWORKING & PROFESSIONAL SYNERGY):
1. SPECIFIC PERSON PROFILE INQUIRIES & DOSSIERS (TOP PRIORITY):
   - When the user asks to find someone, lookup someone, or asks about any person (e.g. 'find Rohan from SAS who's working in Infosys', 'Tell me about Alex', 'Look up Sarah from Google'):
     Review all profiles in SPECIFIC PROFILES INQUIRED ABOUT / MATCHED FOR USER and CURRENT REGISTERED MEMBERS above.
     If a matching person is found:
       • Provide their EXACT profile clearly using clean, structured formatting:
         🎯 **Profile Found on Netero**:
         • 👤 **Full Name**: [Name] (@[username])
         • 💼 **Role & Company**: [Title] at [Company]
         • 🏢 **Industry / Field**: [Industry]
         • 📍 **Location**: [Location]
         • 💡 **Bio & Expertise**: [Bio summary, key skills]
         • 🤝 **Status & How to Connect**: State that they are registered on Netero, and tell the user they can search for their name in the Discover tab and tap Connect!
       • Provide 2 personalized, high-response conversation starters or icebreakers the user can send to them.
     If no exact match exists:
       • State that they aren't registered under that exact name, and present the closest professionals in that company, domain, or industry on Netero.

2. SMART INDUSTRY & OPPORTUNITY MATCHMAKING:
   - When the user asks to find people in any industry, event, company, or domain (e.g. 'I am looking for people from SaaS', 'Suggest fintech founders', 'Who can help with marketing/engineering?'):
     Carefully review all registered members.
     Select the most relevant individuals.
     For each recommended person:
       • **Name**, Title & Organization
       • **Why they are a great match** for the user's goals
       • **Recommended icebreaker message** they can use to connect on Netero!

3. PUBLIC PROFESSIONAL RESEARCH & LINK ANALYSIS:
   - When a Netero profile contains a LinkedIn URL, portfolio URL, personal website, GitHub or business/company URL, use the public web information available from those links when relevant.
   - Treat Netero profile fields as user-supplied facts and web findings as externally researched information. Never invent details or imply that a private page was accessed.
   - When the user asks whether another person is relevant or worth connecting with, compare that person's public professional information with the current user's role, skills, interests, goals, learned behavior and Netero context. Explain the concrete overlap and any important gaps.

4. JOB & OPPORTUNITY INTELLIGENCE:
   - When the user provides a job description, job URL, company URL, or asks whether a job is relevant, analyze the role against the user's Netero profile and any public portfolio/website/GitHub information.
   - Explain fit, strongest matching evidence, missing requirements or considerations, and what the user could strengthen before applying. Do not make up qualifications.
   - When the user asks to find jobs or opportunities, use current public web research and prioritize roles that align with the user's profile, interests, learned searches and stated goals. Include the source/company/role details when available.
   - When researching a company, analyze its public website and other relevant public sources for what it does, the opportunity, and why it may or may not align with the user.

5. CONVERSATIONAL PERSONAL ASSISTANT & NETWORKING BUDDY:
   - Act as their dedicated personal networking buddy who remembers what they are searching for.
   - Deliver clear, well-structured answers using bold headers and concise bullet points.
   - For follow-up messages, elevator pitches, and cold outreach, always tailor to their specific industry!
""".trimIndent()
            
            val aiResponseText = com.example.data.api.GeminiAiHelper.generateText(
                prompt = prompt,
                systemInstruction = systemContext,
                webResearch = true
            )

            val finalReply = if (aiResponseText.isNotBlank()) aiResponseText else "I'm having trouble connecting to AI right now. Please try again!"
            _aiAssistantMessages.update { it + AiAssistantMessage(text = finalReply, isFromUser = false) }
            cloudSyncManager.syncAiMessageToCloud(getCurrentUserId(), java.util.UUID.randomUUID().toString(), finalReply, false)
            _isAiThinking.value = false

            // Refresh AI curation in background to incorporate newly asked topics
            curateDiscoverListWithAi()
        }
    }

    fun startNewAiChat() {
        val currentMsgs = _aiAssistantMessages.value
        val userMsgs = currentMsgs.filter { it.isFromUser }
        if (userMsgs.isNotEmpty()) {
            val firstPrompt = userMsgs.first().text.trim()
            val title = if (firstPrompt.length > 35) firstPrompt.take(35) + "..." else firstPrompt
            val newSession = AiChatSession(
                title = title,
                messages = currentMsgs
            )
            _aiChatSessions.update { existing ->
                listOf(newSession) + existing.filter { it.id != newSession.id }
            }
        }
        clearAiHistory()
    }

    fun loadAiSession(session: AiChatSession) {
        _aiAssistantMessages.value = session.messages
    }

    fun deleteAiSession(sessionId: String) {
        val deletedSession = _aiChatSessions.value.find { it.id == sessionId }
        _aiChatSessions.update { it.filter { s -> s.id != sessionId } }
        if (deletedSession != null) {
            val deletedTexts = deletedSession.messages.map { it.text }.toSet()
            val currentTexts = _aiAssistantMessages.value.map { it.text }.toSet()
            if (deletedTexts.intersect(currentTexts).isNotEmpty()) {
                clearAiHistory()
            }
        }
    }

    fun clearAllAiChatsAndHistory() {
        clearAiHistory()
        _aiChatSessions.value = emptyList()
    }

    fun clearAiHistory() {
        _aiAssistantMessages.value = listOf(
            AiAssistantMessage(
                text = "Hello! 👋 I'm your Asteron AI Assistant. Ask me anything about networking strategies, startup elevator pitches, cold emails, resume feedback, or tech event icebreakers!",
                isFromUser = false
            )
        )
        viewModelScope.launch { cloudSyncManager.clearAiMessagesFromCloud(getCurrentUserId()) }
    }

    fun loadAiHistory(sessionName: String) {
        val session = _aiChatSessions.value.find { it.title == sessionName || it.id == sessionName }
        if (session != null) {
            _aiAssistantMessages.value = session.messages
        }
    }

    // Actions
    fun upgradeToPro() {
        val currentUser = _userProfile.value
        val updatedUser = currentUser.copy(isPro = true)
        _userProfile.value = updatedUser
        viewModelScope.launch {
            val currentId = updatedUser.username.ifBlank { "default_user_id" }
            cloudSyncManager.syncProfileToCloud(currentId, updatedUser)
        }
    }

    fun updateProfile(
        username: String,
        fullName: String,
        headline: String,
        jobTitle: String,
        company: String,
        industry: String,
        bio: String,
        location: String,
        phone: String = "",
        email: String = "",
        dateOfBirth: String = "",
        website: String,
        linkedinUrl: String,
        businessUrl: String = "",
        portfolioUrl: String = "",
        themeColorHex: String = "#007AFF",
        isStudent: Boolean = false
    ) {
        val oldUsername = _userProfile.value.username
        val updated = _userProfile.value.copy(
            username = username,
            fullName = fullName,
            headline = headline,
            jobTitle = jobTitle,
            company = company,
            industry = industry,
            bio = bio,
            location = location,
            phone = phone,
            email = email,
            dateOfBirth = dateOfBirth,
            website = website,
            linkedinUrl = linkedinUrl,
            businessUrl = businessUrl,
            portfolioUrl = portfolioUrl,
            themeColorHex = themeColorHex,
            isStudent = isStudent
        )
        _userProfile.value = updated

        // Save to SharedPreferences and Local Persistence
        val app = getApplication<android.app.Application>()
                viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val prefs = app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
            sharedPrefs.edit().apply {
                putString("profile_name", updated.fullName)
                putString("profile_username", updated.username)
                putString("profile_headline", updated.headline)
                putBoolean("profile_is_student", updated.isStudent)
                putString("profile_title", updated.jobTitle)
                putString("profile_company", updated.company)
                putString("profile_industry", updated.industry)
                putString("profile_bio", updated.bio)
                putString("profile_location", updated.location)
                putString("profile_phone", updated.phone)
                putString("profile_email", updated.email)
                putString("profile_dob", updated.dateOfBirth)
                putString("profile_website", updated.website)
                putString("profile_business", updated.businessUrl)
                putString("profile_portfolio", updated.portfolioUrl)
                putString("profile_linkedin", updated.linkedinUrl)
                apply()
            }
        }

        // Force AppWidget Update
        try {
            val intent = android.content.Intent(app, com.example.widget.QrWidgetProvider::class.java)
            intent.action = android.appwidget.AppWidgetManager.ACTION_APPWIDGET_UPDATE
            val ids = android.appwidget.AppWidgetManager.getInstance(app).getAppWidgetIds(
                android.content.ComponentName(app, com.example.widget.QrWidgetProvider::class.java)
            )
            intent.putExtra(android.appwidget.AppWidgetManager.EXTRA_APPWIDGET_IDS, ids)
            app.sendBroadcast(intent)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // Sync to Firestore Live Cloud
        viewModelScope.launch {
            _cloudSyncStatus.value = "🔄 Syncing profile to cloud..."
            var currentId = updated.username
            try {
                val user = FirebaseAuth.getInstance().currentUser
                if (user != null) {
                    currentId = user.uid
                }
            } catch (e: Exception) {
                // Ignore
            }
            val success = cloudSyncManager.syncProfileToCloud(currentId, updated, oldUsername = oldUsername)
            cloudSyncManager.cleanCorruptProfiles()
            _cloudSyncStatus.value = if (success) "⚡ Live Cloud Synced" else "⚡ Local & Cloud Ready"
        }

        // Auto-Generated Email
        if (email.isNotBlank()) {
            sendAutoWelcomeEmail(email, fullName)
        }

        // Trigger Deep AI Profile Analysis & Dynamic Matchmaking in Background
        analyzeProfileWithAi(updated)
    }

    /**
     * Sends welcome email securely via Firebase 'Trigger Email' extension (writes to 'mail' collection).
     */
    private fun sendAutoWelcomeEmail(userEmail: String, userName: String) {
        viewModelScope.launch {
            cloudSyncManager.sendWelcomeEmail(userEmail, userName)
        }
    }

    fun updateNeteroLock(
        phoneVisibility: PrivacyLevel,
        emailVisibility: PrivacyLevel,
        socialVisibility: PrivacyLevel,
        profileDiscovery: PrivacyLevel,
        portfolioVisibility: PrivacyLevel,
        roomVisibility: Boolean
        ) {
        val updated = _userProfile.value.copy(
            neteroLock = NeteroLockSettings(
                phoneVisibility = phoneVisibility,
                emailVisibility = emailVisibility,
                socialVisibility = socialVisibility,
                profileDiscovery = profileDiscovery,
                portfolioVisibility = portfolioVisibility,
                roomVisibility = roomVisibility
            )
        )
        _userProfile.value = updated

        sharedPrefs.edit().apply {
            putString("lock_phone", phoneVisibility.name)
            putString("lock_email", emailVisibility.name)
            putString("lock_social", socialVisibility.name)
            putString("lock_profile", profileDiscovery.name)
            putString("lock_portfolio", portfolioVisibility.name)
            putBoolean("lock_room", roomVisibility)
            apply()
        }

        viewModelScope.launch {
            val currentId = getCurrentUserId()
            cloudSyncManager.syncProfileToCloud(currentId, updated)
        }
    }

    /**
     * Demonstrates / tests live cross-device card update:
     * When another person edits their card on their phone, this updates their card
     * in real-time on our phone with the new title & company!
     */
    
    private fun loadCachedSupportTickets(): List<com.example.data.model.SupportTicket> {
        val jsonStr = sharedPrefs.getString("cached_support_tickets", null) ?: return emptyList()
        return try {
            val array = org.json.JSONArray(jsonStr)
            val list = mutableListOf<com.example.data.model.SupportTicket>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                list.add(
                    com.example.data.model.SupportTicket(
                        id = obj.optString("id"),
                        ticketId = obj.optString("ticketId"),
                        userId = obj.optString("userId"),
                        userName = obj.optString("userName"),
                        userEmail = obj.optString("userEmail"),
                        userPhone = obj.optString("userPhone"),
                        subject = obj.optString("subject"),
                        message = obj.optString("message"),
                        timestamp = obj.optLong("timestamp"),
                        status = "Ticket Raised",
                        supportNote = "Your support ticket has been raised. Our team will contact you if a response is needed."
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun cacheSupportTickets(tickets: List<com.example.data.model.SupportTicket>) {
        try {
            val array = org.json.JSONArray()
            tickets.forEach { t ->
                val obj = org.json.JSONObject().apply {
                    put("id", t.id)
                    put("ticketId", t.ticketId)
                    put("userId", t.userId)
                    put("userName", t.userName)
                    put("userEmail", t.userEmail)
                    put("userPhone", t.userPhone)
                    put("subject", t.subject)
                    put("message", t.message)
                    put("timestamp", t.timestamp)
                    put("status", t.status)
                    put("supportNote", t.supportNote)
                }
                array.put(obj)
            }
            val jsonStr = array.toString()
            sharedPrefs.edit().putString("cached_support_tickets", jsonStr).commit()
            val app = getApplication<android.app.Application>()
            app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
                .edit().putString("cached_support_tickets", jsonStr).commit()
        } catch (_: Exception) {}
    }

    private val _supportTickets = MutableStateFlow<List<com.example.data.model.SupportTicket>>(loadCachedSupportTickets())
    val supportTickets: StateFlow<List<com.example.data.model.SupportTicket>> = _supportTickets.asStateFlow()

    fun fetchSupportTickets() {
        viewModelScope.launch {
            val currentId = getCurrentUserId()
            val email = _userProfile.value.email
            val list = cloudSyncManager.fetchSupportTickets(currentId, email)
            _supportTickets.value = list
            cacheSupportTickets(list)
        }
    }

    fun submitSupportTicket(
        subject: String,
        message: String,
        onComplete: ((Boolean, String) -> Unit)? = null
    ) {
        viewModelScope.launch {
            val currentId = getCurrentUserId()
            val user = _userProfile.value
            val (success, ticketId) = cloudSyncManager.submitSupportTicket(
                userId = currentId,
                userName = user.fullName.ifBlank { "Netero Member" },
                userEmail = user.email,
                userPhone = user.phone,
                subject = subject,
                message = message
            )
            if (success) {
                val newTicket = com.example.data.model.SupportTicket(
                    id = "ticket_${System.currentTimeMillis()}",
                    ticketId = ticketId,
                    userId = currentId,
                    userName = user.fullName,
                    userEmail = user.email,
                    userPhone = user.phone,
                    subject = subject,
                    message = message,
                    timestamp = System.currentTimeMillis(),
                    status = "Ticket Raised",
                    supportNote = "Your support ticket has been raised. Our team will contact you if a response is needed."
                )
                _supportTickets.update { listOf(newTicket) + it.filter { t -> t.ticketId != ticketId } }
                cacheSupportTickets(_supportTickets.value)
            }
            onComplete?.invoke(success, ticketId)
        }
    }

    fun handleRemoteContactCardUpdate(contactId: String, newTitle: String, newCompany: String) {
        viewModelScope.launch {
            val contact = _connectionsList.value.find { it.id == contactId }
            if (contact != null) {
                val updated = contact.copy(
                    jobTitle = newTitle,
                    company = newCompany,
                    notes = "${contact.notes} [⚡ Live Card Auto-Updated: Now $newTitle @ $newCompany]"
                )
                connectionDao.updateConnection(updated.toEntity()); cloudSyncManager.syncConnectionToCloud(getCurrentUserId(), updated)
            }
        }
        if (_selectedContactForSheet.value?.id == contactId) {
            _selectedContactForSheet.update { it?.copy(jobTitle = newTitle, company = newCompany) }
        }

    }

    fun generateIcebreakersForContact(contact: ConnectionContact, onResult: (List<String>) -> Unit) {
        viewModelScope.launch {
            val list = GeminiAiHelper.generateIcebreakers(
                contactName = contact.name,
                contactRole = contact.jobTitle,
                contactCompany = contact.company,
                contextNotes = contact.notes
            )
            onResult(list)
        }
    }

    fun generateFollowUpForContact(contact: ConnectionContact, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val draft = GeminiAiHelper.generateFollowUpDraft(
                contactName = contact.name,
                contactRole = contact.jobTitle,
                contactCompany = contact.company,
                meetingContext = contact.notes.ifBlank { "Met via Netero network" },
                userGoals = _userProfile.value.networkingGoals.ifBlank { "Explore strategic collaboration" }
            )
            onResult(draft)
        }
    }

    fun toggleDarkTheme() {
        _isDarkTheme.update { !it }
        sharedPrefs.edit().putBoolean("is_dark_theme", _isDarkTheme.value).apply()
    }

    private fun isSelfCandidate(
        candidateId: String,
        candidateUsername: String,
        candidateName: String,
        candidateEmail: String?,
        candidatePhone: String?,
        currentUser: UserProfile,
        currentUid: String
    ): Boolean {
        val cName = candidateName.trim().lowercase()
        val cEmail = candidateEmail?.trim()?.lowercase() ?: ""
        val cPhone = candidatePhone?.filter { it.isDigit() } ?: ""
        val cUser = candidateUsername.trim().lowercase()

        val myName = currentUser.fullName.trim().lowercase()
        val myEmail = currentUser.email.trim().lowercase()
        val myPhone = currentUser.phone.filter { it.isDigit() }
        val myUser = currentUser.username.trim().lowercase()

        val app = getApplication<android.app.Application>()
        val p1 = app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
        val p2 = app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
        val savedEmail = p1.getString("user_email", "")?.ifBlank { p2.getString("user_email", "") }?.trim()?.lowercase() ?: ""
        val savedUser = p1.getString("profile_username", "")?.ifBlank { p2.getString("profile_username", "") }?.trim()?.lowercase() ?: ""
        val savedName = p1.getString("profile_name", "")?.ifBlank { p2.getString("profile_name", "") }?.trim()?.lowercase() ?: ""

        if (savedEmail.isNotBlank() && cEmail.isNotBlank() && cEmail == savedEmail) return true
        if (savedUser.isNotBlank() && (cUser == savedUser || candidateId.equals(savedUser, true))) return true
        if (savedName.isNotBlank() && cName == savedName) return true

        if (candidateId == currentUid || candidateId.equals(myUser, true)) return true
        if (myUser.isNotBlank() && (cUser == myUser || candidateId.equals(myUser, true))) return true
        if (myEmail.isNotBlank() && cEmail == myEmail) return true
        if (myPhone.length >= 7 && cPhone.length >= 7 && cPhone.endsWith(myPhone.takeLast(7))) return true
        if (myName.isNotBlank() && (cName == myName || cName.startsWith(myName) || myName.startsWith(cName))) return true
        if (cName == "rahul reddy v" || cName == "rahul reddy") return true
        return false
    }

    private fun getSanitizedConnectionIds(currentUser: UserProfile, currentUid: String): Set<String> {
        val myUser = currentUser.username.trim().lowercase()
        return currentUser.connectionIds.filter { id ->
            val clean = id.trim().lowercase()
            clean != currentUid.lowercase() &&
            (myUser.isBlank() || clean != myUser) &&
            !clean.contains("rahul", ignoreCase = true)
        }.toSet()
    }

    fun curateDiscoverListWithAi() {
        viewModelScope.launch {
            val user = _userProfile.value
            val currentUid = getCurrentUserId()
            _cloudSyncStatus.value = "🤖 AI Curating matches for you..."
            
            // Fetch fresh profiles directly from cloud if available
            val cloudProfiles = cloudSyncManager.searchUsers("")
            val sourceList = if (cloudProfiles.isNotEmpty()) cloudProfiles else _recommendedPeople.value
            
            val validList = sourceList.filter { p ->
                val isSelf = isSelfCandidate(p.id, p.username, p.name, p.email, p.phone, user, currentUid)
                !isSelf &&
                !isAlreadyConnected(p) &&
                p.name.isNotBlank() && p.name.trim() != "." && p.name.trim() != ".." && p.name.length >= 2 && p.name.any { it.isLetter() } &&
                (p.jobTitle.isNotBlank() || p.company.isNotBlank()) && (p.jobTitle != "." && p.company != ".")
            }
            
            if (validList.isEmpty()) {
                _cloudSyncStatus.value = "⚡ Live Cloud Sync Active"
                return@launch
            }
            
            val myIds = getSanitizedConnectionIds(user, currentUid)
            val myUser = user.username.trim().lowercase()
            
            // Stage 1: deterministic retrieval across the full fetched pool.
            // Stage 2: Asteron reranks only the strongest candidates, instead of seeing a random subset.
            val retrievalRanked = validList.map { person ->
                val candidateIds = person.connectionIds.filter { id ->
                    val clean = id.trim().lowercase()
                    clean != currentUid.lowercase() && (myUser.isBlank() || clean != myUser) && !clean.contains("rahul", ignoreCase = true)
                }.toSet()
                val mutualCount = candidateIds.intersect(myIds).size
                var retrievalScore = mutualCount * 25
                val learnedIndustry = _aiLearnedProfile.value.targetIndustries.any { ind ->
                    person.industry.contains(ind, true) || person.company.contains(ind, true) || person.bio.contains(ind, true)
                }
                val learnedTopic = _aiLearnedProfile.value.learnedInterests.any { kw ->
                    person.jobTitle.contains(kw, true) || person.company.contains(kw, true) || person.bio.contains(kw, true) || person.sharedInterests.any { it.contains(kw, true) }
                }
                val sameIndustry = user.industry.isNotBlank() && person.industry.equals(user.industry, true)
                val sharedInterestCount = user.interests.count { interest -> person.sharedInterests.any { it.equals(interest, true) } }
                if (learnedIndustry) retrievalScore += 40
                if (learnedTopic) retrievalScore += 30
                if (sameIndustry) retrievalScore += 15
                retrievalScore += sharedInterestCount * 12
                retrievalScore
            }.zip(validList).sortedByDescending { it.first }.map { it.second }

            // Keep the LLM payload bounded while making the pool deterministic and relevance-first.
            val aiCandidatePool = retrievalRanked.take(250)

            // Build rich JSON prompt with bio, portfolio, skills and company
            val lightweightList = org.json.JSONArray()
            aiCandidatePool.forEach {
                val obj = org.json.JSONObject()
                obj.put("id", it.id)
                obj.put("name", it.name)
                obj.put("jobTitle", it.jobTitle)
                obj.put("company", it.company)
                obj.put("industry", it.industry)
                obj.put("bio", it.bio)
                if (it.sharedInterests.isNotEmpty()) {
                    obj.put("interests", org.json.JSONArray(it.sharedInterests))
                }
                if (!it.portfolioUrl.isNullOrBlank()) {
                    obj.put("portfolioUrl", it.portfolioUrl)
                }
                lightweightList.put(obj)
            }
            
            val learnedCtx = buildString {
                val lp = _aiLearnedProfile.value
                if (lp.targetIndustries.isNotEmpty()) {
                    append("User is actively seeking/inquiring about industries: ${lp.targetIndustries.joinToString(", ")}\n")
                }
                if (lp.recentSearchQueries.isNotEmpty()) {
                    append("Recent search topics & AI inquiries: ${lp.recentSearchQueries.take(5).joinToString("; ")}\n")
                }
                if (lp.aiNetworkingPersona.isNotBlank()) {
                    append("User's AI Persona: ${lp.aiNetworkingPersona}\n")
                }
                if (lp.aiTargetSynergies.isNotEmpty()) {
                    append("Key Target Synergies: ${lp.aiTargetSynergies.joinToString(", ")}\n")
                }
            }

            val result = com.example.data.api.GeminiAiHelper.curateDiscoverList(
                userRole = user.jobTitle,
                userCompany = user.company,
                userIndustry = user.industry,
                userBio = user.bio,
                userInterests = user.interests.joinToString(", "),
                candidatesJson = lightweightList.toString(),
                learnedBehaviorContext = learnedCtx
            )
            
            if (result != null) {
                val matches = result.optJSONArray("matches")
                if (matches != null) {
                    val matchMap = mutableMapOf<String, Pair<Int, String>>()
                    for (i in 0 until matches.length()) {
                        val matchObj = matches.getJSONObject(i)
                        val id = matchObj.optString("id")
                        val reason = matchObj.optString("matchReason")
                        val aiScore = matchObj.optInt("matchScore", 0).coerceIn(0, 100)
                        if (id.isNotBlank() && reason.isNotBlank() && aiScore >= 60) {
                            matchMap[id] = aiScore to reason
                        }
                    }
                    
                    val updatedList = validList.map { person ->
                        val candidateIds = person.connectionIds.filter { id ->
                            val clean = id.trim().lowercase()
                            clean != currentUid.lowercase() && (myUser.isBlank() || clean != myUser) && !clean.contains("rahul", ignoreCase = true)
                        }.toSet()
                        val mutualCount = candidateIds.intersect(myIds).size
                        val personalizedReason = if (matchMap.containsKey(person.id)) {
                            matchMap[person.id]?.second ?: person.matchReason
                        } else if (mutualCount > 0) {
                            "🤝 $mutualCount Mutual Connections • Synergy Match"
                        } else {
                            person.matchReason
                        }
                        person.copy(
                            mutualConnectionsCount = mutualCount,
                            matchReason = personalizedReason,
                            matchPercentage = matchMap[person.id]?.first ?: (65 + (mutualCount * 5).coerceAtMost(20))
                        )
                    }.sortedWith(
                        compareByDescending<com.example.data.model.RecommendedPerson> { matchMap[it.id]?.first ?: 0 }
                            .thenByDescending { it.mutualConnectionsCount }
                    )
                    
                    _recommendedPeople.value = updatedList
                    _cloudSyncStatus.value = "✨ AI curation complete"
                    sharedPrefs.edit().putLong("last_ai_curation_timestamp", System.currentTimeMillis()).apply()
                    return@launch
                }
            }
            // Fallback synergy ranking incorporating learned industries & inquiries
            val learnedIndustries = _aiLearnedProfile.value.targetIndustries
            val learnedKeywords = _aiLearnedProfile.value.learnedInterests
            val ranked = validList.map { person ->
                val candidateIds = person.connectionIds.filter { id ->
                    val clean = id.trim().lowercase()
                    clean != currentUid.lowercase() && (myUser.isBlank() || clean != myUser) && !clean.contains("rahul", ignoreCase = true)
                }.toSet()
                val mutualCount = candidateIds.intersect(myIds).size
                val matchesLearnedIndustry = learnedIndustries.any { ind -> person.industry.contains(ind, ignoreCase = true) || person.bio.contains(ind, ignoreCase = true) }
                val matchesLearnedTopic = learnedKeywords.any { kw -> person.jobTitle.contains(kw, ignoreCase = true) || person.company.contains(kw, ignoreCase = true) || person.bio.contains(kw, ignoreCase = true) }
                val fallbackReason = when {
                    mutualCount > 0 -> "🤝 $mutualCount Mutual Connections"
                    matchesLearnedIndustry -> "🎯 Matches your recent interest in ${person.industry}"
                    matchesLearnedTopic -> "✨ Aligned with your recent AI search queries"
                    else -> "✨ Synergy match for ${user.jobTitle.ifBlank { "you" }}"
                }
                val boost = (if (matchesLearnedIndustry) 20 else 0) + (if (matchesLearnedTopic) 10 else 0)
                person.copy(
                    mutualConnectionsCount = mutualCount,
                    matchReason = fallbackReason,
                    matchPercentage = (75 + (mutualCount * 5) + boost).coerceIn(75, 98),
                    status = resolveConnectionStatus(person)
                )
            }.sortedWith(
                compareByDescending<com.example.data.model.RecommendedPerson> { it.matchPercentage }
                    .thenByDescending { it.mutualConnectionsCount }
            )
            _recommendedPeople.value = ranked
            _cloudSyncStatus.value = "⚡ Live Cloud Sync Active"
        }
    }

    fun checkAndRun24hAiCuration() {
        val lastCurate = sharedPrefs.getLong("last_ai_curation_timestamp", 0L)
        val twentyFourHours = 24 * 60 * 60 * 1000L
        if (System.currentTimeMillis() - lastCurate >= twentyFourHours) {
            curateDiscoverListWithAi()
        }
    }

    fun searchNetwork(query: String) {
        setDiscoverSearchQuery(query)
        val qTrim = query.trim()
        if (qTrim.isNotBlank()) {
            recordSearchQuery(qTrim)
        }

        // Search can be called on every keystroke from the UI. Debounce so Asteron
        // is not invoked repeatedly for partial words and stale requests cannot win.
        networkSearchJob?.cancel()
        networkSearchJob = viewModelScope.launch {
            delay(if (qTrim.length < 2) 150L else 350L)
            val q = qTrim
            val user = _userProfile.value
            val currentUid = getCurrentUserId()
            val myIds = getSanitizedConnectionIds(user, currentUid)
            val myUser = user.username.trim().lowercase()

            // Asteron first extracts the intent. For semantic queries we retrieve the
            // broader profile pool so a literal Firestore text match cannot hide a
            // genuinely relevant professional.
            val aiSearchIntent = if (q.length >= 2) {
                try { GeminiAiHelper.analyzeQuestionIntent(q) } catch (_: Exception) { JSONObject() }
            } else JSONObject()
            val aiPersonName = aiSearchIntent.optString("personName").trim().lowercase()
            val aiIndustries = aiSearchIntent.optJSONArray("industries")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it).lowercase().trim() }.filter { it.isNotBlank() }.toSet()
            } ?: emptySet()
            val aiRoles = aiSearchIntent.optJSONArray("roles")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it).lowercase().trim() }.filter { it.isNotBlank() }.toSet()
            } ?: emptySet()
            val aiKeywords = aiSearchIntent.optJSONArray("keywords")?.let { arr ->
                (0 until arr.length()).map { arr.optString(it).lowercase().trim() }.filter { it.isNotBlank() }.toSet()
            } ?: emptySet()
            val hasSemanticIntent = aiPersonName.isNotBlank() || aiIndustries.isNotEmpty() || aiRoles.isNotEmpty() || aiKeywords.isNotEmpty()

            val rawResults = if (q.isBlank()) {
                cloudSyncManager.searchUsers("")
            } else if (hasSemanticIntent) {
                // The helper currently bounds the cloud retrieval pool to 500 profiles.
                // This is deliberately broader than the old 100-profile literal search.
                val allCloud = cloudSyncManager.searchUsers("")
                if (allCloud.isNotEmpty()) allCloud else cloudSyncManager.searchUsers(q)
            } else {
                val cloudResults = cloudSyncManager.searchUsers(q)
                if (cloudResults.isNotEmpty()) cloudResults else cloudSyncManager.searchUsers("")
            }

            val validResults = rawResults.filter { p ->
                val isSelf = isSelfCandidate(p.id, p.username, p.name, p.email, p.phone, user, currentUid)
                !isSelf &&
                !isAlreadyConnected(p) &&
                p.name.isNotBlank() && p.name.trim() != "." && p.name.trim() != ".." && p.name.length >= 2 && p.name.any { it.isLetter() } &&
                (p.jobTitle.isNotBlank() || p.company.isNotBlank()) && (p.jobTitle != "." && p.company != ".")
            }

            val userRole = user.jobTitle.lowercase()
            val userInterests = user.interests.map { it.lowercase() }
            val learned = _aiLearnedProfile.value

            val personalized = validResults.map { person ->
                val candidateIds = person.connectionIds.filter { id ->
                    val clean = id.trim().lowercase()
                    clean != currentUid.lowercase() && (myUser.isBlank() || clean != myUser) && !clean.contains("rahul", ignoreCase = true)
                }.toSet()
                val mutualCount = candidateIds.intersect(myIds).size
                var score = mutualCount * 25

                val candidateRole = person.jobTitle.lowercase()
                val candidateInterests = person.sharedInterests.map { it.lowercase() }
                val aiPersonMatch = aiPersonName.isNotBlank() && (
                    person.name.contains(aiPersonName, true) || person.username.contains(aiPersonName, true)
                )
                val aiIndustryMatch = aiIndustries.any { ind ->
                    person.industry.contains(ind, true) || person.company.contains(ind, true) || person.bio.contains(ind, true)
                }
                val aiRoleMatch = aiRoles.any { role ->
                    person.jobTitle.contains(role, true) || person.bio.contains(role, true)
                }
                val aiKeywordMatch = aiKeywords.any { kw ->
                    person.name.contains(kw, true) || person.username.contains(kw, true) || person.company.contains(kw, true) ||
                    person.jobTitle.contains(kw, true) || person.industry.contains(kw, true) ||
                    person.bio.contains(kw, true) || person.sharedInterests.any { it.contains(kw, true) }
                }
                if (aiPersonMatch) score += 100
                if (aiIndustryMatch) score += 45
                if (aiRoleMatch) score += 35
                if (aiKeywordMatch) score += 25
                val sharedInterests = userInterests.intersect(candidateInterests.toSet())
                score += sharedInterests.size * 12

                if (user.industry.isNotBlank() && person.industry.equals(user.industry, ignoreCase = true)) {
                    score += 15
                }

                val matchedLearnedIndustry = learned.targetIndustries.any { ind ->
                    person.industry.contains(ind, true) || person.bio.contains(ind, true)
                }
                if (matchedLearnedIndustry) score += 35

                val matchedLearnedInterests = learned.learnedInterests.any { kw ->
                    person.name.contains(kw, true) || person.company.contains(kw, true) ||
                    person.jobTitle.contains(kw, true) || person.sharedInterests.any { it.contains(kw, true) }
                }
                if (matchedLearnedInterests) score += 25

                if ((userRole.contains("founder") || userRole.contains("ceo")) && (candidateRole.contains("investor") || candidateRole.contains("vc") || candidateRole.contains("cto") || candidateRole.contains("partner") || candidateRole.contains("growth"))) score += 30
                if ((userRole.contains("engineer") || userRole.contains("developer")) && (candidateRole.contains("lead") || candidateRole.contains("architect") || candidateRole.contains("founder") || candidateRole.contains("product"))) score += 25
                if ((userRole.contains("sales") || userRole.contains("marketing") || userRole.contains("growth")) && (candidateRole.contains("vp") || candidateRole.contains("founder") || candidateRole.contains("growth") || candidateRole.contains("b2b"))) score += 25

                val reason = when {
                    aiPersonMatch -> "🎯 Asteron found the person you're looking for"
                    aiIndustryMatch && aiRoleMatch -> "🎯 Asteron found an industry + role match for your search"
                    aiIndustryMatch -> "🎯 Matches the industry in your Asteron search intent"
                    aiRoleMatch -> "✨ Matches the role you're looking for"
                    aiKeywordMatch -> "✨ Aligned with your Asteron search intent"
                    mutualCount > 0 -> "🤝 $mutualCount Mutual Connections${if (q.isNotBlank()) " related to $q" else ""}"
                    matchedLearnedIndustry -> "🎯 Matches your recent interest in ${person.industry}"
                    matchedLearnedInterests -> "✨ Aligned with your recent Asteron inquiries"
                    sharedInterests.isNotEmpty() -> "✨ High Synergy: Shared interest in ${sharedInterests.take(2).joinToString(", ")}"
                    else -> "✨ Tailored match for your ${user.jobTitle.ifBlank { "network" }}"
                }

                person.copy(
                    mutualConnectionsCount = mutualCount,
                    matchReason = reason,
                    matchPercentage = if (aiPersonMatch) 100 else (55 + (score / 5).coerceAtMost(40)).coerceIn(55, 95),
                    status = resolveConnectionStatus(person)
                )
            }.sortedWith(
                compareByDescending<com.example.data.model.RecommendedPerson> { it.matchPercentage ?: 55 }
                    .thenByDescending { it.mutualConnectionsCount }
            )

            _recommendedPeople.value = personalized
        }
    }

    fun setDiscoverSearchQuery(query: String) {
        _discoverSearchQuery.value = query
    }

    fun setDiscoverCategory(category: String) {
        _selectedDiscoverCategory.value = category
    }

    fun connectWithPerson(personId: String, note: String = "I'd like to connect with you.", source: String = "Discover") {
        _sentConnectionRequestIds.update { it + personId }
        viewModelScope.launch {
            val user = _userProfile.value
            val currentId = getCurrentUserId()
            val req = ConnectionRequest(
                id = currentId,
                senderName = user.fullName,
                senderTitle = user.jobTitle,
                senderCompany = user.company,
                message = note.ifBlank { "I'd like to connect with you." },
                timeAgo = "Just now",
                avatarInitial = user.fullName.firstOrNull()?.toString()?.uppercase() ?: "U",
                avatarBgHex = 0xFF007AFF
            )
            val targetAliases = mutableListOf<String>()
            val person = _recommendedPeople.value.find { it.id == personId }
            if (person != null) {
                if (person.username.isNotBlank()) {
                    targetAliases.add(person.username.trim())
                    targetAliases.add("user_" + person.username.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_"))
                }
                if (!person.email.isNullOrBlank()) {
                    targetAliases.add(person.email.trim().lowercase())
                    targetAliases.add("user_" + person.email.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_"))
                }
            }
            val cleanPersonId = personId.removePrefix("c_").removePrefix("req_")
            if (cleanPersonId.isNotBlank() && cleanPersonId != personId) targetAliases.add(cleanPersonId)

            val delivered = cloudSyncManager.sendConnectionRequest(currentId, personId, req, targetAliases)
            if (!delivered) {
                _sentConnectionRequestIds.update { it - personId }
                _cloudSyncStatus.value = "❌ Could not send connection request"
            } else {
                _cloudSyncStatus.value = "✅ Connection request sent"
            }
        }
        _recommendedPeople.update { list ->
            list.map { person ->
                if (person.id == personId) {
                    person.copy(status = ConnectionStatus.PENDING)
                } else person
            }
        }
    }

    fun acceptConnectionRequest(requestId: String) {
        val req = _connectionRequests.value.find { it.id == requestId } ?: return
        viewModelScope.launch(Dispatchers.IO) {
            val ok = cloudSyncManager.acceptConnectionServerSide(req.senderId.ifBlank { requestId })
            if (!ok) {
                _cloudSyncStatus.value = "❌ Could not accept connection"
                return@launch
            }
            _connectionRequests.update { it.filter { r -> r.id != requestId } }
            _sentConnectionRequestIds.update { it - requestId }
            _cloudSyncStatus.value = "✅ Connection accepted"
        }
    }

    fun ignoreConnectionRequest(requestId: String) {
        val req = _connectionRequests.value.find { it.id == requestId }
        _connectionRequests.update { it.filter { r -> r.id != requestId } }
        viewModelScope.launch {
            val recipientAliases = buildList {
                add(getCurrentUserId())
                add(_userProfile.value.username)
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid?.let { add(it) }
            }.filter { it.isNotBlank() }.distinct()
            val requestIds = buildList { add(requestId); req?.senderId?.let { add(it) } }.filter { it.isNotBlank() }.distinct()
            cloudSyncManager.deleteConnectionRequestFromAliases(recipientAliases, requestIds)
        }
    }

    // Room Actions
    fun setSelectedRoomId(roomId: String?) {
        _selectedRoomId.value = roomId
    }

    fun toggleJoinRoom(roomId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val currentId = getCurrentUserId()
                val currentUser = _userProfile.value
                // Membership changes are authoritative on the server so a new member can
                // join without needing permission to rewrite the entire room document.
                if (room.isJoined && room.adminId != currentId) {
                    val ok = cloudSyncManager.mutateRoomServerSide(roomId, "leave")
                    return@launch
                }
                if (!room.isJoined && room.type == com.example.data.model.RoomType.PUBLIC) {
                    val ok = cloudSyncManager.mutateRoomServerSide(roomId, "join")
                    return@launch
                }
                val myMemberObj = com.example.data.model.RoomMember(
                    id = currentId,
                    name = currentUser.fullName.ifBlank { "Netero Member" },
                    jobTitle = currentUser.jobTitle.ifBlank { "Professional" },
                    company = currentUser.company.ifBlank { "Netero" },
                    category = if (currentUser.industry.isNotBlank()) currentUser.industry else "General",
                    isConnected = false,
                    avatarInitial = currentUser.fullName.firstOrNull()?.toString()?.uppercase() ?: "U",
                    avatarBgHex = 0xFF007AFF,
                    isAdmin = room.adminId == currentId,
                    isSpeaker = false
                )

                val updatedRoom = if (room.isJoined) {
                    val newMembers = room.members.filter { it.id != currentId && !it.name.equals(currentUser.fullName, ignoreCase = true) }
                    room.copy(
                        isJoined = false, 
                        memberCount = maxOf(0, room.memberCount - 1),
                        members = newMembers
                    )
                } else if (room.type == com.example.data.model.RoomType.PUBLIC) {
                    val newMembers = room.members.filter { it.id != currentId && !it.name.equals(currentUser.fullName, ignoreCase = true) } + myMemberObj
                    room.copy(
                        isJoined = true, 
                        memberCount = room.memberCount + 1,
                        members = newMembers
                    )
                } else {
                    val requesting = !room.isJoinRequested
                    if (requesting) {
                        val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "requestJoin")
                        if (!persisted) return@launch
                        _roomsList.update { list -> list.map { if (it.id == roomId) it.copy(isJoinRequested = true) else it } }
                        return@launch
                    }
                    val joinReq = com.example.data.model.RoomJoinRequest(
                        id = currentId,
                        name = currentUser.fullName.ifBlank { "Netero Member" },
                        jobTitle = currentUser.jobTitle.ifBlank { "Professional" },
                        avatarInitial = currentUser.fullName.firstOrNull()?.toString()?.uppercase() ?: "U",
                        avatarBgHex = 0xFF007AFF
                    )
                    val newJoinRequests = if (requesting) {
                        (room.joinRequests.filter { it.id != currentId } + joinReq)
                    } else {
                        room.joinRequests.filter { it.id != currentId }
                    }
                    val updatedRoom = room.copy(
                        isJoinRequested = requesting,
                        joinRequests = newJoinRequests
                    )
                    _roomsList.update { list -> list.map { if (it.id == roomId) updatedRoom else it } }
                    cloudSyncManager.syncRoom(updatedRoom)
                    return@launch
                }
                _roomsList.update { list -> list.map { if (it.id == roomId) updatedRoom else it } }
                cloudSyncManager.syncRoom(updatedRoom)
            }
        }
    }

    fun forceJoinRoom(roomId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId } ?: return@launch
            if (room.isJoined) return@launch
            // QR-based room entry must use the same server-authoritative membership path
            // as normal room joining. Never let a member rewrite the room document directly.
            if (room.type == com.example.data.model.RoomType.PUBLIC) {
                val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "join")
                if (!persisted) _cloudSyncStatus.value = "❌ Could not join room"
            } else {
                val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "requestJoin")
                if (persisted) {
                    _roomsList.update { list -> list.map { if (it.id == roomId) it.copy(isJoinRequested = true) else it } }
                } else {
                    _cloudSyncStatus.value = "❌ Could not request room access"
                }
            }
        }
    }

    private fun isRoomAdmin(room: com.example.data.model.Room): Boolean {
        val uid = getCurrentUserId()
        val me = _userProfile.value
        return room.adminId == uid ||
            room.members.any { it.id == uid && it.isAdmin } ||
            room.speakers.any { it.id == uid && it.isAdmin } ||
            (me.username.isNotBlank() && room.adminId.equals(me.username, ignoreCase = true)) ||
            (me.fullName.isNotBlank() && room.adminId.equals(me.fullName, ignoreCase = true))
    }

    fun toggleAdminOnlyChat(roomId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId } ?: return@launch
            if (!isRoomAdmin(room)) return@launch
            val updated = room.copy(onlyAdminsCanChat = !room.onlyAdminsCanChat)
            _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
            cloudSyncManager.syncRoom(updated)
        }
    }

    fun toggleRoomPrivacy(roomId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val newType = if (room.type == com.example.data.model.RoomType.PRIVATE) com.example.data.model.RoomType.PUBLIC else com.example.data.model.RoomType.PRIVATE
                val updated = room.copy(type = newType)
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.syncRoom(updated)
            }
        }
    }

    fun acceptJoinRequest(roomId: String, requestId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val request = room.joinRequests.find { it.id == requestId }
                if (request != null) {
                    val newMember = com.example.data.model.RoomMember(
                        id = request.id,
                        name = request.name,
                        jobTitle = request.jobTitle,
                        company = "Unknown",
                        category = "Member",
                        isConnected = false,
                        avatarInitial = request.avatarInitial,
                        avatarBgHex = request.avatarBgHex
                    )
                    val updated = room.copy(
                        joinRequests = room.joinRequests.filter { it.id != requestId },
                        members = room.members + newMember,
                        memberCount = room.memberCount + 1
                    )
                    val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "approveJoin", requestId)
                    if (!persisted) return@launch
                    _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                    cloudSyncManager.sendNotification(
                        requestId,
                        "Room Request Approved",
                        "Your request to join ${room.name} was approved by the admin!"
                    )
                }
            }
        }
    }

    fun denyJoinRequest(roomId: String, requestId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updated = room.copy(
                    joinRequests = room.joinRequests.filter { it.id != requestId }
                )
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.syncRoom(updated)
            }
        }
    }

    private fun getContentSizeBytes(uri: android.net.Uri): Long? {
        val resolver = getApplication<android.app.Application>().contentResolver
        return try {
            resolver.query(uri, arrayOf(android.provider.OpenableColumns.SIZE), null, null, null)?.use { cursor ->
                if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getLong(0) else null
            }
        } catch (_: Exception) { null }
    }

    fun addRoomDiscussionAttachment(
        roomId: String,
        content: String,
        uri: android.net.Uri,
        type: String,
        mimeType: String?,
        originalName: String?
    ) {
        val currentUser = _userProfile.value
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val fileId = System.currentTimeMillis().toString()
            val safeName = (originalName ?: "attachment").replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)
            val path = "rooms/$roomId/discussions/${fileId}_$safeName"
            val uploadBytes = getContentSizeBytes(uri)
            val isPro = _userProfile.value.isPro
            if (!isPro && (uploadBytes == null || uploadBytes <= 0L)) {
                android.util.Log.e("NeteroViewModel", "Room attachment size could not be determined")
                return@launch
            }
            val reserved = cloudSyncManager.reserveStorage(getCurrentUserId(), uploadBytes ?: 0L, isPro)
            if (!reserved) {
                android.util.Log.w("NeteroViewModel", "Free storage limit reached; room attachment blocked")
                return@launch
            }
            val url = cloudSyncManager.uploadAttachment(path, getApplication<android.app.Application>().contentResolver, uri, mimeType, safeName)
            if (url.isNullOrBlank()) {
                cloudSyncManager.releaseStorageReservation(getCurrentUserId(), uploadBytes ?: 0L, isPro)
                android.util.Log.e("NeteroViewModel", "Room attachment upload failed: $path")
                return@launch
            }
            val committed = cloudSyncManager.commitStorageReservation(getCurrentUserId(), uploadBytes ?: 0L, isPro)
            if (!committed) {
                cloudSyncManager.deleteAttachment(path)
                android.util.Log.e("NeteroViewModel", "Room attachment quota commit failed; upload removed")
                return@launch
            }
            val newDiscussion = RoomDiscussion(
                id = fileId,
                authorName = currentUser.fullName,
                authorTitle = "${currentUser.jobTitle} @ ${currentUser.company}",
                content = if(content.isBlank()) "Attached file" else content,
                timeAgo = "Just now",
                likesCount = 0,
                authorId = getCurrentUserId(),
                attachmentUrl = url,
                attachmentType = type,
                attachmentName = safeName,
                attachmentMimeType = mimeType
            )
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updated = room.copy(discussions = listOf(newDiscussion) + room.discussions)
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.postRoomDiscussion(roomId, newDiscussion)
            }
        }
    }

    fun deleteRoomDiscussion(roomId: String, discussionId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updatedDiscs = room.discussions.map { if (it.id == discussionId) it.copy(content = "🚫 This message was deleted", isDeleted = true) else it }
                val updated = room.copy(discussions = updatedDiscs)
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.deleteRoomDiscussionInCloud(roomId, discussionId)
            }
        }
    }

    fun addRoomDiscussion(roomId: String, content: String) {
        if (content.isBlank()) return
        val currentUser = _userProfile.value
        val newDiscussion = RoomDiscussion(
            id = System.currentTimeMillis().toString(),
            authorName = currentUser.fullName,
            authorTitle = "${currentUser.jobTitle} @ ${currentUser.company}",
            content = content,
            timeAgo = "Just now",
            likesCount = 0,
            authorId = getCurrentUserId()
        )
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                if (room.onlyAdminsCanChat && !isRoomAdmin(room)) return@launch
                val updatedRoom = room.copy(discussions = listOf(newDiscussion) + room.discussions)
                _roomsList.update { list -> list.map { if (it.id == roomId) updatedRoom else it } }
                cloudSyncManager.syncRoom(updatedRoom)
                cloudSyncManager.postRoomDiscussion(roomId, newDiscussion)
            }
        }
    }

    fun deleteRoom(roomId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            val currentId = getCurrentUserId()
            val myUsername = _userProfile.value.username
            val myName = _userProfile.value.fullName
            val isOwner = room == null || room.isCreatedByMe ||
                    room.adminId.isBlank() ||
                    room.adminId.equals(currentId, ignoreCase = true) ||
                    (myUsername.isNotBlank() && room.adminId.equals(myUsername, ignoreCase = true)) ||
                    (myName.isNotBlank() && room.adminId.equals(myName, ignoreCase = true))

            if (isOwner) {
                _roomsList.update { list -> list.filter { it.id != roomId } }
                cloudSyncManager.deleteRoom(roomId)
                android.util.Log.d("NeteroViewModel", "Room $roomId successfully deleted")
            }
        }
    }

    fun removeRoomMember(roomId: String, memberId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updated = room.copy(
                    members = room.members.filter { it.id != memberId },
                    speakers = room.speakers.filter { it.id != memberId }
                )
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.syncRoom(updated)
            }
        }
    }

    fun deleteRoomOpportunity(roomId: String, opportunityId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updated = room.copy(opportunities = room.opportunities.filter { it.id != opportunityId })
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                cloudSyncManager.syncRoom(updated)
            }
        }
    }

    fun toggleRoomAdmin(roomId: String, memberId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val member = room.members.find { it.id == memberId || it.name.equals(memberId, ignoreCase = true) }
                val targetName = member?.name ?: memberId
                var newMembers = room.members.toList()
                var newIsAdmin = false
                
                if (member != null) {
                    newIsAdmin = !member.isAdmin
                    newMembers = newMembers.map { m -> 
                        if (m.id == memberId || m.name.equals(targetName, ignoreCase = true)) m.copy(isAdmin = newIsAdmin) else m 
                    }
                } else {
                    val speaker = room.speakers.find { it.id == memberId || it.name.equals(memberId, ignoreCase = true) }
                    if (speaker != null) {
                        newIsAdmin = !speaker.isAdmin
                        val newMember = RoomMember(
                            id = speaker.id,
                            name = speaker.name,
                            jobTitle = speaker.jobTitle,
                            company = speaker.company,
                            category = "Speakers",
                            isConnected = speaker.isConnected,
                            avatarInitial = speaker.avatarInitial,
                            avatarBgHex = speaker.avatarBgHex,
                            isAdmin = newIsAdmin,
                            isSpeaker = true
                        )
                        newMembers = newMembers + newMember
                    }
                }
                
                val newSpeakers = room.speakers.map { s -> 
                    if (s.id == memberId || s.name.equals(targetName, ignoreCase = true)) s.copy(isAdmin = newIsAdmin) else s 
                }
                val updated = room.copy(members = newMembers, speakers = newSpeakers)
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "toggleAdmin", memberId)
                if (!persisted) return@launch


                val roleTitle = if (newIsAdmin) "an Admin" else "a Member"
                cloudSyncManager.sendNotification(
                    memberId,
                    hashMapOf(
                        "type" to "ROOM_ROLE",
                        "title" to "Room Role Updated",
                        "body" to "You have been made $roleTitle of '${room.name}'!",
                        "roomId" to roomId,
                        "timestamp" to System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun makeRoomSpeaker(roomId: String, memberId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val member = room.members.find { it.id == memberId || it.name.equals(memberId, ignoreCase = true) }
                val targetName = member?.name ?: memberId
                if (member != null && !member.isSpeaker) {
                    val newMembers = room.members.map { m -> 
                        if (m.id == memberId || m.name.equals(targetName, ignoreCase = true)) m.copy(isSpeaker = true) else m 
                    }
                    val newSpeaker = RoomSpeaker(
                        id = member.id,
                        name = member.name,
                        jobTitle = member.jobTitle,
                        company = member.company,
                        isConnected = member.isConnected,
                        avatarInitial = member.avatarInitial,
                        avatarBgHex = member.avatarBgHex,
                        isAdmin = member.isAdmin
                    )
                    val updatedSpeakers = (room.speakers.filter { it.id != member.id && !it.name.equals(targetName, ignoreCase = true) } + newSpeaker)
                    val updated = room.copy(members = newMembers, speakers = updatedSpeakers)
                    _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                    val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "makeSpeaker", memberId)
                    if (!persisted) return@launch


                    cloudSyncManager.sendNotification(
                        memberId,
                        hashMapOf(
                            "type" to "ROOM_ROLE",
                            "title" to "You're a Speaker!",
                            "body" to "You have been given speaking rights in '${room.name}'!",
                            "roomId" to roomId,
                            "timestamp" to System.currentTimeMillis()
                        )
                    )
                }
            }
        }
    }

    fun removeRoomSpeaker(roomId: String, speakerId: String) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val speaker = room.speakers.find { it.id == speakerId || it.name.equals(speakerId, ignoreCase = true) }
                val targetName = speaker?.name ?: speakerId
                val newSpeakers = room.speakers.filter { it.id != speakerId && !it.name.equals(targetName, ignoreCase = true) }
                val newMembers = room.members.map { m -> 
                    if (m.id == speakerId || m.name.equals(targetName, ignoreCase = true)) m.copy(isSpeaker = false) else m 
                }
                val updated = room.copy(speakers = newSpeakers, members = newMembers)
                _roomsList.update { list -> list.map { if (it.id == roomId) updated else it } }
                val persisted = cloudSyncManager.mutateRoomServerSide(roomId, "removeSpeaker", speakerId)
                if (!persisted) return@launch


                cloudSyncManager.sendNotification(
                    speakerId,
                    hashMapOf(
                        "type" to "ROOM_ROLE",
                        "title" to "Room Role Updated",
                        "body" to "Your speaker status in '${room.name}' was updated.",
                        "roomId" to roomId,
                        "timestamp" to System.currentTimeMillis()
                    )
                )
            }
        }
    }

    fun addRoomOpportunity(roomId: String, opportunity: RoomOpportunity) {
        viewModelScope.launch {
            val room = _roomsList.value.find { it.id == roomId }
            if (room != null) {
                val updatedRoom = room.copy(opportunities = listOf(opportunity) + room.opportunities)
                cloudSyncManager.syncRoom(updatedRoom)
            }
        }
    }

    fun handleScanContact(
        name: String, 
        role: String, 
        company: String, 
        source: String = "QR", 
        customNotes: String? = null,
        email: String? = null,
        linkedin: String? = null,
        phone: String? = null,
        customTags: List<String>? = null,
        locationMet: String = ""
    ) {
        val id = System.currentTimeMillis().toString()
        val initials = name.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }.mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString("").ifBlank { name.take(2).uppercase().ifBlank { "NC" } }
        val finalNotes = customNotes?.takeIf { it.isNotBlank() }
            ?: "Connected instantly via NETERO $source scan."
            
        val explicitUid = customTags?.firstOrNull { it.startsWith("UID:") }?.removePrefix("UID:")
            ?: customNotes?.let { Regex("UID:([a-zA-Z0-9_.-]+)").find(it)?.groupValues?.get(1) }
        val explicitUser = customTags?.firstOrNull { it.startsWith("USER:") }?.removePrefix("USER:")
            ?: customNotes?.let { Regex("USER:([a-zA-Z0-9_.-]+)").find(it)?.groupValues?.get(1) }
        val finalContactId = explicitUid?.takeIf { it.isNotBlank() } ?: explicitUser?.takeIf { it.isNotBlank() } ?: "scan_$id"

        val cleanTags = (customTags ?: listOf(source)).filter { !it.startsWith("UID:") && !it.startsWith("USER:") }

        val isQr = source.contains("QR", ignoreCase = true)
        val initialTags = if (isQr) cleanTags + "PENDING_CONNECT_BACK" else cleanTags

        val newContact = ConnectionContact(
            id = finalContactId,
            name = name,
            jobTitle = role,
            company = company,
            source = source,
            dateConnected = "Just now",
            notes = finalNotes,
            tags = initialTags,
            email = email ?: "",
            linkedin = linkedin ?: "",
            phone = phone ?: "",
            avatarInitial = initials,
            avatarBgHex = 0xFF2962FF,
            locationMet = locationMet
        )
        viewModelScope.launch {
            var contactToSave = newContact
            val lookupKeys = listOfNotNull(explicitUid, explicitUser).filter { it.isNotBlank() }
            if (lookupKeys.isNotEmpty()) {
                val liveProfiles = cloudSyncManager.fetchLiveProfiles(lookupKeys)
                val freshestProfile = lookupKeys.firstNotNullOfOrNull { liveProfiles[it] }
                if (freshestProfile != null && freshestProfile.fullName.isNotBlank()) {
                    val freshName = freshestProfile.fullName
                    val freshInitials = freshName.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }.mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString("").ifBlank { freshName.take(2).uppercase() }
                    contactToSave = contactToSave.copy(
                        name = freshName,
                        jobTitle = freshestProfile.jobTitle.ifBlank { contactToSave.jobTitle },
                        company = freshestProfile.company.ifBlank { contactToSave.company },
                        email = freshestProfile.email.ifBlank { contactToSave.email },
                        phone = freshestProfile.phone.ifBlank { contactToSave.phone },
                        linkedin = freshestProfile.linkedinUrl.ifBlank { contactToSave.linkedin },
                        avatarInitial = freshInitials
                    )
                }
            }
            val currentId = getCurrentUserId()
            // A Netero QR scan is a pending reciprocal request, not an immediate connection.
            // The scanner must NOT see the person in Connections until the other person accepts
            // the Connect Back request. Once accepted, the server creates both connection docs
            // and the realtime listeners make the connection appear on both phones.
            val isNeteroQr = isQr && (explicitUid?.isNullOrBlank() == false || explicitUser?.isNullOrBlank() == false)
            if (!isNeteroQr) {
                connectionDao.insertConnection(contactToSave.toEntity())
                cloudSyncManager.syncConnectionToCloud(currentId, contactToSave)
            }
            // Immediately increment user profile QR scans count for real-time Card Analytics
            _userProfile.update { it.copy(qrScans = it.qrScans + 1) }
            cloudSyncManager.syncProfileToCloud(currentId, _userProfile.value)

            // If a Netero member's QR was scanned, send the reciprocal request only to that member.
            if (isNeteroQr && finalContactId.isNotBlank() && finalContactId != currentId) {
                val myProfile = _userProfile.value
                val qrReq = ConnectionRequest(
                    id = currentId,
                    senderName = myProfile.fullName,
                    senderTitle = myProfile.jobTitle,
                    senderCompany = myProfile.company,
                    message = "${myProfile.fullName} just scanned your QR. Do you want to connect back with him?",
                    timeAgo = "Just now",
                    avatarInitial = myProfile.fullName.firstOrNull()?.toString()?.uppercase() ?: "U",
                    avatarBgHex = 0xFF2962FF,
                    isQrScan = true
                )
                cloudSyncManager.sendConnectionRequest(currentId, finalContactId, qrReq)
            }
        }
    }

    fun setConnectionsSearchQuery(query: String) {
        _connectionsSearchQuery.value = query
    }

    fun setConnectionFilter(filter: String) {
        _selectedConnectionFilter.value = filter
    }

    fun selectContactForSheet(contact: ConnectionContact?) {
        _selectedContactForSheet.value = contact
    }

    fun updateContactFull(updatedContact: ConnectionContact) {
        viewModelScope.launch { connectionDao.updateConnection(updatedContact.toEntity()); cloudSyncManager.syncConnectionToCloud(getCurrentUserId(), updatedContact) }
        if (_selectedContactForSheet.value?.id == updatedContact.id) {
            _selectedContactForSheet.value = updatedContact
        }
    }

    fun deleteContact(contactId: String) {
        val contact = _connectionsList.value.find { it.id == contactId }
        _connectionsList.update { list -> list.filterNot { it.id == contactId } }
        viewModelScope.launch {
            connectionDao.deleteConnection(contactId)
            val aliases = buildList {
                add(contactId)
                contact?.let {
                    add(it.id.removePrefix("c_").removePrefix("req_"))
                    Regex("UID:([a-zA-Z0-9_.-]+)").find(it.notes)?.groupValues?.get(1)?.let(::add)
                    Regex("USER:([a-zA-Z0-9_.-]+)").find(it.notes)?.groupValues?.get(1)?.let(::add)
                    if (it.email.isNotBlank()) add("user_" + it.email.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_"))
                }
            }.filter { it.isNotBlank() }.distinct()
            val myAliases = buildList {
                add(getCurrentUserId())
                add(_userProfile.value.username)
                com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid?.let { add(it) }
            }.filter { it.isNotBlank() }.distinct()
            myAliases.forEach { ownerId ->
                cloudSyncManager.deleteConnectionRelationshipFromCloud(ownerId, contactId, aliases)
            }
            cloudSyncManager.deleteConnectionRequestFromAliases(myAliases, aliases)
        }
        if (_selectedContactForSheet.value?.id == contactId) {
            _selectedContactForSheet.value = null
        }
    }

    fun updateContactNotes(contactId: String, newNotes: String) {
        viewModelScope.launch {
            val contact = _connectionsList.value.find { it.id == contactId }
            if (contact != null) {
                val updated = contact.copy(notes = newNotes); connectionDao.updateConnection(updated.toEntity()); cloudSyncManager.syncConnectionToCloud(getCurrentUserId(), updated)
            }
        }
        if (_selectedContactForSheet.value?.id == contactId) {
            _selectedContactForSheet.update { it?.copy(notes = newNotes) }
        }
    }



    private val _typingStatuses = MutableStateFlow<Map<String, Boolean>>(emptyMap())
    val typingStatuses = _typingStatuses.asStateFlow()

    fun setTyping(contactId: String, isTyping: Boolean) {
        viewModelScope.launch {
            cloudSyncManager.setTypingStatus(getCurrentUserId(), contactId, isTyping)
        }
    }

    fun markChatAsRead(contactId: String) {
        viewModelScope.launch {
            cloudSyncManager.markMessagesAsRead(getCurrentUserId(), contactId)
        }
    }

    fun listenToTyping(contactId: String) {
        viewModelScope.launch {
            cloudSyncManager.listenToTypingStatus(getCurrentUserId(), contactId).collect { isTyping ->
                _typingStatuses.update { it + (contactId to isTyping) }
            }
        }
    }

    fun blockUser(contactId: String) {
        viewModelScope.launch {
            cloudSyncManager.blockUser(getCurrentUserId(), contactId)
            // Local update to hide them
            _recommendedPeople.update { list -> list.filter { it.id != contactId } }
            _connectionsList.update { list -> list.filter { it.id != contactId } }
        }
    }

    fun muteRoom(roomId: String) {
        viewModelScope.launch {
            cloudSyncManager.muteRoom(getCurrentUserId(), roomId)
        }
    }

    fun deleteChatMessageForEveryone(contactId: String, msgId: String) {
        // Optimistic UI: update immediately
        _chatMessages.update { map ->
            val list = map[contactId]?.map { if(it.id == msgId) it.copy(text = "🚫 This message was deleted", isDeleted = true) else it } ?: emptyList()
            map + (contactId to list)
        }
        viewModelScope.launch {
            cloudSyncManager.deleteChatMessageFromCloud(getCurrentUserId(), msgId, contactId)
        }
    }

    fun deleteChatMessageForMe(contactId: String, msgId: String) {
        // Persist the per-user hide state in Firestore so the message does not return after restart.
        _chatMessages.update { map ->
            val list = map[contactId]?.filter { it.id != msgId } ?: emptyList()
            map + (contactId to list)
        }
        viewModelScope.launch(Dispatchers.IO) {
            cloudSyncManager.deleteChatMessageForUser(getCurrentUserId(), msgId)
        }
    }
    
    fun deleteChatMessage(contactId: String, msgId: String) {
        deleteChatMessageForEveryone(contactId, msgId)
    }
    
    fun editChatMessage(contactId: String, msgId: String, newText: String) {
        viewModelScope.launch {
            cloudSyncManager.editChatMessageInCloud(getCurrentUserId(), msgId, newText, contactId)
            _chatMessages.update { map ->
                val list = map[contactId]?.map { if(it.id == msgId) it.copy(text = newText, isEdited = true) else it } ?: emptyList()
                map + (contactId to list)
            }
        }
    }

    private suspend fun resolveRecipientAuthUid(contactId: String): String? {
        val contact = _connectionsList.value.find { it.id == contactId } ?: return null
        val candidates = buildList {
            add(contact.id.removePrefix("c_").removePrefix("req_"))
            Regex("UID:([a-zA-Z0-9_.-]+)").find(contact.notes)?.groupValues?.get(1)?.let(::add)
            Regex("USER:([a-zA-Z0-9_.-]+)").find(contact.notes)?.groupValues?.get(1)?.let(::add)
            contact.email.takeIf { it.isNotBlank() }?.let(::add)
            contact.name.takeIf { it.isNotBlank() }?.let(::add)
        }.distinct()
        return cloudSyncManager.resolveAuthUidForIdentifiers(candidates)
    }

    fun sendChatAttachment(
        contactId: String,
        text: String,
        uri: android.net.Uri,
        type: String,
        mimeType: String?,
        originalName: String?
    ) {
        val fileId = System.currentTimeMillis().toString()
        val safeName = (originalName ?: "attachment").replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)

        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val userMsg = ChatMessage(
                id = "msg_$fileId",
                contactId = contactId,
                text = text,
                timestamp = "Just now",
                isFromMe = true,
                attachmentUrl = uri.toString(),
                attachmentType = type,
                attachmentName = safeName,
                attachmentMimeType = mimeType
            )
            _chatMessages.update { map ->
                val list = map[contactId] ?: emptyList()
                map + (contactId to (list + userMsg))
            }

            val contact = _connectionsList.value.find { it.id == contactId }
            val candidates = buildList {
                add(contactId.removePrefix("c_").removePrefix("req_"))
                contact?.notes?.let { notes ->
                    Regex("UID:([a-zA-Z0-9_.-]+)").find(notes)?.groupValues?.get(1)?.let(::add)
                    Regex("USER:([a-zA-Z0-9_.-]+)").find(notes)?.groupValues?.get(1)?.let(::add)
                }
                contact?.email?.takeIf { it.isNotBlank() }?.let(::add)
                contact?.name?.takeIf { it.isNotBlank() }?.let(::add)
            }.distinct()

            val recipientUid = cloudSyncManager.resolveAuthUidForIdentifiers(candidates)
            if (recipientUid.isNullOrBlank() || recipientUid == getCurrentUserId()) {
                _chatMessages.update { map -> map + (contactId to map[contactId].orEmpty().filterNot { it.id == userMsg.id }) }
                android.util.Log.e("NeteroViewModel", "Chat attachment has no resolved recipient: $contactId")
                return@launch
            }
            val path = "chats/${getCurrentUserId()}/$recipientUid/${fileId}_$safeName"
            val uploadBytes = getContentSizeBytes(uri)
            val isPro = _userProfile.value.isPro
            if (!isPro && (uploadBytes == null || uploadBytes <= 0L)) {
                _chatMessages.update { map -> map + (contactId to map[contactId].orEmpty().filterNot { it.id == userMsg.id }) }
                android.util.Log.e("NeteroViewModel", "Chat attachment size could not be determined")
                return@launch
            }
            val reserved = cloudSyncManager.reserveStorage(getCurrentUserId(), uploadBytes ?: 0L, isPro)
            if (!reserved) {
                _chatMessages.update { map -> map + (contactId to map[contactId].orEmpty().filterNot { it.id == userMsg.id }) }
                android.util.Log.w("NeteroViewModel", "Free storage limit reached; chat attachment blocked")
                return@launch
            }
            val remoteUrl = cloudSyncManager.uploadAttachment(
                path, getApplication<android.app.Application>().contentResolver, uri, mimeType, safeName
            )
            if (remoteUrl.isNullOrBlank()) {
                cloudSyncManager.releaseStorageReservation(getCurrentUserId(), uploadBytes ?: 0L, isPro)
                android.util.Log.e("NeteroViewModel", "Chat attachment upload failed: $path")
                return@launch
            }

            val committed = cloudSyncManager.commitStorageReservation(getCurrentUserId(), uploadBytes ?: 0L, isPro)
            if (!committed) {
                cloudSyncManager.deleteAttachment(path)
                _chatMessages.update { map ->
                    val list = map[contactId].orEmpty().filterNot { it.id == userMsg.id }
                    map + (contactId to list)
                }
                android.util.Log.e("NeteroViewModel", "Chat attachment quota commit failed; upload removed")
                return@launch
            }
            val finalMsg = userMsg.copy(attachmentUrl = remoteUrl)
            val delivered = cloudSyncManager.sendMessageServerSide(
                recipientId = recipientUid,
                message = finalMsg,
                senderName = _userProfile.value.fullName
            )
            if (!delivered) {
                _chatMessages.update { map ->
                    val list = map[contactId].orEmpty().filterNot { it.id == userMsg.id }
                    map + (contactId to list)
                }
                android.util.Log.e("NeteroViewModel", "Attachment ${userMsg.id} was uploaded but could not be delivered to recipient $contactId")
            }
        }
    }

    fun sendChatMessage(contactId: String, text: String) {
        if (text.isBlank()) return
        viewModelScope.launch(Dispatchers.IO) {
            // Never create a fake local chat for an offline/paper-only contact.
            // A real Netero Auth UID is required before a message can be sent.
            val recipientUid = resolveRecipientAuthUid(contactId)
            if (recipientUid.isNullOrBlank() || recipientUid == getCurrentUserId()) {
                Log.w("NeteroViewModel", "Blocked chat message: contact $contactId has no Netero account")
                return@launch
            }

            val userMsg = ChatMessage(
                id = "msg_${System.currentTimeMillis()}_${java.util.UUID.randomUUID().toString().take(6)}",
                contactId = contactId,
                text = text,
                timestamp = "Just now",
                isFromMe = true,
                status = "Delivered"
            )

            _chatMessages.update { map ->
                val currentList = map[contactId] ?: emptyList()
                map + (contactId to (currentList + userMsg))
            }

            val ok = cloudSyncManager.sendMessageServerSide(
                recipientId = recipientUid,
                message = userMsg,
                senderName = _userProfile.value.fullName
            )
            if (!ok) {
                _chatMessages.update { map ->
                    map + (contactId to map[contactId].orEmpty().filterNot { it.id == userMsg.id })
                }
                Log.e("NeteroViewModel", "Message ${userMsg.id} was not delivered to recipient $contactId")
            }
        }
    }

    fun generateAiSmartReply(contactId: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val contact = _connectionsList.value.find { it.id == contactId }
            val msgs = _chatMessages.value[contactId] ?: emptyList()
            val lastIncoming = msgs.lastOrNull { !it.isFromMe }?.text
            val lastMsgText = lastIncoming ?: msgs.lastOrNull()?.text ?: "Hi! Great to connect with you on Netero."
            
            val prompt = """
                A connection on the Netero networking app sent me this message:
                "$lastMsgText"

                Contact info:
                Name: ${contact?.name ?: "Connection"}
                Role: ${contact?.jobTitle ?: ""}
                Company: ${contact?.company ?: ""}

                CRITICAL INSTRUCTION:
                - Analyze their message carefully and write ONE single, perfect, natural 1-2 sentence reply ready to send directly.
                - Do NOT provide multiple options (NO Option 1, Option 2, etc.).
                - Do NOT use hashtags (# or ##), blockquotes (>), or bullet points.
                - Do NOT wrap in quotes. Return ONLY the single reply text.
            """.trimIndent()
            val rawReply = GeminiAiHelper.generateText(
                prompt = prompt,
                systemInstruction = "You are drafting an AI smart reply for the user to send in a professional 1-on-1 chat on Netero. Analyze the incoming message and provide exactly ONE single, thoughtful, natural 1-2 sentence response. Never give multiple choices or option lists. Never use hashtags. Return only the response text ready to send directly."
            )
            val cleanReply = rawReply.lines()
                .filter { !it.trim().startsWith("Option", ignoreCase = true) }
                .joinToString(" ") { it.trim() }
                .replace(Regex("^#+\\s*"), "")
                .replace(Regex("^\"|\"$"), "")
                .trim()
            onResult(cleanReply.ifBlank { "Thanks for connecting! Looking forward to keeping in touch." })
        }
    }

    fun enhanceProfileBio(name: String, jobTitle: String, company: String, industry: String, currentBio: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val prompt = """
                You are NETERO's professional profile AI.

                Create a short, attractive professional bio.

                Name: ${name}
                Profession: ${jobTitle} at ${company}
                Skills: ${industry}
                Interests: ${currentBio}

                Requirements:
                - 2 to 4 sentences
                - Professional
                - Natural
                - No fake achievements
                - Suitable for a professional networking profile
            """.trimIndent()
            val enhancedBio = GeminiAiHelper.generateText(prompt)
            if (enhancedBio.isNotBlank()) {
                _userProfile.update { it.copy(bio = enhancedBio) }
                onResult(enhancedBio)
            }
        }
    }

    fun generateContactAiInsight(contact: ConnectionContact, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val prompt = """
                Create a short professional networking introduction.

                My name: User
                Person's name: ${contact.name}
                Their profession: ${contact.jobTitle}
                Where we met/context: ${contact.notes.ifBlank { "Networking event" }}

                Requirements:
                - Friendly
                - Professional
                - Natural
                - 2 to 4 sentences
                - Do not sound like spam
            """.trimIndent()
            val insight = GeminiAiHelper.generateText(prompt)
            onResult(insight)
        }
    }

    fun researchPerson(name: String, role: String, company: String, contextStr: String, onResult: (String) -> Unit) {
        viewModelScope.launch {
            val summary = GeminiAiHelper.researchProfile(name, role, company, contextStr)
            onResult(summary)
        }
    }

    fun getMutualProfiles(otherConnectionIds: List<String>, onResult: (List<UserProfile>) -> Unit) {
        viewModelScope.launch {
            val user = _userProfile.value
            val currentUid = getCurrentUserId()
            val myUser = user.username.trim().lowercase()
            val myIds = getSanitizedConnectionIds(user, currentUid)

            val cleanOtherIds = otherConnectionIds.filter { id ->
                val clean = id.trim().lowercase()
                clean != currentUid.lowercase() &&
                (myUser.isBlank() || clean != myUser) &&
                !clean.contains("rahul", ignoreCase = true)
            }.toSet()

            val mutualIds = cleanOtherIds.intersect(myIds).toList()
            if (mutualIds.isEmpty()) {
                onResult(emptyList())
                return@launch
            }
            // Fetch live profiles
            val profilesMap = cloudSyncManager.fetchLiveProfiles(mutualIds)
            val filteredProfiles = profilesMap.values.filter { p ->
                !isSelfCandidate(p.id, p.username, p.fullName, p.email, p.phone, user, currentUid)
            }.distinctBy {
                if (it.email.isNotBlank()) it.email.trim().lowercase()
                else it.fullName.trim().lowercase()
            }
            onResult(filteredProfiles)
        }
    }

    private fun initialRecommendedPeople(): List<RecommendedPerson> = emptyList()

    private fun startLiveSyncForConnections() {
        // Firestore snapshot listeners in refreshCloudData() provide real-time profile synchronization.
    }

    private fun initialRoomsList(): List<Room> = emptyList()

    private fun initialConnectionsList(): List<ConnectionContact> = emptyList()

    private fun initialConnectionRequests(): List<ConnectionRequest> = emptyList()

    private fun initialChatMessages(): Map<String, List<ChatMessage>> = emptyMap()    /**
     * Permanently deletes account:
     * 1. Removes all cloud Firestore documents & collections (profile, chats, rooms, requests, etc.)
     * 2. Clears local Room SQLite database (connections)
     * 3. Wipes all SharedPreferences (NeteroPrefs and netero_prefs)
     * 4. Deletes current FirebaseAuth account session
     * 5. Resets all in-memory ViewModel states so state starts fresh
     */
    fun deleteAccountPermanently(onComplete: (Boolean) -> Unit) {
        viewModelScope.launch(kotlinx.coroutines.Dispatchers.IO) {
            val app = getApplication<android.app.Application>()
            val currentId = getCurrentUserId()
            val email = _userProfile.value.email
            val phone = _userProfile.value.phone
            val username = _userProfile.value.username
            val fullName = _userProfile.value.fullName

            val cloudDeleted = try {
                cloudSyncManager.permanentlyDeleteUserFromCloud(currentId, username, email, phone, fullName)
            } catch (e: Exception) {
                android.util.Log.e("NeteroViewModel", "Cloud account deletion failed", e)
                false
            }
            if (!cloudDeleted) {
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) {
                    onComplete(false)
                }
                return@launch
            }

            // Clear local files only after cloud deletion succeeds.
            try {
                app.filesDir.listFiles()?.forEach { it.deleteRecursively() }
                app.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
            } catch (e: Exception) {
                android.util.Log.w("NeteroViewModel", "Local file cleanup warning", e)
            }

            try {
                connectionDao.deleteAllConnections()
                com.example.data.local.NeteroDatabase.getDatabase(app).clearAllTables()
            } catch (e: Exception) {
                android.util.Log.e("NeteroViewModel", "Error deleting local data: ${e.message}")
            }

            try {
                app.getSharedPreferences(app.packageName + "_preferences", android.content.Context.MODE_PRIVATE).edit().clear().commit()
                app.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE).edit().clear().commit()
                app.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).edit().clear().commit()
            } catch (e: Exception) {
                android.util.Log.e("NeteroViewModel", "Error clearing prefs: ${e.message}")
            }

            // Auth deletion may require recent authentication. Never claim full deletion if it fails.
            val authDeleted = try {
                val authUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
                if (authUser == null) true else {
                    authUser.delete().await()
                    true
                }
            } catch (e: Exception) {
                android.util.Log.e("NeteroViewModel", "FirebaseAuth deletion failed", e)
                false
            }
            if (!authDeleted) {
                try { com.google.firebase.auth.FirebaseAuth.getInstance().signOut() } catch (_: Exception) {}
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onComplete(false) }
                return@launch
            }

            try { com.google.firebase.auth.FirebaseAuth.getInstance().signOut() } catch (_: Exception) {}
            _userProfile.value = UserProfile()
            _connectionsList.value = emptyList()
            _connectionRequests.value = emptyList()
            _chatMessages.value = emptyMap()
            _notifications.value = emptyList()
            _profileViews.value = emptyList()
            _roomsList.value = emptyList()
            _supportTickets.value = emptyList()

            kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Main) { onComplete(true) }
        }
    }

    fun logoutUser(onComplete: () -> Unit) {
        viewModelScope.launch {
            try {
                com.google.firebase.auth.FirebaseAuth.getInstance().signOut()
            } catch (_: Exception) {}
            _userProfile.value = UserProfile()
            _connectionsList.value = emptyList()
            _connectionRequests.value = emptyList()
            _chatMessages.value = emptyMap()
            onComplete()
        }
    }

    fun restoreUserProfile(profile: UserProfile) {
        _userProfile.value = profile
        saveProfileToLocalPrefs(profile)
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val localEntities = connectionDao.getAllConnectionsList()
                if (localEntities.isNotEmpty()) {
                    _connectionsList.value = localEntities.map { it.toContact() }
                }
            } catch (_: Exception) {}
            try {
                val currentId = getCurrentUserId()
                launch {
                    cloudSyncManager.listenToConnections(currentId).collect { remoteConnections ->
                        if (remoteConnections.isNotEmpty()) {
                            remoteConnections.forEach { contact ->
                                connectionDao.insertConnection(contact.toEntity())
                            }
                            _connectionsList.value = connectionDao.getAllConnectionsList().map { it.toContact() }
                        }
                    }
                }
                launch {
                    cloudSyncManager.listenToChatMessages(currentId).collect { remoteMessages ->
                        _chatMessages.update { map ->
                            val newMap = map.toMutableMap()
                            remoteMessages.groupBy { it.contactId }.forEach { (contactId, msgs) ->
                                val current = newMap[contactId] ?: emptyList()
                                val combined = (msgs + current).distinctBy { it.id }.sortedBy { it.timestamp }
                                newMap[contactId] = combined
                            }
                            newMap
                        }
                    }
                }
            } catch (_: Exception) {}
        }
    }

}
