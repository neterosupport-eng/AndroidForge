package com.example.ui.screens

import com.example.ui.components.PullToRefreshLayout
import androidx.compose.material.icons.filled.Call

import com.example.data.model.UserProfile
import android.content.Intent
import android.net.Uri
import android.provider.ContactsContract
import androidx.compose.material.icons.filled.Link
import androidx.compose.ui.platform.LocalContext
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SearchOff
import androidx.compose.ui.text.style.TextAlign

import androidx.compose.material.icons.filled.Phone

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.CloudSync
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Sensors
import androidx.compose.material.icons.filled.Sync
import android.Manifest
import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.os.Build
import android.widget.Toast
import com.example.data.api.GeminiAiHelper
import com.example.receivers.FollowUpReceiver
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState

import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Message
import androidx.compose.material.icons.filled.NoteAdd
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Send
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ChatMessage
import com.example.data.model.ConnectionContact
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.NeteroTheme
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay
import androidx.compose.runtime.rememberCoroutineScope

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ConnectionsScreen(
    connectionsList: List<ConnectionContact>,
    chatMessages: Map<String, List<ChatMessage>> = emptyMap(),
    searchQuery: String,
    onSearchQueryChange: (String) -> Unit,
    selectedFilterTag: String,
    onSelectFilterTag: (String) -> Unit,
    selectedContactForSheet: ConnectionContact?,
    onSelectContact: (ConnectionContact?) -> Unit,
    onUpdateNotes: (String, String) -> Unit,
    onNavigateToChat: (String) -> Unit = {},
    onOpenContactProfile: (ConnectionContact) -> Unit = {},
    onUpdateContact: (ConnectionContact) -> Unit = {},
    onDeleteContact: (String) -> Unit = {},
    onHandleRemoteUpdate: (String, String, String) -> Unit = { _, _, _ -> },
    onHandlePaperScan: (String, String, String) -> Unit = { _, _, _ -> },
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {},
    userProfile: UserProfile? = null,
    onRefresh: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    var isRefreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    var selectedTab by remember { mutableStateOf("Directory") } // "Directory" or "Messages"
    val filterTags = listOf("All")

    val filteredList = connectionsList.filter { contact ->
        val matchesQuery = searchQuery.isBlank() ||
                contact.name.contains(searchQuery, ignoreCase = true) ||
                contact.jobTitle.contains(searchQuery, ignoreCase = true) ||
                contact.company.contains(searchQuery, ignoreCase = true) ||
                contact.notes.contains(searchQuery, ignoreCase = true)

        val matchesTag = selectedFilterTag == "All" || contact.tags.contains(selectedFilterTag)

        matchesQuery && matchesTag
    }

    PullToRefreshLayout(onRefresh = onRefresh, modifier = modifier) {
    Box(modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background)) {
        Box(modifier = Modifier.fillMaxSize()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(top = 20.dp, start = 20.dp, end = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
        // Top Header
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(
                        modifier = Modifier
                            .size(8.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF00E676))
                    )
                    Text(
                        text = "LIVE CLOUD SYNCED NETWORK",
                        style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
                Text(
                    text = "Connections & CRM",
                    style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Row(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(44.dp)
                        .clip(CircleShape)
                        .background(MaterialTheme.colorScheme.surface),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Chat,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary
                    )
                }
            }
        }

        // Top Column Selector (CRM Directory vs Messaging Column)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surface)
                .padding(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selectedTab == "Directory") AccentBlue else Color.Transparent)
                    .clickable { selectedTab = "Directory" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(16.dp))
                    Text(text = "Directory (${filteredList.size})", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                }
            }

            Box(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(10.dp))
                    .background(if (selectedTab == "Messages") AccentBlue else Color.Transparent)
                    .clickable { selectedTab = "Messages" }
                    .padding(vertical = 10.dp),
                contentAlignment = Alignment.Center
            ) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Message, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(16.dp))
                    Text(text = "Messaging Column", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                }
            }
        }

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = onSearchQueryChange,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_connections_input"),
            placeholder = { Text(text = if (selectedTab == "Directory") "Search by name, company, or note..." else "Search chat messages...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search",
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { onSearchQueryChange("") }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Clear",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(14.dp)
        )
        
        var connSearchHistory by remember { mutableStateOf(emptyList<String>()) }
        if (searchQuery.isEmpty() && connSearchHistory.isNotEmpty()) {
            Column(modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Recent Searches", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    androidx.compose.material3.TextButton(
                        onClick = { connSearchHistory = emptyList<String>() },
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("Clear History", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    connSearchHistory.forEach { historyItem ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .clickable { onSearchQueryChange(historyItem) }
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(12.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(historyItem, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        if (selectedTab == "Directory") {
            // Filter Chips Bar
            LazyRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                contentPadding = PaddingValues(end = 12.dp)
            ) {
                items(filterTags) { tag ->
                    val isSelected = tag == selectedFilterTag
                    FilterChip(
                        selected = isSelected,
                        onClick = { onSelectFilterTag(tag) },
                        label = {
                            Text(
                                text = tag,
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            )
                        },
                        modifier = Modifier.testTag("filter_tag_$tag"),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surface,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedContainerColor = AccentBlue,
                            selectedLabelColor = MaterialTheme.colorScheme.onBackground
                        ),
                        border = FilterChipDefaults.filterChipBorder(
                            borderColor = MaterialTheme.colorScheme.outline,
                            selectedBorderColor = AccentBlue,
                            enabled = true,
                            selected = isSelected
                        )
                    )
                }
            }

            // Connections Directory List
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    contentAlignment = Alignment.Center
                ) {
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        if (connectionsList.isEmpty()) {
                            Box(
                                modifier = Modifier
                                    .size(100.dp)
                                    .clip(CircleShape)
                                    .background(MaterialTheme.colorScheme.surfaceVariant),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(50.dp)
                                )
                            }
                            Text(
                                text = "Your network is empty",
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "Go to the QR tab to scan a card\nand make your first connection!",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.SearchOff,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "No connections match search",
                                style = MaterialTheme.typography.bodyLarge,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(12.dp),
                    contentPadding = PaddingValues(bottom = 100.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    items(filteredList, key = { it.id }) { contact ->
                        ConnectionItemCard(
                            contact = contact,
                            onClick = { onOpenContactProfile(contact) },
                            onNavigateToChat = {
                                if (contact.isNeteroAccount()) onNavigateToChat(contact.id)
                                else Toast.makeText(context, "This contact is not on Netero yet. Use WhatsApp, email, or invite them to Netero.", Toast.LENGTH_SHORT).show()
                            }
                        )
                    }
                }
            }
        } else {
            // Messaging Column View
            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 100.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredList, key = { "chat_${it.id}" }) { contact ->
                    val msgs = chatMessages[contact.id] ?: emptyList()
                    val lastMsg = msgs.lastOrNull()

                    MessagingColumnCard(
                        contact = contact,
                        lastMessage = lastMsg,
                        onClick = {
                            if (contact.isNeteroAccount()) onNavigateToChat(contact.id)
                            else Toast.makeText(context, "This contact is not on Netero yet.", Toast.LENGTH_SHORT).show()
                        }
                    )
                }
            }
        }
    }
    }

    }}

    // Contact Details Bottom Sheet
    selectedContactForSheet?.let { contact ->
        ContactDetailsBottomSheet(
            contact = contact,
            onDismiss = { onSelectContact(null) },
            onUpdateNotes = { newNotes -> onUpdateNotes(contact.id, newNotes) },
            onNavigateToChat = {
                if (contact.isNeteroAccount()) onNavigateToChat(contact.id)
                else Toast.makeText(context, "This contact is not on Netero yet. Use WhatsApp, email, or invite them to Netero.", Toast.LENGTH_SHORT).show()
            },
            onUpdateContact = { onUpdateContact(it) },
            onDeleteContact = { onDeleteContact(contact.id) },
            isPro = isPro,
            onNavigateToPaywall = onNavigateToPaywall,
            userProfile = userProfile
        )
    }
}

private fun ConnectionContact.isNeteroAccount(): Boolean {
    return !id.startsWith("scan_", ignoreCase = true) &&
        !source.equals("Paper OCR", ignoreCase = true)
}

@Composable
private fun ConnectionItemCard(
    contact: ConnectionContact,
    onClick: () -> Unit,
    onNavigateToChat: () -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(Color(contact.avatarBgHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        if (contact.profileImageUrl.isNotBlank()) {
                            coil.compose.AsyncImage(
                                model = com.example.utils.AttachmentHelper.getDisplayableImageModel(contact.profileImageUrl),
                                contentDescription = "Contact Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = contact.avatarInitial,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }

                    Column {
Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            // Relationship Health Dot
                            val daysSinceContact = (System.currentTimeMillis() - contact.lastContactedMillis) / (1000 * 60 * 60 * 24)
                            val healthColor = when {
                                daysSinceContact < 30 -> Color(0xFF4CAF50) // Green
                                daysSinceContact < 90 -> Color(0xFFFFC107) // Yellow
                                else -> Color(0xFFF44336) // Red
                            }
                            Box(modifier = Modifier.size(12.dp).clip(CircleShape).background(healthColor))
                            
                            Text(
                                text = contact.name,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onBackground,
                                modifier = Modifier.weight(1f, fill = false),
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(AccentBlue.copy(alpha = 0.2f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text("⚡ Live", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.primary, maxLines = 1, softWrap = false)
                            }
                        }
                        Text(
                            text = "${contact.jobTitle} @ ${contact.company}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        if (contact.locationMet.isNotBlank()) {
                            Text(
                                text = "📍 Met at: ${contact.locationMet}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                Text(
                    text = contact.dateConnected,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            // Private Notes Summary
            if (contact.notes.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.Top,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.EditNote,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = contact.notes,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Quick Actions Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    contact.tags.take(2).forEach { tag ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = tag, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(
                        onClick = {
                            if (contact.isNeteroAccount()) onNavigateToChat()
                            else Toast.makeText(context, "This contact is not on Netero yet. Use WhatsApp, email, or invite them to Netero.", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier
                            .height(36.dp)
                            .testTag("chat_button_${contact.id}"),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                        shape = RoundedCornerShape(10.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    ) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.Chat, contentDescription = "Chat", tint = Color.White, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Chat & Interact", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                    }
                }
            }
        }
    }
}

@Composable
private fun MessagingColumnCard(
    contact: ConnectionContact,
    lastMessage: ChatMessage?,
    onClick: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(18.dp))
            .clickable { onClick() }
            .testTag("messaging_card_${contact.id}"),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(52.dp)
                    .clip(CircleShape)
                    .background(Color(contact.avatarBgHex)),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = contact.avatarInitial,
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = contact.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = lastMessage?.timestamp ?: contact.dateConnected,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = "${contact.jobTitle} • ${contact.company}",
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Medium),
                    color = MaterialTheme.colorScheme.primary,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = lastMessage?.let { if (it.isFromMe) "You: ${it.text}" else it.text }
                        ?: "Connected via ${contact.source}. Tap to start conversation...",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.8f),
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
            }

            IconButton(
                onClick = onClick,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(AccentBlue.copy(alpha = 0.15f))
                    .size(36.dp)
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Chat,
                    contentDescription = "Open Chat",
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class, ExperimentalPermissionsApi::class)
@Composable
private fun ContactDetailsBottomSheet(
    contact: ConnectionContact,
    onDismiss: () -> Unit,
    onUpdateNotes: (String) -> Unit,
    onNavigateToChat: () -> Unit = {},
    onUpdateContact: (ConnectionContact) -> Unit = {},
    onDeleteContact: () -> Unit = {},
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {},
    userProfile: UserProfile? = null
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var editingNotes by remember { mutableStateOf(contact.notes) }
    var isEditing by remember { mutableStateOf(false) }
    var isEditingContact by remember { mutableStateOf(false) }
    var editName by remember { mutableStateOf(contact.name) }
    var editRole by remember { mutableStateOf(contact.jobTitle) }
    var editCompany by remember { mutableStateOf(contact.company) }
    var editEmail by remember { mutableStateOf(contact.email) }
    var editPhone by remember { mutableStateOf(contact.phone) }
    var editLinkedin by remember { mutableStateOf(contact.linkedin) }
    val context = LocalContext.current
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    val scope = rememberCoroutineScope()
    var selectedReminderDays by remember { mutableStateOf<Int?>(null) }
    var showDeleteConfirmation by remember { mutableStateOf(false) }
    var showDoubleDeleteConfirmation by remember { mutableStateOf(false) }

    // AI Icebreakers & Follow-Up State
    var generatedResearch by remember { mutableStateOf<String?>(null) }
    var isGeneratingResearch by remember { mutableStateOf(false) }
    var generatedIcebreakers by remember { mutableStateOf<List<String>>(emptyList()) }
    var isGeneratingIcebreakers by remember { mutableStateOf(false) }
    var generatedFollowUp by remember { mutableStateOf<String?>(null) }
    var isGeneratingFollowUp by remember { mutableStateOf(false) }

    val notificationPermissionState = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
        rememberPermissionState(permission = Manifest.permission.POST_NOTIFICATIONS)
    } else null

    if (showDeleteConfirmation) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteConfirmation = false },
            title = { Text("Delete Connection?", color = MaterialTheme.colorScheme.onBackground) },
            text = { Text("Are you sure you want to remove ${contact.name} from your CRM? This cannot be undone.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        showDeleteConfirmation = false
                        showDoubleDeleteConfirmation = true
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text("Delete", color = MaterialTheme.colorScheme.onBackground)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDeleteConfirmation = false },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Text("Cancel")
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }

    if (showDoubleDeleteConfirmation) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDoubleDeleteConfirmation = false },
            title = { Text("Are you absolutely sure?", color = MaterialTheme.colorScheme.onBackground) },
            text = { Text("Do you really want to delete ${contact.name}? This is your final confirmation.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
            confirmButton = {
                Button(
                    onClick = {
                        showDoubleDeleteConfirmation = false
                        onDeleteContact()
                        onDismiss()
                        Toast.makeText(context, "${contact.name} removed.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF5252))
                ) {
                    Text("Yes, Delete", color = MaterialTheme.colorScheme.onBackground)
                }
            },
            dismissButton = {
                OutlinedButton(
                    onClick = { showDoubleDeleteConfirmation = false },
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.onPrimary)
                ) {
                    Text("Cancel")
                }
            },
            containerColor = MaterialTheme.colorScheme.surfaceVariant
        )
    }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = MaterialTheme.colorScheme.surface,
        scrimColor = Color.Black.copy(alpha = 0.7f)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 24.dp)
                .padding(bottom = 40.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Sheet Actions
            Row(
                modifier = Modifier.fillMaxWidth().padding(bottom = 0.dp),
                horizontalArrangement = Arrangement.End
            ) {
                var showMenu by remember { mutableStateOf(false) }
                Box {
                    IconButton(onClick = { showMenu = true }, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.MoreVert, contentDescription = "Options", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(20.dp))
                    }
                    androidx.compose.material3.DropdownMenu(
                        expanded = showMenu,
                        onDismissRequest = { showMenu = false }
                    ) {
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("Remove Connection") },
                            onClick = {
                                showMenu = false
                                showDeleteConfirmation = true
                            },
                            leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                        )
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("Block User") },
                            onClick = {
                                showMenu = false
                                android.widget.Toast.makeText(context, "User blocked successfully.", android.widget.Toast.LENGTH_SHORT).show()
                                onDeleteContact()
                            },
                            leadingIcon = { Icon(Icons.Default.Block, contentDescription = null) }
                        )
                        androidx.compose.material3.DropdownMenuItem(
                            text = { Text("Report User") },
                            onClick = {
                                showMenu = false
                                android.widget.Toast.makeText(context, "User reported. Our team will review this account.", android.widget.Toast.LENGTH_SHORT).show()
                                onDeleteContact()
                            },
                            leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null) }
                        )
                    }
                }
            }
            
            // Header Profile Info
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(contact.avatarBgHex)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = contact.avatarInitial,
                        style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }

                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
Text(
                            text = contact.name,
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground,
                            modifier = Modifier.weight(1f, fill = false),
                            maxLines = 1,
                            overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                        )
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(Color(0xFF00E676).copy(alpha = 0.15f))
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(
                                text = "Live Cloud Synced",
                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                color = Color(0xFF00E676),
                                maxLines = 1,
                                softWrap = false
                            )
                        }
                    }
                    Text(
                        text = "${contact.jobTitle} @ ${contact.company}",
                        style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Connected: ${contact.dateConnected}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            


            // Quick Action Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                QuickActionButton(
                    icon = Icons.AutoMirrored.Filled.Chat,
                    label = "Chat",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (contact.isNeteroAccount()) onNavigateToChat()
                        else Toast.makeText(context, "This contact is not on Netero yet. Use WhatsApp, email, or invite them to Netero.", Toast.LENGTH_SHORT).show()
                    }
                )
                QuickActionButton(
                    icon = Icons.Default.Email,
                    label = "Email",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (contact.email.isNotBlank()) {
                            val intent = Intent(Intent.ACTION_SENDTO).apply {
                                data = android.net.Uri.parse("mailto:${contact.email}")
                            }
                            try { context.startActivity(intent) } catch (e: Exception) {}
                        }
                    }
                )
                QuickActionButton(
                    icon = Icons.Default.Phone,
                    label = "WhatsApp",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        if (contact.phone.isNotBlank()) {
                            val intent = Intent(Intent.ACTION_VIEW).apply {
                                data = android.net.Uri.parse("https://wa.me/${contact.phone}?text=Hi%20${contact.name},%20let's%20connect!")
                            }
                            try { context.startActivity(intent) } catch (e: Exception) {}
                        }
                    }
                )
                QuickActionButton(
                    icon = Icons.Default.Sync,
                    label = "Export",
                    modifier = Modifier.weight(1f),
                    onClick = {
                        val intent = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                            type = ContactsContract.RawContacts.CONTENT_TYPE
                            putExtra(ContactsContract.Intents.Insert.NAME, contact.name)
                            putExtra(ContactsContract.Intents.Insert.COMPANY, contact.company)
                            putExtra(ContactsContract.Intents.Insert.JOB_TITLE, contact.jobTitle)
                            putExtra(ContactsContract.Intents.Insert.EMAIL, contact.email)
                            putExtra(ContactsContract.Intents.Insert.PHONE, contact.phone)
                        }
                        context.startActivity(intent)
                    }
                )
            }

            // AI Icebreakers & Follow-up Suite
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f), RoundedCornerShape(16.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(18.dp))
                            Text(
                                text = "NETERO AI ASSISTANT",
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp),
                                color = MaterialTheme.colorScheme.onBackground
                            )
                        }
                    }

                        Button(
                            onClick = {
                                if (!isPro) { onNavigateToPaywall() } else if (!isGeneratingResearch) {
                                    isGeneratingResearch = true
                                    scope.launch {
                                        generatedResearch = GeminiAiHelper.researchProfile(
                                            name = contact.name,
                                            role = contact.jobTitle,
                                            company = contact.company,
                                            context = contact.notes
                                        )
                                        isGeneratingResearch = false
                                    }
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(40.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.tertiary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text(if (isGeneratingResearch) "Researching..." else "✨ Research ${contact.name}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                            onClick = {
                                if (!isPro) { onNavigateToPaywall() } else if (!isGeneratingIcebreakers) {
                                    isGeneratingIcebreakers = true
                                    scope.launch {
                                        val myContext = if (userProfile != null) {
                                            "My Profile: ${userProfile.fullName} (${userProfile.jobTitle} at ${userProfile.company}, Industry: ${userProfile.industry}, Interests: ${userProfile.interests.joinToString(", ")}). Connection Notes: ${contact.notes}"
                                        } else {
                                            contact.notes
                                        }
                                        generatedIcebreakers = GeminiAiHelper.generateIcebreakers(
                                            contactName = contact.name,
                                            contactRole = contact.jobTitle,
                                            contactCompany = contact.company,
                                            contextNotes = myContext
                                        )
                                        isGeneratingIcebreakers = false
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).height(40.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.primary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text(if (isGeneratingIcebreakers) "Generating..." else "✨ Icebreakers", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }

                        Button(
                            onClick = {
                                if (!isPro) { onNavigateToPaywall() } else if (!isGeneratingFollowUp) {
                                    isGeneratingFollowUp = true
                                    scope.launch {
                                        val myGoals = if (userProfile != null) {
                                            "I am ${userProfile.fullName}, working as ${userProfile.jobTitle} at ${userProfile.company} in ${userProfile.industry}. My goals: Explore synergy and high-impact collaboration between ${userProfile.industry} and ${contact.company}."
                                        } else {
                                            "Collaborate and explore industry synergies"
                                        }
                                        val industry = contact.tags.firstOrNull { it != "QR" && it != contact.source }
                                            ?: (if (contact.notes.contains("INDUSTRY:")) Regex("INDUSTRY:([^|]+)").find(contact.notes)?.groupValues?.get(1)?.trim() else null)
                                            ?: contact.company
                                        generatedFollowUp = GeminiAiHelper.generateFollowUpDraft(
                                            contactName = contact.name,
                                            contactRole = contact.jobTitle,
                                            contactCompany = contact.company,
                                            meetingContext = contact.notes.ifBlank { "Met via Netero network" },
                                            userGoals = myGoals,
                                            contactIndustry = industry
                                        )
                                        isGeneratingFollowUp = false
                                    }
                                }
                            },
                            modifier = Modifier.weight(1f).height(40.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.onPrimary),
                            shape = RoundedCornerShape(10.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp)
                        ) {
                            Text(if (isGeneratingFollowUp) "Drafting..." else "✨ Follow-Up Draft", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        }
                    }

                    // Display Generated Research
                    if (generatedResearch != null) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("AI Insight:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = generatedResearch!!,
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Display Generated Icebreakers
                    if (generatedIcebreakers.isNotEmpty()) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Icebreaker Options:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            generatedIcebreakers.forEach { icebreaker ->
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                                        .clickable {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                            clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Icebreaker", icebreaker))
                                            Toast.makeText(context, "Copied to clipboard!", Toast.LENGTH_SHORT).show()
                                        }
                                        .padding(10.dp)
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                        Text(text = icebreaker, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
                                        Icon(imageVector = Icons.Default.ContentCopy, contentDescription = "Copy", tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                                    }
                                }
                            }
                        }
                    }

                    // Display Generated Follow-Up
                    generatedFollowUp?.let { draft ->
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Follow-Up Message Draft:", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.5f))
                                    .padding(10.dp)
                            ) {
                                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Text(text = draft, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground)
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.End,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Action buttons: Copy, WhatsApp, Email
                                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                            OutlinedButton(
                                                onClick = {
                                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as android.content.ClipboardManager
                                                    clipboard.setPrimaryClip(android.content.ClipData.newPlainText("Follow Up Draft", draft))
                                                    Toast.makeText(context, "Draft copied to clipboard!", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.height(34.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(12.dp))
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text("Copy", style = MaterialTheme.typography.labelSmall)
                                            }
                                            // Send via WhatsApp
                                            Button(
                                                onClick = {
                                                    try {
                                                        val cleanPhone = contact.phone.replace(Regex("[^0-9+]"), "")
                                                        val encText = java.net.URLEncoder.encode(draft, "UTF-8")
                                                        val uri = if (cleanPhone.isNotBlank()) {
                                                            android.net.Uri.parse("https://api.whatsapp.com/send?phone=" + cleanPhone.removePrefix("+") + "&text=" + encText)
                                                        } else {
                                                            android.net.Uri.parse("https://api.whatsapp.com/send?text=" + encText)
                                                        }
                                                        val intent = Intent(Intent.ACTION_VIEW, uri)
                                                        context.startActivity(intent)
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "WhatsApp not installed or error opening WhatsApp", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.height(34.dp),
                                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 0.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF25D366)),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("WhatsApp", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = Color.White)
                                            }
                                            // Send via Email
                                            Button(
                                                onClick = {
                                                    try {
                                                        val intent = Intent(Intent.ACTION_SENDTO).apply {
                                                            data = android.net.Uri.parse("mailto:")
                                                            if (contact.email.isNotBlank()) {
                                                                putExtra(Intent.EXTRA_EMAIL, arrayOf(contact.email))
                                                            }
                                                            putExtra(Intent.EXTRA_SUBJECT, "Great connecting with you on Netero!")
                                                            putExtra(Intent.EXTRA_TEXT, draft)
                                                        }
                                                        context.startActivity(Intent.createChooser(intent, "Send Email"))
                                                    } catch (e: Exception) {
                                                        Toast.makeText(context, "No email app found", Toast.LENGTH_SHORT).show()
                                                    }
                                                },
                                                modifier = Modifier.height(34.dp),
                                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text("Email", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), maxLines = 1, softWrap = false)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Tags
            if (contact.tags.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "TAGS",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    FlowRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        contact.tags.forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = tag,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            }

            // Private Notes Section
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "PRIVATE CRM NOTES",
                        style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    IconButton(
                        onClick = { isEditing = !isEditing },
                        modifier = Modifier.size(32.dp)
                    ) {
                        Icon(
                            imageVector = if (isEditing) Icons.Default.Close else Icons.AutoMirrored.Filled.NoteAdd,
                            contentDescription = "Edit Notes",
                            tint = Color.White
                        )
                    }
                }

                if (isEditing) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedTextField(
                            value = editingNotes,
                            onValueChange = { editingNotes = it },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("Add private follow-up notes...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                            maxLines = 4,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                focusedBorderColor = AccentBlue,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        Button(
                            onClick = {
                                onUpdateNotes(editingNotes)
                                isEditing = false
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(44.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Save Note", fontWeight = FontWeight.Bold)
                        }
                    }
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = contact.notes.ifBlank { "No notes added yet. Tap icon above to add private CRM notes." },
                            style = MaterialTheme.typography.bodyMedium,
                            color = if (contact.notes.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            }

            // AI Smart Follow-up Reminder (Customizable)
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(
                    text = "AI FOLLOW-UP REMINDER",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val reminderOptions = listOf(
                        Pair("1 Day", 1),
                        Pair("3 Days", 3),
                        Pair("1 Week", 7)
                    )
                    
                    reminderOptions.forEach { (label, days) ->
                        val isSelected = (selectedReminderDays == days)
                        Button(
                            onClick = {
                                if (notificationPermissionState != null && !notificationPermissionState.status.isGranted) {
                                    notificationPermissionState.launchPermissionRequest()
                                } else {
                                    val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
                                    val intent = Intent(context, FollowUpReceiver::class.java).apply {
                                        putExtra("contactName", contact.name)
                                        val parsedTopic = if (contact.notes.isNotBlank()) contact.notes.take(30) + "..." else "recent discussions"
                                        putExtra("customMessage", "Time to follow up with ${contact.name} about $parsedTopic. Here is a draft email...")
                                    }
                                    val pendingIntent = PendingIntent.getBroadcast(
                                        context, contact.name.hashCode(), intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
                                    )
                                    val triggerAtMillis = System.currentTimeMillis() + (days * 24 * 60 * 60 * 1000L)
                                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerAtMillis, pendingIntent)
                                    
                                    selectedReminderDays = days
                                    Toast.makeText(context, "✨ AI reminder set for $label", Toast.LENGTH_SHORT).show()
                                }
                            },
                            modifier = Modifier.weight(1f).height(44.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSelected) Color(0xFF00E676) else Color(0xFF00E676).copy(alpha = 0.15f),
                                contentColor = if (isSelected) MaterialTheme.colorScheme.background else Color(0xFF00E676)
                            ),
                            shape = RoundedCornerShape(12.dp),
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(text = label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        }
                    }
                }
            }

            // Contact Info
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(
                    text = "CONTACT DATA",
                    style = MaterialTheme.typography.labelSmall.copy(letterSpacing = 1.5.sp),
                    color = MaterialTheme.colorScheme.onBackground
                )
                if (contact.email.isNotBlank()) Text(text = "Email: ${contact.email}", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.bodyMedium)
                if (contact.phone.isNotBlank()) Text(text = "Phone: ${contact.phone}", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.bodyMedium)
                
                // One-Click LinkedIn Integration - Only display and click if link exists
                val cleanLinkedin = contact.linkedin.trim()
                val isValidLinkedin = cleanLinkedin.isNotBlank() && 
                    cleanLinkedin != "." && cleanLinkedin != ".." && cleanLinkedin != "-" && 
                    !cleanLinkedin.equals("null", ignoreCase = true) && 
                    !cleanLinkedin.equals("none", ignoreCase = true) &&
                    cleanLinkedin.length >= 3

                if (isValidLinkedin) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically, 
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(Color(0xFF0077B5).copy(alpha = 0.2f)) // LinkedIn Blue Tint
                            .clickable {
                                try {
                                    val url = when {
                                        cleanLinkedin.startsWith("http://") || cleanLinkedin.startsWith("https://") -> cleanLinkedin
                                        cleanLinkedin.contains("linkedin.com") -> "https://$cleanLinkedin"
                                        else -> "https://www.linkedin.com/in/$cleanLinkedin"
                                    }
                                    uriHandler.openUri(url)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "Could not open LinkedIn profile.", Toast.LENGTH_SHORT).show()
                                }
                            }
                            .padding(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Language, contentDescription = "LinkedIn", tint = Color(0xFF0077B5), modifier = Modifier.size(18.dp))
                        Text(text = "Connect on LinkedIn: $cleanLinkedin", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }

                if (contact.portfolio.isNotBlank()) {
                    val cleanPort = contact.portfolio.trim()
                    Row(
                        verticalAlignment = Alignment.CenterVertically, 
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f))
                            .clickable {
                                val url = if (cleanPort.startsWith("http://") || cleanPort.startsWith("https://")) cleanPort else "https://$cleanPort"
                                try {
                                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply { addFlags(Intent.FLAG_ACTIVITY_NEW_TASK) }
                                    context.startActivity(intent)
                                } catch (e: Exception) {
                                    try {
                                        uriHandler.openUri(url)
                                    } catch (_: Exception) {
                                        Toast.makeText(context, "Could not open portfolio: $cleanPort", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            .padding(10.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Link, contentDescription = "Portfolio", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                        Text(text = "View Portfolio / Featured Work: $cleanPort", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                    }
                }
            }
            

        }
    }
}

@Composable
private fun QuickActionButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    modifier: Modifier = Modifier,
    onClick: () -> Unit = {}
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(12.dp))
            .clickable { onClick() }
            .padding(vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(imageVector = icon, contentDescription = label, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(text = label, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp), color = Color.White)
        }
    }
}

@Preview(showBackground = true)
@Composable
fun ConnectionsScreenPreview() {
    NeteroTheme(darkTheme = true) {
        ConnectionsScreen(
            connectionsList = emptyList(),
            searchQuery = "",
            onSearchQueryChange = {},
            selectedFilterTag = "All",
            onSelectFilterTag = {},
            selectedContactForSheet = null,
            onSelectContact = {},
            onUpdateNotes = { _, _ -> }
        )
    }
}
