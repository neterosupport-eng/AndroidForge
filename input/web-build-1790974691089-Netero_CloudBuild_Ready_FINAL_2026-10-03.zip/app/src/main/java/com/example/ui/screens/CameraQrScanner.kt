@file:OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)

package com.example.ui.screens

import android.Manifest
import android.util.Log
import kotlin.OptIn
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import com.example.ui.theme.AccentBlue
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.google.mlkit.vision.barcode.BarcodeScannerOptions
import com.google.mlkit.vision.barcode.BarcodeScanning
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.common.InputImage
import java.util.concurrent.Executors

@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun CameraQrScanner(
    onQrCodeScanned: (String) -> Unit,
    captureTrigger: Long = 0L,
    onImageCaptured: ((ByteArray) -> Unit)? = null
) {
    val cameraPermissionState = rememberPermissionState(permission = Manifest.permission.CAMERA)

    LaunchedEffect(Unit) {
        if (!cameraPermissionState.status.isGranted) {
            cameraPermissionState.launchPermissionRequest()
        }
    }

    if (cameraPermissionState.status.isGranted) {
        CameraPreview(
            onQrCodeScanned = onQrCodeScanned,
            captureTrigger = captureTrigger,
            onImageCaptured = onImageCaptured
        )
    } else {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.surface)
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("Camera permission is required to scan QR codes.", color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { cameraPermissionState.launchPermissionRequest() },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                ) {
                    Text("Grant Permission")
                }
            }
        }
    }
}

@Composable
private fun CameraPreview(
    onQrCodeScanned: (String) -> Unit,
    captureTrigger: Long,
    onImageCaptured: ((ByteArray) -> Unit)?
) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val currentOnQrCodeScanned by rememberUpdatedState(onQrCodeScanned)
    val currentOnImageCaptured by rememberUpdatedState(onImageCaptured)
    
    val executor = remember { Executors.newSingleThreadExecutor() }
    var imageCaptureUseCase by remember { mutableStateOf<ImageCapture?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                val cameraProviderFuture = androidx.camera.lifecycle.ProcessCameraProvider.getInstance(context)
                cameraProviderFuture.addListener({
                    try {
                        val cameraProvider = cameraProviderFuture.get()
                        cameraProvider.unbindAll()
                    } catch(e: Exception) {}
                }, androidx.core.content.ContextCompat.getMainExecutor(context))
            } catch(e: Exception) {}
            
            // Delay executor shutdown slightly to allow unbind to complete without deadlocking
            android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
                try {
                    executor.shutdown()
                } catch(e: Exception) {}
            }, 500)
        }
    }

    LaunchedEffect(captureTrigger) {
        if (captureTrigger > 0L && imageCaptureUseCase != null) {
            imageCaptureUseCase?.takePicture(ContextCompat.getMainExecutor(context), object : ImageCapture.OnImageCapturedCallback() {
                override fun onCaptureSuccess(image: ImageProxy) {
                    try {
                        val rotationDegrees = image.imageInfo.rotationDegrees
                        val rawBitmap = image.toBitmap()
                        val matrix = android.graphics.Matrix()
                        if (rotationDegrees != 0) {
                            matrix.postRotate(rotationDegrees.toFloat())
                        }
                        val rotatedBitmap = if (rotationDegrees != 0) {
                            android.graphics.Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
                        } else {
                            rawBitmap
                        }
                        val maxDim = 1280
                        val scaledBitmap = if (rotatedBitmap.width > maxDim || rotatedBitmap.height > maxDim) {
                            val scale = maxDim.toFloat() / maxOf(rotatedBitmap.width, rotatedBitmap.height)
                            android.graphics.Bitmap.createScaledBitmap(
                                rotatedBitmap,
                                (rotatedBitmap.width * scale).toInt(),
                                (rotatedBitmap.height * scale).toInt(),
                                true
                            )
                        } else {
                            rotatedBitmap
                        }
                        val out = java.io.ByteArrayOutputStream()
                        scaledBitmap.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, out)
                        val jpegBytes = out.toByteArray()
                        image.close()
                        currentOnImageCaptured?.invoke(jpegBytes)
                    } catch (e: Exception) {
                        Log.e("CameraPreview", "Error converting image proxy to JPEG bitmap, falling back to buffer", e)
                        try {
                            val buffer = image.planes[0].buffer
                            val bytes = ByteArray(buffer.capacity())
                            buffer.get(bytes)
                            image.close()
                            currentOnImageCaptured?.invoke(bytes)
                        } catch (_: Exception) {
                            image.close()
                        }
                    }
                }
                override fun onError(exception: ImageCaptureException) {
                    Log.e("CameraPreview", "Photo capture failed", exception)
                }
            })
        }
    }

    AndroidView(
        factory = { ctx ->
            val previewView = PreviewView(ctx)
            val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                
                val preview = Preview.Builder().build().also {
                    it.surfaceProvider = previewView.surfaceProvider
                }
                
                val imageAnalysis = ImageAnalysis.Builder()
                    .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                    .build()
                    .also {
                        it.setAnalyzer(
                            executor,
                            QrCodeAnalyzer { qrContent ->
                                android.os.Handler(android.os.Looper.getMainLooper()).post { currentOnQrCodeScanned(qrContent) }
                            }
                        )
                    }
                
                val imageCapture = ImageCapture.Builder().build()
                imageCaptureUseCase = imageCapture

                val cameraSelector = CameraSelector.DEFAULT_BACK_CAMERA
                try {
                    cameraProvider.unbindAll()
                    cameraProvider.bindToLifecycle(
                        lifecycleOwner,
                        cameraSelector,
                        preview,
                        imageCapture,
                        imageAnalysis
                    )
                } catch (exc: Exception) {
                    Log.e("CameraPreview", "Use case binding failed", exc)
                }
            }, ContextCompat.getMainExecutor(ctx))
            previewView
        },
        onRelease = {
            val cameraProviderFuture = ProcessCameraProvider.getInstance(context)
            cameraProviderFuture.addListener({
                val cameraProvider = cameraProviderFuture.get()
                cameraProvider.unbindAll()
            }, ContextCompat.getMainExecutor(context))
        },
        modifier = Modifier.fillMaxSize()
    )
}

private class QrCodeAnalyzer(
    private val onQrCodeScanned: (String) -> Unit
) : ImageAnalysis.Analyzer {
    private val options = BarcodeScannerOptions.Builder()
        .setBarcodeFormats(Barcode.FORMAT_QR_CODE)
        .build()
    private val scanner = BarcodeScanning.getClient(options)
    private var lastScannedContent: String? = null
    private var lastScannedTime: Long = 0L

    @androidx.annotation.OptIn(androidx.camera.core.ExperimentalGetImage::class)
    @android.annotation.SuppressLint("UnsafeOptInUsageError")
    override fun analyze(imageProxy: ImageProxy) {
        val mediaImage = imageProxy.image
        if (mediaImage != null) {
            val image = InputImage.fromMediaImage(mediaImage, imageProxy.imageInfo.rotationDegrees)
            
            // Try Barcode scanning first
            scanner.process(image)
                .addOnSuccessListener { barcodes ->
                    if (barcodes.isNotEmpty()) {
                        for (barcode in barcodes) {
                            barcode.rawValue?.let { content ->
                                val currentTime = System.currentTimeMillis()
                                if (content != lastScannedContent || currentTime - lastScannedTime > 2000) {
                                    lastScannedContent = content
                                    lastScannedTime = currentTime
                                    onQrCodeScanned(content)
                                }
                                break
                            }
                        }
                    }
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } else {
            imageProxy.close()
        }
    }
}
