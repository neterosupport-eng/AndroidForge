package com.example.data.model

data class ChatMessage(
    val id: String,
    val contactId: String,
    val text: String,
    val timestamp: String,
    val isFromMe: Boolean,
    val status: String = "Delivered", // Sent, Delivered, Read
    val sentAtMillis: Long = System.currentTimeMillis(),
    val isEdited: Boolean = false,
    val isDeleted: Boolean = false,
    val senderId: String = "",
    val attachmentUrl: String? = null,
    val attachmentType: String? = null,
    val attachmentName: String? = null,
    val attachmentMimeType: String? = null
)
