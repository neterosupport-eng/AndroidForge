package com.example.data.model

enum class PrivacyLevel(val label: String) {
    PUBLIC("Public"),
    CONNECTIONS_ONLY("Connections Only"),
    PRIVATE("Private"),
    LOCKED("Locked")
}

data class NeteroLockSettings(
    val phoneVisibility: PrivacyLevel = PrivacyLevel.CONNECTIONS_ONLY,
    val emailVisibility: PrivacyLevel = PrivacyLevel.CONNECTIONS_ONLY,
    val socialVisibility: PrivacyLevel = PrivacyLevel.PUBLIC,
    val profileDiscovery: PrivacyLevel = PrivacyLevel.PUBLIC,
    val portfolioVisibility: PrivacyLevel = PrivacyLevel.PUBLIC,
    val roomVisibility: Boolean = true
)
