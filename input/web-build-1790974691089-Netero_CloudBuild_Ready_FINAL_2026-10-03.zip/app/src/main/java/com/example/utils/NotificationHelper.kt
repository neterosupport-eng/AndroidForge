package com.example.utils

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.example.MainActivity
import com.example.R

object NotificationHelper {
    private const val TAG = "NotificationHelper"
    private var channelsCreated = false

    const val CHANNEL_ID_REQUESTS = "netero_channel_requests"
    const val CHANNEL_NAME_REQUESTS = "Connection Requests"

    const val CHANNEL_ID_MESSAGES = "netero_channel_messages"
    const val CHANNEL_NAME_MESSAGES = "Messages & Chats"

    const val CHANNEL_ID_ROOMS = "netero_channel_rooms"
    const val CHANNEL_NAME_ROOMS = "Room Discussions"

    fun createNotificationChannels(context: Context) {
        if (channelsCreated) return
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                ?: return

            // Channel for Connection Requests
            val requestChannel = NotificationChannel(
                CHANNEL_ID_REQUESTS,
                CHANNEL_NAME_REQUESTS,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when someone sends you a professional connection request"
                enableVibration(true)
                setShowBadge(true)
            }

            // Channel for Messages
            val messageChannel = NotificationChannel(
                CHANNEL_ID_MESSAGES,
                CHANNEL_NAME_MESSAGES,
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Alerts when you receive a new chat message or update"
                enableVibration(true)
                setShowBadge(true)
            }

            // Channel for Rooms
            val roomChannel = NotificationChannel(
                CHANNEL_ID_ROOMS,
                CHANNEL_NAME_ROOMS,
                NotificationManager.IMPORTANCE_DEFAULT
            ).apply {
                description = "Alerts for new room messages and discussions"
                setShowBadge(true)
            }

            notificationManager.createNotificationChannels(listOf(requestChannel, messageChannel, roomChannel))
            channelsCreated = true
            Log.d(TAG, "Notification channels initialized successfully")
        }
    }

    fun showConnectionRequestNotification(
        context: Context,
        senderName: String,
        senderTitle: String,
        requestId: String
    ) {
        try {
            createNotificationChannels(context)

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("navigate_to", "pending_connections")
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                requestId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            )

            val contentText = if (senderTitle.isNotBlank()) {
                "$senderName ($senderTitle) sent you a connection request."
            } else {
                "$senderName sent you a connection request."
            }

            val notification = NotificationCompat.Builder(context, CHANNEL_ID_REQUESTS)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("New Connection Request 🤝")
                .setContentText(contentText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(contentText))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_SOCIAL)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notificationManager = NotificationManagerCompat.from(context)
            try {
                notificationManager.notify("request_${requestId}".hashCode(), notification)
            } catch (e: SecurityException) {
                Log.w(TAG, "Notification permission not granted: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to display connection request notification", e)
        }
    }

    fun showChatMessageNotification(
        context: Context,
        senderName: String,
        messageText: String,
        contactId: String
    ) {
        try {
            createNotificationChannels(context)

            val intent = Intent(context, MainActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
                putExtra("navigate_to", "chat_detail")
                putExtra("contact_id", contactId)
            }

            val pendingIntent = PendingIntent.getActivity(
                context,
                contactId.hashCode(),
                intent,
                PendingIntent.FLAG_UPDATE_CURRENT or (if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) PendingIntent.FLAG_IMMUTABLE else 0)
            )

            val notification = NotificationCompat.Builder(context, CHANNEL_ID_MESSAGES)
                .setSmallIcon(R.mipmap.ic_launcher)
                .setContentTitle("$senderName 💬")
                .setContentText(messageText)
                .setStyle(NotificationCompat.BigTextStyle().bigText(messageText))
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_MESSAGE)
                .setAutoCancel(true)
                .setContentIntent(pendingIntent)
                .build()

            val notificationManager = NotificationManagerCompat.from(context)
            try {
                notificationManager.notify("chat_${contactId}".hashCode(), notification)
            } catch (e: SecurityException) {
                Log.w(TAG, "Notification permission not granted: ${e.message}")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to display chat notification", e)
        }
    }
}
