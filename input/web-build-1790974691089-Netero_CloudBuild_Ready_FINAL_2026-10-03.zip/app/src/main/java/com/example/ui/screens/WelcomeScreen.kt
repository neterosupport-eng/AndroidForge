package com.example.ui.screens

import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.KeyboardType

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.togetherWith
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.ui.res.painterResource
import com.example.R
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.tasks.await
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Info
import android.widget.Toast
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.ClickableText
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.platform.LocalUriHandler
import com.example.data.api.EmailOtpService
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.NeteroTheme

enum class AuthMethod {
    PHONE,
    EMAIL
}

enum class AuthStep {
    WELCOME,
    INPUT_CONTACT,
    VERIFY_OTP
}

@Composable
@Suppress("DEPRECATION")
fun WelcomeScreen(
    onNavigateToSetup: () -> Unit,
    onNavigateToHome: () -> Unit,
    onRestoreProfile: ((com.example.data.model.UserProfile) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var visible by remember { mutableStateOf(false) }
    var currentStep by remember { mutableStateOf(AuthStep.WELCOME) }
    var selectedMethod by remember { mutableStateOf(AuthMethod.EMAIL) }
    var isLogin by remember { mutableStateOf(false) }
    var contactInfo by remember { mutableStateOf("") }
    var selectedCountryCode by remember { mutableStateOf("+91") }
    var otpCode by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf("") }
    var isSendingOtp by remember { mutableStateOf(false) }
    var isVerifyingOtp by remember { mutableStateOf(false) }
    var isResendingOtp by remember { mutableStateOf(false) }
    var emailErrorMessage by remember { mutableStateOf<String?>(null) }
    var otpErrorMessage by remember { mutableStateOf<String?>(null) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()

    LaunchedEffect(Unit) {
        visible = true
    }

    Surface(
        modifier = modifier.fillMaxSize(),
        color = MaterialTheme.colorScheme.background
    ) {
        Box(
            modifier = Modifier.fillMaxSize()
        ) {
            // Ambient subtle background gradient glow
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            colors = listOf(
                                AccentBlue.copy(alpha = 0.18f),
                                Color.Transparent
                            ),
                            radius = 1200f
                        )
                    )
            )

            AnimatedVisibility(
                visible = visible,
                enter = fadeIn() + slideInVertically(initialOffsetY = { 80 }),
                modifier = Modifier.fillMaxSize()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 28.dp, vertical = 32.dp)
                        .verticalScroll(rememberScrollState()),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    AnimatedContent(
                        targetState = currentStep,
                        label = "auth_step_transition",
                        transitionSpec = {
                            fadeIn(animationSpec = tween(300)) togetherWith fadeOut(animationSpec = tween(300))
                        }
                    ) { step ->
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = if (step == AuthStep.WELCOME) Arrangement.SpaceBetween else Arrangement.Top
                        ) {
                            when (step) {
                                AuthStep.WELCOME -> {
                                    WelcomeContent(
                                        onEmailSignIn = {
                                            selectedMethod = AuthMethod.EMAIL
                                            contactInfo = ""
                                            otpCode = ""
                                            emailErrorMessage = null
                                            otpErrorMessage = null
                                            currentStep = AuthStep.INPUT_CONTACT
                                        }
                                    )
                                }
                                AuthStep.INPUT_CONTACT -> {
                                    InputContactContent(
                                        authMethod = selectedMethod,
                                        contactInfo = contactInfo,
                                        selectedCountryCode = selectedCountryCode,
                                        isSending = isSendingOtp,
                                        errorMessage = emailErrorMessage,
                                        onContactInfoChange = { 
                                            contactInfo = it 
                                            emailErrorMessage = null
                                        },
                                        onCountryCodeChange = { selectedCountryCode = it },
                                        onBack = { currentStep = AuthStep.WELCOME },
                                        onContinue = { 
                                            val trimmedEmail = contactInfo.trim().lowercase()
                                            if (trimmedEmail.isBlank()) {
                                                emailErrorMessage = "Please enter your Gmail / email address."
                                                return@InputContactContent
                                            }
                                            val emailPattern = android.util.Patterns.EMAIL_ADDRESS
                                            if (!emailPattern.matcher(trimmedEmail).matches() || !trimmedEmail.contains(".")) {
                                                emailErrorMessage = "Please enter a valid email address (e.g. name@gmail.com)"
                                                return@InputContactContent
                                            }

                                            emailErrorMessage = null
                                            isSendingOtp = true
                                            coroutineScope.launch {
                                                val auth = FirebaseAuth.getInstance()
                                                if (auth.currentUser == null) {
                                                    try { auth.signInAnonymously().await() } catch (_: Exception) {}
                                                }
                                                val sent = EmailOtpService.sendEmailOtp(trimmedEmail)
                                                isSendingOtp = false
                                                if (sent) {
                                                    otpCode = ""
                                                    otpErrorMessage = null
                                                    verificationId = "email_$trimmedEmail"
                                                    currentStep = AuthStep.VERIFY_OTP
                                                    Toast.makeText(context, "✓ Verification code sent to $trimmedEmail", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    emailErrorMessage = "Unable to deliver code to $trimmedEmail. Please check your internet connection or email address and try again."
                                                    Toast.makeText(context, "Failed to send code. Please try again.", Toast.LENGTH_LONG).show()
                                                }
                                            }
                                        }
                                    )
                                }
                                AuthStep.VERIFY_OTP -> {
                                    VerifyOtpContent(
                                        authMethod = selectedMethod,
                                        contactInfo = contactInfo.trim().lowercase(),
                                        otpCode = otpCode,
                                        isVerifying = isVerifyingOtp,
                                        isResending = isResendingOtp,
                                        errorMessage = otpErrorMessage,
                                        onOtpChange = { 
                                            otpCode = it 
                                            otpErrorMessage = null
                                        },
                                        onBack = { currentStep = AuthStep.INPUT_CONTACT },
                                        onResend = {
                                            val trimmedEmail = contactInfo.trim().lowercase()
                                            isResendingOtp = true
                                            coroutineScope.launch {
                                                val auth = FirebaseAuth.getInstance()
                                                if (auth.currentUser == null) {
                                                    try { auth.signInAnonymously().await() } catch (_: Exception) {}
                                                }
                                                val sent = EmailOtpService.sendEmailOtp(trimmedEmail)
                                                isResendingOtp = false
                                                if (sent) {
                                                    otpCode = ""
                                                    otpErrorMessage = null
                                                    Toast.makeText(context, "✓ New verification code sent to $trimmedEmail", Toast.LENGTH_SHORT).show()
                                                } else {
                                                    otpErrorMessage = "Unable to resend code. Please check your internet connection and try again."
                                                    Toast.makeText(context, "Failed to resend code. Please try again.", Toast.LENGTH_SHORT).show()
                                                }
                                            }
                                        },
                                        onVerify = {
                                            val enteredCode = otpCode.trim()
                                            if (enteredCode.length != 6) {
                                                otpErrorMessage = "Please enter all 6 digits."
                                                return@VerifyOtpContent
                                            }

                                            isVerifyingOtp = true
                                            coroutineScope.launch {
                                                val trimmedEmail = contactInfo.trim().lowercase()
                                                try {
                                                    val verified = EmailOtpService.verifyEmailOtp(trimmedEmail, enteredCode)
                                                    if (!verified) {
                                                        otpErrorMessage = "Incorrect or expired verification code. Please request a new code."
                                                        isVerifyingOtp = false
                                                        return@launch
                                                    }
                                                } catch (_: Exception) {
                                                    otpErrorMessage = "Unable to verify the code right now. Please try again."
                                                    isVerifyingOtp = false
                                                    return@launch
                                                }
                                                try {
                                                    val legacyPrefs = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
                                                    legacyPrefs.edit()
                                                        .putString("user_email", trimmedEmail)
                                                        .putString("profile_email", trimmedEmail)
                                                        .apply()
                                                    val modernPrefs = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                                                    modernPrefs.edit()
                                                        .putString("user_email", trimmedEmail)
                                                        .putString("profile_email", trimmedEmail)
                                                        .apply()

                                                    Toast.makeText(context, "✓ Verification successful! Logging in...", Toast.LENGTH_SHORT).show()

                                                    val auth = FirebaseAuth.getInstance()
                                                    if (auth.currentUser == null) {
                                                        try {
                                                            auth.signInAnonymously().await()
                                                        } catch (_: Exception) {}
                                                    }

                                                    val uid = auth.currentUser?.uid
                                                    try {
                                                        val db = com.google.firebase.firestore.FirebaseFirestore.getInstance()
                                                        val canonicalId = "user_" + trimmedEmail.replace(Regex("[^a-zA-Z0-9_]"), "_")
                                                        var profileDoc = db.collection("netero_profiles").document(canonicalId).get().await()
                                                        if (!profileDoc.exists() || profileDoc.getString("fullName").isNullOrBlank()) {
                                                            if (uid != null) {
                                                                profileDoc = db.collection("netero_profiles").document(uid).get().await()
                                                            }
                                                        }
                                                        if (!profileDoc.exists() || profileDoc.getString("fullName").isNullOrBlank()) {
                                                            var queryDocs = db.collection("netero_profiles").whereEqualTo("email", trimmedEmail).get().await()
                                                            if (queryDocs.isEmpty) {
                                                                queryDocs = db.collection("netero_profiles").whereEqualTo("email", contactInfo.trim()).get().await()
                                                            }
                                                            if (!queryDocs.isEmpty) {
                                                                profileDoc = queryDocs.documents.first()
                                                            } else {
                                                                val allDocs = db.collection("netero_profiles").limit(50).get().await()
                                                                val match = allDocs.documents.firstOrNull { d ->
                                                                    val e = d.getString("email") ?: ""
                                                                    val u = d.getString("username") ?: ""
                                                                    e.trim().equals(trimmedEmail, ignoreCase = true) || (u.isNotBlank() && u.trim().equals(contactInfo.trim(), ignoreCase = true))
                                                                }
                                                                if (match != null) profileDoc = match
                                                            }
                                                        }

                                                            val fullName = profileDoc.getString("fullName")
                                                            if (profileDoc.exists() && !fullName.isNullOrBlank()) {
                                                                val restored = com.example.data.api.CloudSyncManager().parseUserProfile(profileDoc)
                                                                onRestoreProfile?.invoke(restored)

                                                                profileDoc.reference.set(
                                                                    mapOf(
                                                                        "lastLoginAt" to System.currentTimeMillis(),
                                                                        "email" to (restored.email.ifBlank { trimmedEmail })
                                                                    ),
                                                                    com.google.firebase.firestore.SetOptions.merge()
                                                                ).await()

                                                                val p1 = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE).edit()
                                                                val p2 = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE).edit()
                                                                val canonicalKey = "user_" + (restored.email.ifBlank { trimmedEmail }).trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
                                                                listOf(p1, p2).forEach { ed ->
                                                                    ed.putString("user_email", restored.email.ifBlank { trimmedEmail })
                                                                    ed.putString("profile_email", restored.email.ifBlank { trimmedEmail })
                                                                    ed.putString("canonical_user_id", canonicalKey)
                                                                    ed.putString("persistent_user_uid", canonicalKey)
                                                                    ed.putString("profile_name", restored.fullName)
                                                                    ed.putString("profile_username", restored.username)
                                                                    ed.putString("profile_headline", restored.headline)
                                                                    ed.putString("profile_title", restored.jobTitle)
                                                                    ed.putString("profile_company", restored.company)
                                                                    ed.putString("profile_industry", restored.industry)
                                                                    ed.putString("profile_bio", restored.bio)
                                                                    ed.putString("profile_phone", restored.phone)
                                                                    ed.putString("profile_location", restored.location)
                                                                    ed.putString("profile_image_url", restored.profileImageUrl)
                                                                    ed.putBoolean("is_logged_in", true)
                                                                    ed.commit()
                                                                }

                                                                isVerifyingOtp = false
                                                                onNavigateToHome()
                                                                return@launch
                                                            }
                                                        } catch (_: Exception) {}

                                                    // Local fallback check before navigating to setup
                                                    val p1 = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
                                                    val p2 = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                                                    fun getPrefString(key: String): String {
                                                        val s1 = p2.getString(key, "") ?: ""
                                                        if (s1.isNotBlank()) return s1
                                                        return p1.getString(key, "") ?: ""
                                                    }
                                                    val localName = getPrefString("profile_name")
                                                    if (localName.isNotBlank()) {
                                                        val restoredLocal = com.example.data.model.UserProfile(
                                                            fullName = localName,
                                                            username = getPrefString("profile_username"),
                                                            headline = getPrefString("profile_headline"),
                                                            jobTitle = getPrefString("profile_title"),
                                                            company = getPrefString("profile_company"),
                                                            industry = getPrefString("profile_industry"),
                                                            bio = getPrefString("profile_bio"),
                                                            phone = getPrefString("profile_phone"),
                                                            email = trimmedEmail.ifBlank { getPrefString("profile_email") },
                                                            location = getPrefString("profile_location"),
                                                            profileImageUrl = getPrefString("profile_image_url"),
                                                            isStudent = p2.getBoolean("profile_is_student", false) || p1.getBoolean("profile_is_student", false)
                                                        )
                                                        onRestoreProfile?.invoke(restoredLocal)
                                                        val canonicalKey = "user_" + (restoredLocal.email.ifBlank { trimmedEmail }).trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
                                                        p1.edit().putString("canonical_user_id", canonicalKey).putString("persistent_user_uid", canonicalKey).putBoolean("is_logged_in", true).commit()
                                                        p2.edit().putString("canonical_user_id", canonicalKey).putString("persistent_user_uid", canonicalKey).putBoolean("is_logged_in", true).commit()
                                                        isVerifyingOtp = false
                                                        onNavigateToHome()
                                                        return@launch
                                                    }

                                                    isVerifyingOtp = false
                                                    onNavigateToSetup()
                                                } catch (e: Exception) {
                                                    isVerifyingOtp = false
                                                    val p1 = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
                                                    val p2 = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                                                    fun getPrefString(key: String): String {
                                                        val s1 = p2.getString(key, "") ?: ""
                                                        if (s1.isNotBlank()) return s1
                                                        return p1.getString(key, "") ?: ""
                                                    }
                                                    val localName = getPrefString("profile_name")
                                                    if (localName.isNotBlank()) {
                                                        val restoredLocal = com.example.data.model.UserProfile(
                                                            fullName = localName,
                                                            username = getPrefString("profile_username"),
                                                            headline = getPrefString("profile_headline"),
                                                            jobTitle = getPrefString("profile_title"),
                                                            company = getPrefString("profile_company"),
                                                            industry = getPrefString("profile_industry"),
                                                            bio = getPrefString("profile_bio"),
                                                            phone = getPrefString("profile_phone"),
                                                            email = trimmedEmail.ifBlank { getPrefString("profile_email") },
                                                            location = getPrefString("profile_location"),
                                                            profileImageUrl = getPrefString("profile_image_url"),
                                                            isStudent = p2.getBoolean("profile_is_student", false) || p1.getBoolean("profile_is_student", false)
                                                        )
                                                        onRestoreProfile?.invoke(restoredLocal)
                                                        val canonicalKey = "user_" + (restoredLocal.email.ifBlank { trimmedEmail }).trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
                                                        p1.edit().putString("canonical_user_id", canonicalKey).putString("persistent_user_uid", canonicalKey).putBoolean("is_logged_in", true).commit()
                                                        p2.edit().putString("canonical_user_id", canonicalKey).putString("persistent_user_uid", canonicalKey).putBoolean("is_logged_in", true).commit()
                                                        onNavigateToHome()
                                                    } else {
                                                        onNavigateToSetup()
                                                    }
                                                }
                                            }
                                        }
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun WelcomeContent(
    onEmailSignIn: () -> Unit
) {
    var termsAccepted by remember { mutableStateOf(false) }
    var isSigningIn by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val coroutineScope = rememberCoroutineScope()
    
    Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Brand Header
        Column(
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(MaterialTheme.colorScheme.surface)
                    .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
                contentAlignment = Alignment.Center
            ) {
                Image(
                    painter = painterResource(id = R.drawable.ic_netero_logo),
                    contentDescription = "NETERO Logo",
                    modifier = Modifier.size(80.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text(
                text = "NETERO",
                style = MaterialTheme.typography.displayLarge.copy(
                    fontWeight = FontWeight.Bold,
                    fontSize = 42.sp,
                    letterSpacing = 6.sp
                ),
                color = MaterialTheme.colorScheme.onBackground,
                textAlign = TextAlign.Center
            )

            Text(
                text = "connect • engage • grow",
                style = MaterialTheme.typography.titleMedium.copy(
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 2.sp
                ),
                color = MaterialTheme.colorScheme.primary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Your Digital Identity, Everywhere.\nThe next generation of real-world & professional networking.",
                style = MaterialTheme.typography.bodyMedium.copy(
                    lineHeight = 22.sp
                ),
                color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f),
                textAlign = TextAlign.Center
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Fast Onboarding Banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                    Text(
                        text = "Privacy First • NETERO Lock Protection",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                }
                Text(
                    text = "Zero GPS location tracking. Control who sees your phone, email, and socials.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        // Action Buttons
        Column(
            modifier = Modifier.fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 4.dp, vertical = 8.dp)
            ) {
                Checkbox(
                    checked = termsAccepted,
                    onCheckedChange = { termsAccepted = it }
                )
                val annotatedString = buildAnnotatedString {
                    append("I accept the ")
                    pushStringAnnotation(tag = "TERMS", annotation = "https://docs.google.com/document/d/e/2PACX-1vRyfV5Wofoe-3rK2-Bqsst4LiYiKwySHAonug3m1W5leyf8m9JSa_zpOOHByOezxlMqeVTiYU4JZ8Y1/pub")
                    withStyle(style = SpanStyle(color = MaterialTheme.colorScheme.primary, textDecoration = TextDecoration.Underline)) {
                        append("Terms & Conditions and Privacy Policy")
                    }
                    pop()
                    append(".")
                }
                val uriHandler = LocalUriHandler.current
                ClickableText(
                    text = annotatedString,
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onBackground),
                    onClick = { offset ->
                        annotatedString.getStringAnnotations(tag = "TERMS", start = offset, end = offset)
                            .firstOrNull()?.let { annotation ->
                                uriHandler.openUri(annotation.item)
                            } ?: run {
                                termsAccepted = !termsAccepted
                            }
                    }
                )
            }



            Button(
                onClick = { 
                    if (termsAccepted) {
                        onEmailSignIn()
                    } else {
                        Toast.makeText(context, "Please accept the Terms & Conditions", Toast.LENGTH_SHORT).show()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp)
                    .testTag("email_login_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.White,
                    contentColor = Color(0xFF0F172A)
                ),
                elevation = ButtonDefaults.buttonElevation(defaultElevation = 2.dp, pressedElevation = 4.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    modifier = Modifier.size(20.dp),
                    tint = Color(0xFF0F172A)
                )
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = "Continue with Google / Email",
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFF0F172A)
                    )
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Auth Security Badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically
            ) {
                AuthChip(icon = Icons.Default.Email, label = "Verified Email Login")
                Spacer(modifier = Modifier.width(16.dp))
                AuthChip(icon = Icons.Default.Shield, label = "Privacy Secured")
            }
        }
    }
}

@Composable
private fun InputContactContent(
    authMethod: AuthMethod,
    contactInfo: String,
    selectedCountryCode: String,
    isSending: Boolean = false,
    errorMessage: String? = null,
    onContactInfoChange: (String) -> Unit,
    onCountryCodeChange: (String) -> Unit,
    onBack: () -> Unit,
    onContinue: () -> Unit
) {
    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 24.dp)
        ) {
            IconButton(onClick = onBack, enabled = !isSending) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(
                text = "Email Verification",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Text(
            text = "Enter your Gmail or Email Address",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "We will send an authentic 6-digit verification code directly to your email inbox.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )

        Spacer(modifier = Modifier.height(24.dp))

        OutlinedTextField(
            value = contactInfo,
            onValueChange = onContactInfoChange,
            modifier = Modifier.fillMaxWidth(),
            enabled = !isSending,
            label = { Text("Gmail / Email Address", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)) },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email, autoCorrectEnabled = false),
            placeholder = { Text("yourname@gmail.com", color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.5f)) },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary
                )
            },
            isError = errorMessage != null,
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedContainerColor = MaterialTheme.colorScheme.surface,
                unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                focusedBorderColor = AccentBlue,
                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                errorBorderColor = MaterialTheme.colorScheme.error
            ),
            shape = RoundedCornerShape(12.dp)
        )

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(32.dp))

        Button(
            onClick = onContinue,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentBlue,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                disabledContainerColor = AccentBlue.copy(alpha = 0.4f),
                disabledContentColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            ),
            enabled = contactInfo.isNotBlank() && !isSending,
            shape = RoundedCornerShape(16.dp)
        ) {
            if (isSending) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(10.dp))
                Text("Sending Verification Code...", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            } else {
                Text("Send Verification Code", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        }
    }
}

@Composable
private fun VerifyOtpContent(
    authMethod: AuthMethod,
    contactInfo: String,
    otpCode: String,
    isVerifying: Boolean = false,
    isResending: Boolean = false,
    errorMessage: String? = null,
    onOtpChange: (String) -> Unit,
    onBack: () -> Unit,
    onResend: () -> Unit = {},
    onVerify: () -> Unit
) {
    var countdown by remember { mutableIntStateOf(30) }

    LaunchedEffect(countdown) {
        if (countdown > 0) {
            delay(1000L)
            countdown -= 1
        }
    }

    Column(
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(bottom = 24.dp)
        ) {
            IconButton(onClick = onBack, enabled = !isVerifying) {
                Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
            }
            Text(
                text = "Enter Verification Code",
                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                color = MaterialTheme.colorScheme.onBackground
            )
        }

        Text(
            text = "Code Sent via Email",
            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onBackground
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "We sent a 6-digit verification code to:",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
        )
        Spacer(modifier = Modifier.height(4.dp))
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = contactInfo,
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                color = AccentBlue,
                modifier = Modifier.weight(1f)
            )
            androidx.compose.material3.TextButton(onClick = onBack, enabled = !isVerifying) {
                Text("Change", style = MaterialTheme.typography.labelMedium)
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Visual 6-Digit PIN Boxes
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp, Alignment.CenterHorizontally)
        ) {
            for (i in 0 until 6) {
                val char = otpCode.getOrNull(i)?.toString() ?: ""
                val isCurrent = otpCode.length == i
                val boxBorderColor = when {
                    errorMessage != null -> MaterialTheme.colorScheme.error
                    isCurrent -> AccentBlue
                    char.isNotEmpty() -> MaterialTheme.colorScheme.primary
                    else -> MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                }

                Box(
                    modifier = Modifier
                        .width(44.dp)
                        .height(54.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .border(if (isCurrent) 2.dp else 1.dp, boxBorderColor, RoundedCornerShape(12.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = char,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        // Hidden / overlay keyboard field with autofill disabled
        OutlinedTextField(
            value = otpCode,
            onValueChange = { input ->
                val digits = input.filter { it.isDigit() }.take(6)
                onOtpChange(digits)
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 8.dp),
            enabled = !isVerifying,
            label = { Text("Type 6-digit code") },
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.NumberPassword,
                autoCorrectEnabled = false
            ),
            singleLine = true,
            isError = errorMessage != null,
            shape = RoundedCornerShape(12.dp)
        )

        if (errorMessage != null) {
            Spacer(modifier = Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(errorMessage, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
            }
        }

        Spacer(modifier = Modifier.height(28.dp))

        Button(
            onClick = onVerify,
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AccentBlue,
                contentColor = MaterialTheme.colorScheme.onPrimary,
                disabledContainerColor = AccentBlue.copy(alpha = 0.4f),
                disabledContentColor = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.4f)
            ),
            enabled = otpCode.length == 6 && !isVerifying,
            shape = RoundedCornerShape(16.dp)
        ) {
            if (isVerifying) {
                CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = MaterialTheme.colorScheme.onPrimary)
                Spacer(Modifier.width(10.dp))
                Text("Verifying Code...", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            } else {
                Text("Verify & Continue", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (isResending) {
                CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = AccentBlue)
                Spacer(Modifier.width(8.dp))
                Text("Sending new verification code...", style = MaterialTheme.typography.bodyMedium, color = AccentBlue)
            } else {
                Text(
                    text = "Didn't receive the code? ",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f)
                )
                Text(
                    text = if (countdown > 0) "Resend in ${countdown}s" else "Resend Code",
                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                    color = if (countdown > 0) MaterialTheme.colorScheme.onSurfaceVariant else AccentBlue,
                    modifier = Modifier.clickable(enabled = countdown == 0 && !isVerifying) {
                        countdown = 30
                        onResend()
                    }
                )
            }
        }
    }
}

@Composable
private fun AuthChip(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp),
        modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 10.dp, vertical = 6.dp)
    ) {
        Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
        Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.7f))
    }
}

@Preview(showBackground = true)
@Composable
fun WelcomeScreenPreview() {
    NeteroTheme(darkTheme = true) {
        WelcomeScreen(onNavigateToSetup = {}, onNavigateToHome = {})
    }
}
