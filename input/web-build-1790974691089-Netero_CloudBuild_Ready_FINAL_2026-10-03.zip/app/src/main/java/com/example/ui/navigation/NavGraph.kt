package com.example.ui.navigation

import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch
import com.example.ui.components.AskAiBottomSheet
import com.example.ui.components.FloatingAskAiButton
import com.example.ui.screens.ChatDetailScreen
import com.example.ui.screens.ConnectionsScreen
import com.example.ui.screens.DiscoverScreen
import com.example.ui.screens.HelpDeskScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.ProfileSetupScreen
import com.example.ui.screens.QrScreen
import com.example.ui.screens.RoomDetailScreen
import com.example.ui.screens.RoomsScreen
import com.example.ui.screens.WelcomeScreen
import com.example.ui.screens.OnboardingScreen
import com.example.ui.screens.PendingConnectionsScreen
import com.example.ui.screens.RecommendedConnectionsScreen

import com.example.ui.screens.AnalyticsScreen
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.PrimaryBlack
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextGray
import com.example.ui.viewmodel.NeteroViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NeteroNavGraph(
    viewModel: NeteroViewModel,
    startDestination: String = Screen.Onboarding.route,
    navController: NavHostController = rememberNavController()
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    val userProfile by viewModel.userProfile.collectAsState()
    val isDarkTheme by viewModel.isDarkTheme.collectAsState()

    val recommendedPeople by viewModel.recommendedPeople.collectAsState()
    val discoverSearchQuery by viewModel.discoverSearchQuery.collectAsState()
    val selectedDiscoverCategory by viewModel.selectedDiscoverCategory.collectAsState()

    val roomsList by viewModel.roomsList.collectAsState()

    val connectionsList by viewModel.connectionsList.collectAsState()
    val chatMessages by viewModel.chatMessages.collectAsState()
    val connectionRequests by viewModel.connectionRequests.collectAsState()
    val connectionsSearchQuery by viewModel.connectionsSearchQuery.collectAsState()
    val selectedConnectionFilter by viewModel.selectedConnectionFilter.collectAsState()
    val selectedContactForSheet by viewModel.selectedContactForSheet.collectAsState()

    val aiAssistantMessages by viewModel.aiAssistantMessages.collectAsState()
    val aiChatSessions by viewModel.aiChatSessions.collectAsState()
    val isAiThinking by viewModel.isAiThinking.collectAsState()
    var showAskAiSheet by remember { mutableStateOf(false) }
    
    val context = androidx.compose.ui.platform.LocalContext.current
    
    androidx.compose.runtime.LaunchedEffect(Unit) {
        viewModel.networkNotifications.collect { message ->
            android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_LONG).show()
        }
    }

    val prefs = context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)

    val isBottomNavVisible = currentRoute in Screen.bottomNavScreens.map { it.route }

    if (showAskAiSheet) {
        AskAiBottomSheet(
            messages = aiAssistantMessages,
            isThinking = isAiThinking,
            sessions = aiChatSessions,
            onSendMessage = { prompt -> viewModel.askAiAnything(prompt) },
            onNewChat = { viewModel.startNewAiChat() },
            onClearHistory = { viewModel.clearAllAiChatsAndHistory() },
            onLoadHistory = { sessionName -> viewModel.loadAiHistory(sessionName) },
            onLoadSession = { session -> viewModel.loadAiSession(session) },
            onDeleteSession = { sessionId -> viewModel.deleteAiSession(sessionId) },
            onDismiss = { showAskAiSheet = false }
        )
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        floatingActionButton = {
            if (isBottomNavVisible) {
                FloatingAskAiButton(
                    onClick = { 
                        showAskAiSheet = true
                    },
                    modifier = Modifier.offset(y = 8.dp)
                )
            }
        },
        bottomBar = {
            if (isBottomNavVisible) {
                NavigationBar(
                    modifier = Modifier
                        .navigationBarsPadding()
                        .clip(RoundedCornerShape(topStart = 20.dp, topEnd = 20.dp))
                        .testTag("bottom_navigation_bar"),
                    containerColor = DarkSurface,
                    contentColor = MaterialTheme.colorScheme.onSurface,
                    tonalElevation = 8.dp
                ) {
                    Screen.bottomNavScreens.forEach { screen ->
                        val isSelected = currentRoute == screen.route
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = {
                                if (currentRoute != screen.route) {
                                    navController.navigate(screen.route) {
                                        popUpTo(Screen.Home.route) {
                                            saveState = true
                                        }
                                        launchSingleTop = true
                                        restoreState = true
                                    }
                                }
                            },
                            icon = {
                                val iconVector = if (isSelected) screen.selectedIcon else screen.unselectedIcon
                                iconVector?.let {
                                    Icon(
                                        imageVector = it,
                                        contentDescription = screen.title,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            },
                            label = {
                                Text(
                                    text = screen.title,
                                    fontSize = 9.sp,
                                    maxLines = 1,
                                    softWrap = false,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            modifier = Modifier.testTag("bottom_nav_${screen.route}"),
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = AccentBlue,
                                selectedTextColor = AccentBlue,
                                indicatorColor = AccentBlue.copy(alpha = 0.15f),
                                unselectedIconColor = TextGray,
                                unselectedTextColor = TextGray
                            )
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues),
            enterTransition = { fadeIn(animationSpec = tween(200)) },
            exitTransition = { fadeOut(animationSpec = tween(200)) }
        ) {
            // Onboarding
            composable(Screen.Onboarding.route) {
                OnboardingScreen(
                    onFinishOnboarding = {
                        navController.navigate(Screen.Welcome.route) {
                            popUpTo(Screen.Onboarding.route) { inclusive = true }
                        }
                    }
                )
            }

            // Screen 1: Welcome
            composable(Screen.Welcome.route) {
                WelcomeScreen(
                    onNavigateToSetup = { navController.navigate(Screen.ProfileSetup.route) },
                    onNavigateToHome = {
                        prefs.edit().putBoolean("is_logged_in", true).commit()
                        context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                            .edit().putBoolean("is_logged_in", true).commit()
                        viewModel.refreshCloudData()
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Welcome.route) { inclusive = true }
                        }
                    },
                    onRestoreProfile = { restored ->
                        viewModel.restoreUserProfile(restored)
                    }
                )
            }

            // Screen 2: Profile Setup
            composable(Screen.ProfileSetup.route) {
                ProfileSetupScreen(
                    onUploadImage = { uri, cb -> viewModel.uploadProfileImage(uri, cb) },
                    userProfile = userProfile,
                    onSaveProfile = { username, fullName, headline, jobTitle, company, industry, bio, location, phone, email, dateOfBirth, website, linkedinUrl, businessUrl, portfolioUrl, themeColorHex, isStudent ->
                        viewModel.updateProfile(username, fullName, headline, jobTitle, company, industry, bio, location, phone, email, dateOfBirth, website, linkedinUrl, businessUrl, portfolioUrl, themeColorHex, isStudent)
                    },
                    onEnhanceBio = { name, jobTitle, company, industry, currentBio, onResult ->
                        viewModel.enhanceProfileBio(name, jobTitle, company, industry, currentBio, onResult)
                    },
                    onNavigateBack = { navController.popBackStack() },
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onNavigateNext = {
                        prefs.edit().putBoolean("is_logged_in", true).apply()
                        context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                            .edit().putBoolean("is_logged_in", true).apply()
                        viewModel.refreshCloudData()
                        navController.navigate(Screen.Home.route) {
                            popUpTo(Screen.Welcome.route) { inclusive = true }
                        }
                    }
                )
            }

            // Screen 3: Home
            composable(Screen.Home.route) {
                val notifications by viewModel.notifications.collectAsStateWithLifecycle()
                HomeScreen(
                    userProfile = userProfile,
                    notifications = notifications,
                    recentConnections = connectionsList,
                    connectionRequests = connectionRequests,
                    recommendedPeople = recommendedPeople,
                    recommendedRooms = roomsList,
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                    onNavigateToEditProfile = { navController.navigate(Screen.ProfileSetup.route) },
                    onNavigateToDiscover = { navController.navigate(Screen.Discover.route) },
                    onNavigateToRooms = { navController.navigate(Screen.Rooms.route) },
                    onOpenRoom = { roomId -> navController.navigate(Screen.RoomDetail.createRoute(roomId)) },
                    onNavigateToScan = { navController.navigate(Screen.Scan.route) },
                    onNavigateToConnections = { navController.navigate(Screen.Connections.route) },
                    onNavigateToPending = { navController.navigate(Screen.PendingConnections.route) },
                    onNavigateToRecommended = { navController.navigate(Screen.RecommendedConnections.route) },
                    onNavigateToHelpDesk = { navController.navigate(Screen.HelpDesk.route) },
                    onOpenAskAi = { 
                        if (userProfile.isPro) {
                            showAskAiSheet = true
                        } else {
                            navController.navigate(Screen.Paywall.route)
                        }
                    },

                    onAcceptRequest = { viewModel.acceptConnectionRequest(it) },
                    onIgnoreRequest = { viewModel.ignoreConnectionRequest(it) },
                    onConnectPerson = { id, note -> viewModel.connectWithPerson(id, note) },
                    onJoinRoom = { viewModel.toggleJoinRoom(it) }
                )
            }

            // Screen 4: Discover (LinkedIn Style)
            composable(Screen.Discover.route) {
                val aiLearnedProfile by viewModel.aiLearnedProfile.collectAsStateWithLifecycle()
                DiscoverScreen(
                    userProfile = userProfile,
                    recommendedPeople = recommendedPeople,
                    searchQuery = discoverSearchQuery,
                    selectedCategory = selectedDiscoverCategory,
                    recentSearches = aiLearnedProfile.recentSearchQueries,
                    onSearchQueryChange = { viewModel.searchNetwork(it) },
                    onCategorySelect = { viewModel.setDiscoverCategory(it) },
                    onConnectPerson = { id, note -> viewModel.connectWithPerson(id, note) },
                    onFetchMutuals = { ids, cb -> viewModel.getMutualProfiles(ids, cb) },
                    onRefreshAiMatches = { viewModel.curateDiscoverListWithAi() },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onAskAiClick = { prompt ->
                        showAskAiSheet = true
                        if (!prompt.isNullOrBlank()) {
                            viewModel.askAiAnything(prompt)
                        }
                    }
                )
            }

            // Screen 5: Rooms Space
            composable(Screen.Rooms.route) {
                RoomsScreen(
                    roomsList = roomsList,
                    onSelectRoom = { roomId ->
                        navController.navigate(Screen.RoomDetail.createRoute(roomId))
                    },
                    onToggleJoinRoom = { viewModel.toggleJoinRoom(it) },
                    onAddRoom = { name, desc, type, loc, tags, pwd, sd, st, ed, et -> 
                        viewModel.createNewRoom(name, desc, type, loc, tags, pwd.isNotBlank(), pwd, sd, st, ed, et) 
                    },
                    onScanEventQrClick = { navController.navigate(Screen.Scan.route) },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onRefresh = { viewModel.refreshCloudData() }
                )
            }

            // Screen 5b: Room Detail View
            composable(
                route = Screen.RoomDetail.route,
                arguments = listOf(navArgument("roomId") { type = NavType.StringType })
            ) { backStackEntry ->
                val roomId = backStackEntry.arguments?.getString("roomId") ?: ""
                val room = roomsList.find { it.id == roomId } ?: roomsList.first()

                androidx.compose.runtime.LaunchedEffect(roomId) {
                    if (roomId.isNotBlank()) {
                        viewModel.listenToLiveDiscussions(roomId)
                    }
                }

                RoomDetailScreen(
                    room = room,
                    connectionsList = connectionsList,
                    onNavigateBack = { navController.popBackStack() },
                    onToggleJoinRoom = { viewModel.toggleJoinRoom(it) },
                    onPostDiscussion = { rId, content -> viewModel.addRoomDiscussion(rId, content) },
                    onPostDiscussionAttachment = { rId, text, uri, type, mimeType, originalName -> viewModel.addRoomDiscussionAttachment(rId, text, uri, type, mimeType, originalName) },
                    onConnectMember = { id, note -> viewModel.connectWithPerson(id, note = note, source = "Room") },
                    onDeleteRoom = { 
                        viewModel.deleteRoom(room.id) 
                        navController.popBackStack()
                    },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onDeleteDisc = { discId -> viewModel.deleteRoomDiscussion(room.id, discId) },
                    onRemoveMember = { mId -> viewModel.removeRoomMember(room.id, mId) },
                    onDeleteOpportunity = { oId -> viewModel.deleteRoomOpportunity(room.id, oId) },
                    onToggleAdmin = { rId, mId -> viewModel.toggleRoomAdmin(rId, mId) },

                    onAcceptRequest = { rId, reqId -> viewModel.acceptJoinRequest(rId, reqId) },
                    onDenyRequest = { rId, reqId -> viewModel.denyJoinRequest(rId, reqId) },
                    onToggleAdminOnlyChat = { viewModel.toggleAdminOnlyChat(it) },
                    onToggleRoomPrivacy = { viewModel.toggleRoomPrivacy(it) },
                    onPostOpportunity = { opp -> viewModel.addRoomOpportunity(room.id, opp) },
                    currentUserName = userProfile.fullName,
                    onMakeSpeaker = { rId, mId -> viewModel.makeRoomSpeaker(rId, mId) },
                    onRemoveSpeaker = { rId, mId -> viewModel.removeRoomSpeaker(rId, mId) },
                    userProfile = userProfile
                )
            }

            // Screen 6: Scan & QR Share
            composable(Screen.Scan.route) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val scope = androidx.compose.runtime.rememberCoroutineScope()
                QrScreen(
                    userProfile = userProfile,
                    onHandleScanContact = { name, role, company, source, notes, email, linkedin, phone, tags ->
                        scope.launch {
                            val locString = com.example.utils.LocationHelper.getDeviceLocationString(context)
                            viewModel.handleScanContact(name, role, company, source, notes, email, linkedin, phone, tags, locString)
                        }
                    },
                    onRoomScanned = { roomId ->
                        viewModel.forceJoinRoom(roomId)
                        navController.navigate(Screen.RoomDetail.createRoute(roomId))
                    }
                )
            }

            // Screen 7: Connections Book & Messaging Column
            composable(Screen.Connections.route) {
                val context = androidx.compose.ui.platform.LocalContext.current
                val scope = androidx.compose.runtime.rememberCoroutineScope()
                ConnectionsScreen(
                    connectionsList = connectionsList,
                    chatMessages = chatMessages,
                    searchQuery = connectionsSearchQuery,
                    onSearchQueryChange = { viewModel.setConnectionsSearchQuery(it) },
                    selectedFilterTag = selectedConnectionFilter,
                    onSelectFilterTag = { viewModel.setConnectionFilter(it) },
                    selectedContactForSheet = selectedContactForSheet,
                    onSelectContact = { viewModel.selectContactForSheet(it) },
                    onUpdateNotes = { contactId, notes -> viewModel.updateContactNotes(contactId, notes) },
                    onNavigateToChat = { contactId -> navController.navigate(Screen.ChatDetail.createRoute(contactId)) },
                    onUpdateContact = { updated -> viewModel.updateContactFull(updated) },
                    onDeleteContact = { contactId -> viewModel.deleteContact(contactId) },
                    onHandleRemoteUpdate = { contactId, title, company ->
                        viewModel.handleRemoteContactCardUpdate(contactId, title, company)
                    },
                    onHandlePaperScan = { name, role, company ->
                        scope.launch {
                            val locString = com.example.utils.LocationHelper.getDeviceLocationString(context)
                            viewModel.handleScanContact(name, role, company, "Paper OCR", null, null, null, null, null, locString)
                        }
                    },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    userProfile = userProfile,
                    onRefresh = { viewModel.refreshCloudData() }
                )
            }

            // Screen 7b: Direct Chat & Interaction
            composable(
                route = Screen.ChatDetail.route,
                arguments = listOf(navArgument("contactId") { type = NavType.StringType })
            ) { backStackEntry ->
                val contactId = backStackEntry.arguments?.getString("contactId") ?: ""
                val contact = connectionsList.find { it.id == contactId }
                val msgs = chatMessages[contactId] ?: emptyList()

                val isMessagingUnlocked = contact != null && !contact.tags.contains("PENDING_CONNECT_BACK")

                ChatDetailScreen(
                    contact = contact,
                    messages = msgs,
                    onSendMessage = { text -> viewModel.sendChatMessage(contactId, text) },
                    onSendAttachment = { text, uri, type, mimeType, originalName -> viewModel.sendChatAttachment(contactId, text, uri, type, mimeType, originalName) },
                    onDeleteMessageForMe = { msgId -> viewModel.deleteChatMessageForMe(contactId, msgId) },
                    onDeleteMessageForEveryone = { msgId -> viewModel.deleteChatMessageForEveryone(contactId, msgId) },
                    onEditMessage = { msgId, newText -> viewModel.editChatMessage(contactId, msgId, newText) },
                    onGenerateAiSmartReply = { cb -> viewModel.generateAiSmartReply(contactId, cb) },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onNavigateBack = { navController.popBackStack() },
                    isMessagingUnlocked = isMessagingUnlocked
                )
            }

            
            composable(Screen.Analytics.route) {
                val profileViews by viewModel.profileViews.collectAsStateWithLifecycle()
                val connections by viewModel.connectionsList.collectAsStateWithLifecycle()
                val profile by viewModel.userProfile.collectAsStateWithLifecycle()
                AnalyticsScreen(
                    profileViews = profileViews,
                    connectionsCount = connections.size,
                    qrScans = profile.qrScans,
                    linkClicks = profile.linkClicks,
                    onNavigateBack = { navController.popBackStack() },
                )
            }
            
            // Screen 9: Pending Connections
            composable(Screen.PendingConnections.route) {
                PendingConnectionsScreen(
                    requests = connectionRequests,
                    onAccept = { viewModel.acceptConnectionRequest(it) },
                    onIgnore = { viewModel.ignoreConnectionRequest(it) },
                    onNavigateBack = { navController.popBackStack() },
                )
            }
            
            // Screen 10: Recommended Connections
            composable(Screen.RecommendedConnections.route) {
                RecommendedConnectionsScreen(
                    recommendedPeople = recommendedPeople,
                    onConnectPerson = { id, note -> viewModel.connectWithPerson(id, note) },
                    onNavigateBack = { navController.popBackStack() },
                    onFetchMutuals = { ids, cb -> viewModel.getMutualProfiles(ids, cb) }
                )
            }

            // Screen 8: Profile & Privacy Controls (NETERO Lock)

            composable(Screen.Profile.route) {
                ProfileScreen(
                    userProfile = userProfile,
                    isDarkTheme = isDarkTheme,
                    onToggleDarkTheme = { viewModel.toggleDarkTheme() },
                    onUploadProfileImage = { uri, cb -> viewModel.uploadProfileImage(uri, cb) },
                    onRemoveProfilePhoto = { viewModel.removeProfilePhoto() },
                    onNavigateToEditProfile = { navController.navigate(Screen.ProfileSetup.route) },
                    onNavigateToLockSettings = { android.widget.Toast.makeText(navController.context, "Netero Lock Settings coming soon!", android.widget.Toast.LENGTH_SHORT).show() },
                    onNavigateToAnalytics = {                         if (userProfile.isPro) {                            navController.navigate(Screen.Analytics.route)                        } else {                            navController.navigate(Screen.Paywall.route)                        }                    },
                    isPro = userProfile.isPro,
                    onNavigateToPaywall = { navController.navigate(Screen.Paywall.route) },
                    onNavigateToHelpDesk = { navController.navigate(Screen.HelpDesk.route) },
                    onUpdateNeteroLock = { p, e, s, d, port, r ->
                        viewModel.updateNeteroLock(p, e, s, d, port, r)
                    },
                    onEnhanceBioWithAi = { cb -> 
                        viewModel.enhanceProfileBio(
                            userProfile.fullName, 
                            userProfile.jobTitle, 
                            userProfile.company, 
                            userProfile.industry, 
                            userProfile.bio, 
                            cb
                        )
                    },
                    onLogout = {
                        viewModel.logoutUser {
                            prefs.edit().putBoolean("is_logged_in", false).remove("profile_name").apply()
                            context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
                                .edit().putBoolean("is_logged_in", false).remove("profile_name").apply()
                            navController.navigate(Screen.Welcome.route) {
                                popUpTo(0)
                            }
                        }
                    },
                    onDeleteAccount = {
                        viewModel.deleteAccountPermanently {
                            android.widget.Toast.makeText(navController.context, "Account permanently deleted.", android.widget.Toast.LENGTH_LONG).show()
                            navController.navigate(Screen.Welcome.route) {
                                popUpTo(0)
                            }
                        }
                    }
                )
            }

            // Screen 9: Help Desk & Support
            composable(Screen.Paywall.route) {
                com.example.ui.screens.PaywallScreen(
                    onDismiss = { navController.popBackStack() },
                    onSubscribe = { isYearly -> 
                        viewModel.upgradeToPro()
                        navController.popBackStack()
                    }
                )
            }

            composable(Screen.HelpDesk.route) {
                val tickets by viewModel.supportTickets.collectAsStateWithLifecycle()
                val profile by viewModel.userProfile.collectAsStateWithLifecycle()
                androidx.compose.runtime.LaunchedEffect(Unit) {
                    viewModel.fetchSupportTickets()
                }
                HelpDeskScreen(
                    onNavigateBack = { navController.popBackStack() },
                    userEmail = profile.email,
                    supportTickets = tickets,
                    onSubmitTicket = { subject, message, onDone ->
                        viewModel.submitSupportTicket(subject, message, onDone)
                    }
                )
            }
        }
    }
}
