package com.example.data.model

data class UserProfile(
    val id: String = "",
    val fullName: String = "",
    val profileImageUrl: String = "",
    val username: String = "",
    val headline: String = "",
    val jobTitle: String = "",
    val company: String = "",
    val industry: String = "",
    val bio: String = "",
    val location: String = "",
    val email: String = "",
    val phone: String = "",
    val dateOfBirth: String = "",
    val website: String = "",
    val linkedinUrl: String = "",
    val instagramUrl: String = "",
    val businessUrl: String = "",
    val portfolioUrl: String = "",
    val skills: List<String> = emptyList(),
    val interests: List<String> = emptyList(),
    val networkingGoals: String = "",
    val themeColorHex: String = "#007AFF", // Default Accent Blue
    val neteroLock: NeteroLockSettings = NeteroLockSettings(),
    val isPro: Boolean = true,
    val isStudent: Boolean = false,
    val connectionIds: List<String> = emptyList(),
    val qrScans: Int = 0,
    val linkClicks: Int = 0
) {
    val completionPercentage: Int
        get() {
            var filled = 0
            val total = 10
            if (fullName.isNotBlank()) filled++
            if (username.isNotBlank()) filled++
            if (headline.isNotBlank()) filled++
            if (jobTitle.isNotBlank()) filled++
            if (company.isNotBlank()) filled++
            if (bio.isNotBlank()) filled++
            if (location.isNotBlank()) filled++
            if (skills.isNotEmpty()) filled++
            if (interests.isNotEmpty()) filled++
            if (linkedinUrl.isNotBlank()) filled++
            return ((filled.toFloat() / total.toFloat()) * 100).toInt()
        }
}
