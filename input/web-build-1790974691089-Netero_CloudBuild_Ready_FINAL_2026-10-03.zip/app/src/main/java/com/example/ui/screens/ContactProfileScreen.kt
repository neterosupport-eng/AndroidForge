package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.model.ConnectionContact

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ContactProfileScreen(
    contact: ConnectionContact,
    onBack: () -> Unit,
    onChat: () -> Unit = {}
) {
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Profile", maxLines = 1) },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
                }
            )
        }
    ) { padding ->
        Column(
            Modifier.fillMaxSize().padding(padding).verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(Modifier.size(76.dp).clip(CircleShape).background(Color(contact.avatarBgHex)), contentAlignment = Alignment.Center) {
                    Text(contact.avatarInitial.take(2), color = Color.White, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.weight(1f)) {
                    Text(contact.name, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold, maxLines = 2)
                    Text(contact.jobTitle.ifBlank { "Professional" }, style = MaterialTheme.typography.bodyLarge, maxLines = 2)
                    if (contact.company.isNotBlank()) Text(contact.company, color = MaterialTheme.colorScheme.primary, maxLines = 2)
                }
            }
            if (contact.notes.isNotBlank()) {
                Card(Modifier.fillMaxWidth()) { Text(contact.notes, Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium) }
            }
            if (contact.email.isNotBlank()) DetailRow(Icons.Default.Email, "Email", contact.email)
            if (contact.phone.isNotBlank()) DetailRow(Icons.Default.Phone, "Phone", contact.phone)
            if (contact.linkedin.isNotBlank()) DetailRow(Icons.Default.Link, "LinkedIn", contact.linkedin)
            if (contact.company.isNotBlank()) DetailRow(Icons.Default.Business, "Company", contact.company)
            Spacer(Modifier.height(4.dp))
            Button(onClick = onChat, Modifier.fillMaxWidth().height(48.dp)) { Text("Message") }
        }
    }
}

@Composable
private fun DetailRow(icon: androidx.compose.ui.graphics.vector.ImageVector, label: String, value: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Top, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Column(Modifier.weight(1f)) {
            Text(label, style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, style = MaterialTheme.typography.bodyMedium)
        }
    }
}
