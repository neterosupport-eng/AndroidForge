package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [ConnectionEntity::class], version = 2, exportSchema = false)
abstract class NeteroDatabase : RoomDatabase() {
    abstract fun connectionDao(): ConnectionDao

    companion object {
        @Volatile
        private var Instance: NeteroDatabase? = null

        fun getDatabase(context: Context): NeteroDatabase {
            return Instance ?: synchronized(this) {
                Room.databaseBuilder(
                    context.applicationContext,
                    NeteroDatabase::class.java,
                    "netero_database"
                )
                .fallbackToDestructiveMigration(false)
                .fallbackToDestructiveMigrationOnDowngrade()
                .build()
                .also { Instance = it }
            }
        }
    }
}
