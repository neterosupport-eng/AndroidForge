package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.data.model.ConnectionContact

@Entity(tableName = "connections")
data class ConnectionEntity(
    @PrimaryKey val id: String,
    val name: String,
    val jobTitle: String,
    val company: String,
    val source: String,
    val dateConnected: String,
    val notes: String,
    val tagsCsv: String,
    val email: String,
    val linkedin: String,
    val phone: String,
    val whatsapp: String,
    val avatarInitial: String,
    val avatarBgHex: Long,
    val lastContactedMillis: Long = System.currentTimeMillis()
) {
    fun toContact() = ConnectionContact(
        id = id,
        name = name,
        jobTitle = jobTitle,
        company = company,
        source = source,
        dateConnected = dateConnected,
        notes = notes,
        tags = if (tagsCsv.isEmpty()) emptyList() else tagsCsv.split(","),
        email = email,
        linkedin = linkedin,
        phone = phone,
        whatsapp = whatsapp,
        avatarInitial = avatarInitial,
        avatarBgHex = avatarBgHex,
        lastContactedMillis = lastContactedMillis
    )
}

fun ConnectionContact.toEntity() = ConnectionEntity(
    id = id,
    name = name,
    jobTitle = jobTitle,
    company = company,
    source = source,
    dateConnected = dateConnected,
    notes = notes,
    tagsCsv = tags.joinToString(","),
    email = email,
    linkedin = linkedin,
    phone = phone,
    whatsapp = whatsapp,
    avatarInitial = avatarInitial,
    avatarBgHex = avatarBgHex,
    lastContactedMillis = lastContactedMillis
)
