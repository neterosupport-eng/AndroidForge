package com.example.data.api

import com.google.firebase.functions.FirebaseFunctions
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.ByteArrayOutputStream
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

object GeminiAiHelper {
    private val functions by lazy { FirebaseFunctions.getInstance() }

    private suspend fun callAsteron(operation: String, payload: Map<String, Any?>): JSONObject? = withContext(Dispatchers.IO) {
        try {
            val data = HashMap<String, Any?>()
            data["operation"] = operation
            data.putAll(payload)
            val result = functions.getHttpsCallable("asteronAi").call(data).await()
            val raw = result.data
            @Suppress("UNCHECKED_CAST")
            val map = raw as? Map<String, Any?> ?: return@withContext null
            JSONObject(map)
        } catch (_: Exception) {
            null
        }
    }
    private fun extractTextFromCandidate(candidate: JSONObject): String {
        val content = candidate.optJSONObject("content") ?: return ""
        val parts = content.optJSONArray("parts") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until parts.length()) {
            val part = parts.optJSONObject(i) ?: continue
            // Skip thought parts if present in thinking models
            val isThought = part.optBoolean("thought", false)
            if (!isThought && part.has("text")) {
                sb.append(part.getString("text"))
            }
        }
        val result = sb.toString().trim()
        if (result.isNotBlank()) return result
        // Fallback to first text part if all had thought flag or single part
        if (parts.length() > 0) {
            val firstPart = parts.optJSONObject(0)
            return firstPart?.optString("text", "")?.trim() ?: ""
        }
        return ""
    }

    suspend fun generateText(prompt: String, systemInstruction: String? = null, webResearch: Boolean = false): String = withContext(Dispatchers.IO) {
        val baseSystemInstruction = "You are Asteron AI, an intelligent professional networking copilot created for Netero. Focus on networking, career connections, introductions, icebreakers, business synergy and useful professional actions. Never mention third-party AI providers unless technically required."
        val finalSystemInstruction = if (!systemInstruction.isNullOrBlank()) "$baseSystemInstruction\n\n$systemInstruction" else baseSystemInstruction
        val result = callAsteron("generateText", mapOf(
            "prompt" to prompt,
            "systemInstruction" to finalSystemInstruction,
            "webResearch" to webResearch
        ))
        result?.optString("text", "")?.takeIf { it.isNotBlank() } ?: "Asteron is temporarily unavailable. Please try again in a moment."
    }

    suspend fun researchProfile(
        name: String,
        role: String,
        company: String,
        context: String,
        industry: String = "",
        bio: String = "",
        skills: List<String> = emptyList(),
        linkedinUrl: String = "",
        portfolioUrl: String = "",
        websiteUrl: String = "",
        businessUrl: String = ""
    ): String = withContext(Dispatchers.IO) {
        val safeRole = role.ifBlank { "Professional" }
        val safeCompany = company.ifBlank { "Independent" }
        val safeIndustry = industry.ifBlank { "Tech & Business" }

        val prompt = """
            You are Asteron AI, an executive intelligence researcher. Analyze this professional and write a sharp, highly concise 3-line breakdown (maximum 3 to 4 lines):
            - Name: $name
            - Role: $safeRole
            - Company: $safeCompany
            - Industry: $safeIndustry
            - Bio / Context: ${bio.ifBlank { context }}
            - LinkedIn: ${linkedinUrl.ifBlank { "N/A" }}
            - Portfolio: ${portfolioUrl.ifBlank { "N/A" }}
            - Personal Website: ${websiteUrl.ifBlank { "N/A" }}
            - Business/Company URL: ${businessUrl.ifBlank { "N/A" }}

            FORMAT REQUIREMENTS (Strictly 3 lines total):
            Line 1: 👤 **Focus**: Daily focus and key role responsibilities as $safeRole at $safeCompany.
            Line 2: 🏢 **Company Specialization**: What $safeCompany does in the $safeIndustry space.
            Line 3: 💡 **Synergy & Topic**: Concrete collaboration synergy and natural icebreaker topic to discuss.

            CRITICAL: Strictly 3 lines. Ground everything in their real title, company, and industry.
        """.trimIndent()

        val result = callAsteron("researchProfile", mapOf(
            "prompt" to prompt,
            "systemInstruction" to "Research this person and company using the supplied public professional links first and broader public web sources when useful. Clearly distinguish facts supplied in the Netero profile from information found publicly. Do not invent facts or claim access to private/logged-in pages. Return concise, professional, actionable networking intelligence.",
            "webResearch" to true
        ))
        val text = result?.optString("text", "") ?: ""

        if (text.isNotBlank() && !text.startsWith("That's a thoughtful")) {
            text
        } else {
            "Asteron could not complete public research right now. Please try again."
        }
    }

    suspend fun generateIcebreakers(
        contactName: String,
        contactRole: String,
        contactCompany: String,
        contextNotes: String
    ): List<String> = withContext(Dispatchers.IO) {
        val prompt = """
            Generate 3 short, punchy, conversational icebreakers for meeting this person:
            Name: $contactName
            Title (or Major): $contactRole
            Company (or University): $contactCompany
            Context: $contextNotes
            *Note*: If Title contains a degree or Company contains a university, they are likely a student. Tailor icebreakers to ask about their studies, graduation goals, or internships.

            Return 3 distinct bullet points:
            1. Direct & Enthusiastic
            2. Tech/Industry Collaboration Focus
            3. Casual Coffee / Quick Intro
            Keep each under 20 words. No corporate jargon.
        """.trimIndent()

        val rawText = generateText(
            prompt = prompt,
            systemInstruction = "You are an elite networking mentor creating natural, high-response icebreaker lines for in-person and digital networking."
        )

        val lines = rawText.lines()
            .map { it.replace(Regex("^\\d+[.)-]\\s*|^[•*-]\\s*"), "").replace(Regex("[*#_~]"), "").trim() }
            .filter { it.isNotBlank() && it.length > 5 }

        if (lines.isNotEmpty()) lines.take(3) else listOf(
            "Hey $contactName! Great connecting. Would love to hear about what you're building at $contactCompany.",
            "Loved your focus on $contactRole. Let's exchange quick thoughts over coffee!",
            "Hi $contactName, glad we connected via Netero. Let's explore potential synergies between our teams."
        )
    }

    suspend fun generateFollowUpDraft(
        contactName: String,
        contactRole: String,
        contactCompany: String,
        meetingContext: String,
        userGoals: String,
        contactIndustry: String = ""
    ): String = withContext(Dispatchers.IO) {
        val industryFocus = when {
            contactIndustry.contains("saas", ignoreCase = true) || contactIndustry.contains("software", ignoreCase = true) || contactIndustry.contains("tech", ignoreCase = true) || contactIndustry.contains("ai", ignoreCase = true) ->
                "Focus on engineering velocity, product roadmap, tech stack synergies, or AI integration."
            contactIndustry.contains("finance", ignoreCase = true) || contactIndustry.contains("vc", ignoreCase = true) || contactIndustry.contains("invest", ignoreCase = true) || contactIndustry.contains("capital", ignoreCase = true) ->
                "Focus on market dynamics, capital efficiency, deal flow, investment thesis, or portfolio synergy."
            contactIndustry.contains("health", ignoreCase = true) || contactIndustry.contains("pharma", ignoreCase = true) || contactIndustry.contains("med", ignoreCase = true) || contactIndustry.contains("bio", ignoreCase = true) ->
                "Focus on patient outcomes, clinical efficacy, regulatory pathways, or healthcare innovation."
            contactIndustry.contains("marketing", ignoreCase = true) || contactIndustry.contains("design", ignoreCase = true) || contactIndustry.contains("media", ignoreCase = true) || contactIndustry.contains("brand", ignoreCase = true) ->
                "Focus on brand resonance, storytelling, acquisition metrics, conversion funnel, or user experience."
            contactIndustry.contains("student", ignoreCase = true) || contactIndustry.contains("edu", ignoreCase = true) || contactIndustry.contains("academic", ignoreCase = true) ->
                "Focus on learning milestones, career guidance, research collaboration, or practical project insights."
            else ->
                "Focus on industry-leading innovation, mutual professional growth, and shared strategic goals in ${contactIndustry.ifBlank { "your sector" }}."
        }

        val prompt = """
            Draft a highly personalized, tailored 3-sentence networking follow-up message:
            Recipient: $contactName
            Role: $contactRole
            Company: $contactCompany
            Industry: ${contactIndustry.ifBlank { "General Industry" }}
            Where we met: $meetingContext
            Sender's Goals: $userGoals
            
            Industry Directive:
            $industryFocus
            
            CRITICAL RULES:
            - Every person and industry MUST receive a completely distinct follow-up tailored to their specific profession ($contactRole) and sector (${contactIndustry.ifBlank { contactCompany }}).
            - DO NOT output generic copy-paste templates.
            - Structure:
              1. Warm personal greeting referencing their specific domain or company.
              2. Precise collaborative value proposition relevant to their industry.
              3. Courteous, low-friction invitation for a quick 10-15 minute sync.
        """.trimIndent()

        val text = generateText(
            prompt = prompt,
            systemInstruction = "You are Asteron AI, an executive networking strategist crafting bespoke follow-up communications distinctly tailored to each professional's industry."
        )

        if (text.isNotBlank()) text else {
            when {
                contactIndustry.contains("tech", ignoreCase = true) || contactIndustry.contains("ai", ignoreCase = true) || contactIndustry.contains("software", ignoreCase = true) ->
                    "Hi $contactName, great connecting! Really impressed by the technical problems you're solving at $contactCompany. Would love to grab a quick 15-minute chat next week to swap notes on architecture and product scale."
                contactIndustry.contains("finance", ignoreCase = true) || contactIndustry.contains("vc", ignoreCase = true) ->
                    "Hi $contactName, thoroughly enjoyed our discussion regarding current market moves. I'd love to schedule a brief 15-minute sync next week to compare notes on sector trends and explore strategic co-investment or growth opportunities with $contactCompany."
                contactIndustry.contains("health", ignoreCase = true) ->
                    "Hi $contactName, fantastic meeting you today! Your insights into clinical operations and healthcare delivery at $contactCompany were truly eye-opening. Let's find 15 minutes next week to discuss potential technological and collaborative synergies."
                else ->
                    "Hi $contactName, great meeting you today! Loved hearing about your vision and initiatives at $contactCompany. Would love to sync up for a quick 15-minute coffee chat next week to explore meaningful ways we can collaborate."
            }
        }
    }

    suspend fun analyzeUserProfileDeeply(profile: com.example.data.model.UserProfile): JSONObject = withContext(Dispatchers.IO) {
        val prompt = """
            Analyze this professional profile to derive their executive networking persona, key focus domain, and high-synergy target connections:
            - Full Name: ${profile.fullName}
            - Current Role: ${profile.jobTitle.ifBlank { "Professional" }} at ${profile.company.ifBlank { "Independent" }}
            - Industry: ${profile.industry.ifBlank { "Technology & Business" }}
            - Headline: ${profile.headline}
            - Bio: ${profile.bio}
            - Skills: ${profile.skills.joinToString(", ")}
            - Interests: ${profile.interests.joinToString(", ")}
            - Goals: ${profile.networkingGoals}

            Return strictly a JSON object with:
            {
               "networkingPersona": "1-2 sentence executive summary of what they do and the unique value they bring",
               "targetSynergies": ["3 specific types of people, roles, or sectors they should meet on Netero"],
               "focusKeywords": ["4-6 high-impact keywords representing their domain and interests"]
            }
        """.trimIndent()

        val text = generateText(
            prompt = prompt,
            systemInstruction = "You are Asteron AI's backend executive profile analyzer. Output strictly valid JSON."
        )

        try {
            val clean = text.replace("```json", "").replace("```", "").trim()
            JSONObject(clean)
        } catch (e: Exception) {
            JSONObject().apply {
                put("networkingPersona", "${profile.fullName.ifBlank { "Member" }} is a ${profile.jobTitle.ifBlank { "specialist" }} in ${profile.industry.ifBlank { "tech" }} focused on impactful collaboration.")
                val list = JSONArray()
                list.put("Innovators in ${profile.industry.ifBlank { "Tech" }}")
                list.put("Collaborators in ${profile.company.ifBlank { "Industry" }}")
                list.put("Mentors & Growth Leaders")
                put("targetSynergies", list)
                val kw = JSONArray()
                if (profile.industry.isNotBlank()) kw.put(profile.industry)
                if (profile.jobTitle.isNotBlank()) kw.put(profile.jobTitle)
                profile.skills.take(3).forEach { kw.put(it) }
                put("focusKeywords", kw)
            }
        }
    }

    suspend fun analyzeQuestionIntent(prompt: String): JSONObject = withContext(Dispatchers.IO) {
        val pLower = prompt.lowercase()
        val detectedIndustries = mutableListOf<String>()
        val industryKeywords = mapOf(
            "saas" to listOf("saas", "sas", "cloud software", "b2b software"),
            "fintech" to listOf("fintech", "finance", "banking", "payments", "crypto", "web3", "defi"),
            "healthtech" to listOf("health", "healthcare", "healthtech", "biotech", "medical", "pharma"),
            "ai" to listOf("ai", "artificial intelligence", "machine learning", "ml", "llm", "deep learning"),
            "edtech" to listOf("edtech", "education", "student", "university", "learning"),
            "marketing" to listOf("marketing", "growth", "branding", "seo", "advertising"),
            "design" to listOf("design", "ui", "ux", "product design"),
            "venture capital" to listOf("vc", "investor", "angel", "funding", "fundraise", "venture capital", "pitch")
        )
        for ((ind, words) in industryKeywords) {
            if (words.any { pLower.contains(it) }) {
                detectedIndustries.add(ind)
            }
        }

        val jsonPrompt = """
            Analyze the user's networking question or search query:
            Question: "$prompt"

            Determine:
            1. If they are asking about or looking for a specific PERSON by name or username (e.g. "Who is John?", "Tell me about Sarah Connor", "Can you find David?"). If yes, extract that person's name into "personName". If not, leave "personName" empty.
            2. Any specific industries mentioned or implied (e.g. SaaS, Fintech, Healthcare, AI, Edu, etc.) into "industries" array.
            3. Any specific roles or titles sought (e.g. founder, investor, CTO, engineer, designer) into "roles" array.
            4. Key search/topic keywords into "keywords" array.

            Return strictly a JSON object:
            {
              "personName": "",
              "industries": [],
              "roles": [],
              "keywords": []
            }
        """.trimIndent()

        val text = generateText(
            prompt = jsonPrompt,
            systemInstruction = "You are Asteron AI's query intent analyzer. Extract user intent, target people, and industries accurately. Return strictly valid JSON."
        )

        try {
            val clean = text.replace("```json", "").replace("```", "").trim()
            val obj = JSONObject(clean)
            val indArray = obj.optJSONArray("industries") ?: JSONArray()
            val existing = (0 until indArray.length()).map { indArray.getString(it).lowercase() }.toSet()
            for (ind in detectedIndustries) {
                if (!existing.contains(ind.lowercase())) {
                    indArray.put(ind)
                }
            }
            obj.put("industries", indArray)
            obj
        } catch (e: Exception) {
            JSONObject().apply {
                put("personName", "")
                put("industries", JSONArray(detectedIndustries))
                put("roles", JSONArray())
                put("keywords", JSONArray())
            }
        }
    }

    suspend fun curateDiscoverList(
        userRole: String,
        userCompany: String = "",
        userIndustry: String,
        userBio: String,
        userInterests: String = "",
        candidatesJson: String,
        learnedBehaviorContext: String = ""
    ): JSONObject? = withContext(Dispatchers.IO) {
        val prompt = """
            You are an elite networking matchmaker. Carefully analyze the user and candidate profiles.
            
            Current User:
            - Role: $userRole at $userCompany
            - Industry: $userIndustry
            - Bio: ${userBio.ifBlank { "Not specified" }}
            - Interests: ${userInterests.ifBlank { "Not specified" }}
            ${if (learnedBehaviorContext.isNotBlank()) "User's Recent Inquiries & AI-Analyzed Search Intent:\n$learnedBehaviorContext" else ""}
            
            Candidate Profiles (JSON):
            $candidatesJson
            
            Instructions:
            1. Read each candidate's bio, job title, company, shared interests, and portfolio.
            2. Match candidates who share high synergy (e.g. complementary skillsets, common industry challenges, investor/founder alignment, student/mentor opportunities, or candidates matching their recently searched industries).
            3. Only return candidates with a genuine, evidence-based networking fit. Do NOT match someone merely because they are in the same broad industry.
            4. For each selected candidate, provide a 0-100 matchScore based on the strength of the professional/networking fit. Use the full range: 90-100 = exceptionally relevant, 75-89 = strong, 60-74 = moderate, below 60 = do not return.
            5. Write a concise, specific 1-sentence matchReason explaining the concrete overlap, complementarity, goal, or opportunity. Never invent facts that are not present in the supplied profile.
            6. Return ONLY a valid JSON object with a single key "matches", containing at most 30 objects:
               [{"id": "...", "matchScore": 87, "matchReason": "..."}]
        """.trimIndent()
        
        val text = generateText(
            prompt = prompt,
            systemInstruction = "You are an elite professional matchmaking algorithm. Analyze bios, job titles, and portfolios deeply. Output strictly valid JSON."
        )
        
        val parsed = try {
            var cleanText = text.replace("```json", "").replace("```", "").trim()
            JSONObject(cleanText)
        } catch (e: Exception) {
            null
        }
        if (parsed != null && parsed.has("matches")) return@withContext parsed

        try {
            val candidatesArray = org.json.JSONArray(candidatesJson)
            val fallbackMatches = org.json.JSONArray()
            for (i in 0 until candidatesArray.length()) {
                val candidate = candidatesArray.getJSONObject(i)
                val cId = candidate.optString("id")
                val cTitle = candidate.optString("jobTitle")
                val cComp = candidate.optString("company")
                val cInd = candidate.optString("industry")
                val cBio = candidate.optString("bio")
                val reason = if (cBio.isNotBlank()) {
                    "Aligned background in $cInd: ${cBio.take(60)}..."
                } else if (cComp.isNotBlank()) {
                    "Potential professional synergy in $cInd ($cTitle at $cComp)."
                } else {
                    "Potential professional fit in $cInd ($cTitle)."
                }
                val matchObj = JSONObject().apply {
                    put("id", cId)
                    put("matchScore", 60)
                    put("matchReason", reason)
                }
                fallbackMatches.put(matchObj)
            }
            JSONObject().put("matches", fallbackMatches)
        } catch (e: Exception) {
            null
        }
    }

    suspend fun extractBusinessCardData(imageBytes: ByteArray, ocrHintText: String = ""): JSONObject? = withContext(Dispatchers.IO) {
        // 1. Fast on-device safety check for payment cards (credit/debit cards)
        val hasCardNumberPattern = Regex("(?:\\d[ -]*?){13,19}").containsMatchIn(ocrHintText)
        val hasPaymentCardKeywords = Regex("(?i)(visa|mastercard|maestro|rupay|amex|american express|credit card|debit card|valid thru|expires end|cvv|cvc)").containsMatchIn(ocrHintText)
        if (hasCardNumberPattern && hasPaymentCardKeywords) {
            return@withContext JSONObject().apply {
                put("isBusinessCard", false)
                put("isSensitivePaymentCard", true)
            }
        }

        // 2. Fast check for code / programming syntax / terminal output
        val codeKeywords = listOf("import ", "fun ", "class ", "val ", "var ", "const ", "def ", "public static", "console.log", "<div>", "function(", "return ", "SELECT ", "CREATE TABLE", "xmlns:")
        val isCodeSnippet = codeKeywords.count { ocrHintText.contains(it, ignoreCase = false) } >= 2
        if (isCodeSnippet) {
            return@withContext JSONObject().apply {
                put("isBusinessCard", false)
                put("isCodeSnippet", true)
            }
        }

        val bitmap = BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
        val uploadBytes = if (bitmap != null) {
            val maxDim = maxOf(bitmap.width, bitmap.height)
            val scaled = if (maxDim > 1600) {
                val scale = 1600f / maxDim.toFloat()
                Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt().coerceAtLeast(1), (bitmap.height * scale).toInt().coerceAtLeast(1), true)
            } else bitmap
            val out = ByteArrayOutputStream()
            scaled.compress(android.graphics.Bitmap.CompressFormat.JPEG, 80, out)
            if (scaled !== bitmap) scaled.recycle()
            bitmap.recycle()
            out.toByteArray()
        } else imageBytes
        val base64Image = android.util.Base64.encodeToString(uploadBytes, android.util.Base64.NO_WRAP)
        val result = callAsteron("businessCard", mapOf(
            "imageBase64" to base64Image,
            "mimeType" to "image/jpeg",
            "ocrText" to ocrHintText
        ))
        result
    }

    suspend fun summarizeRoomDiscussions(roomName: String, messages: List<Pair<String, String>>): String = withContext(Dispatchers.IO) {
        val totalDiscussionChars = messages.sumOf { it.second.trim().length }
        if (messages.isEmpty() || totalDiscussionChars < 25) {
            return@withContext "Nothing has been discussed in this room yet to summarize. Start a conversation or share topics to generate an AI summary!"
        }
        val conversationText = messages.takeLast(40).joinToString("\n") { (author, text) -> "$author: $text" }
        val prompt = """
            You are a friendly and intelligent networking assistant.
            Please summarize the conversation in the discussion room "$roomName":
            
            $conversationText
            
            Requirements:
            - Respond naturally like a normal helpful AI in 2 to 3 concise sentences.
            - Summarize the topics discussed and any collaboration points.
            - Do NOT use markdown headers (###), hashtags, bold section titles, or long essay bullet points.
            - Keep it clean, direct, and under 60 words.
        """.trimIndent()

        val result = generateText(
            prompt = prompt,
            systemInstruction = "You are a concise, helpful networking assistant. Deliver brief, natural conversational summaries without markdown headers (###) or hashtag symbols."
        )

        val cleanResult = result
            .replace(Regex("^#+\\s*.*$", RegexOption.MULTILINE), "")
            .replace("###", "")
            .replace("##", "")
            .trim()

        if (cleanResult.isNotBlank() && !cleanResult.startsWith("That's a thoughtful") && !cleanResult.startsWith("Great question")) {
            cleanResult
        } else {
            val authors = messages.map { it.first }.distinct()
            "Recent discussions in \"$roomName\" with ${authors.joinToString(", ")}. Members have started connecting and sharing insights."
        }
    }

    private fun getContextualFallback(prompt: String): String {
        val lower = prompt.lowercase().trim()
        return when {
            lower.contains("joke") ->
                "Why do programmers prefer dark mode?\nBecause light attracts bugs! 🐛😄\n\nNeed another joke, a quick elevator pitch, or help connecting with someone on Netero?"
            lower.contains("how are you") || lower.contains("how r u") || lower.contains("how's it going") ->
                "I'm doing great, thank you for asking! 😊 I'm here and fully ready to help you discover awesome connections, refine pitches, or chat about anything on your mind. How is your day going?"
            lower.contains("weather") ->
                "While I can't check local satellite radar in real-time without GPS permissions, I can tell you it's always a bright day to build meaningful connections on Netero! ☀️ How is the weather where you are?"
            lower.contains("morning") ->
                "Good morning! ☀️ Wishing you a productive and inspiring day ahead. What goals or networking plans are on your agenda today?"
            lower.contains("evening") || lower.contains("night") ->
                "Good evening! 🌙 Hope you had a rewarding day. Time to unwind, review your connections, or prep for tomorrow!"
            lower.contains("who are you") || lower.contains("what is your name") || lower.contains("what can you do") ->
                "I am **Asteron AI**, your intelligent networking and conversation copilot. I can answer any casual questions, find people across industries, craft customized elevator pitches, draft follow-up notes, and optimize your digital presence."
            lower in listOf("hi", "hello", "hey", "hii", "hola", "sup", "yo") || lower.startsWith("hi ") || lower.startsWith("hello ") || lower.startsWith("hey ") ->
                "Hello! 👋 I'm your Asteron AI copilot. Feel free to ask me anything—from everyday casual questions to networking strategies, cold emails, or startup advice. What's on your mind?"
            lower.contains("thank") ->
                "You're very welcome! Always happy to help. Let me know if you need anything else! 🚀"
            lower.contains("follow-up") || lower.contains("follow up") -> {
                val name = Regex("Recipient:\\s*([^\\n(]+)", RegexOption.IGNORE_CASE).find(prompt)?.groupValues?.get(1)?.trim() ?: ""
                val role = Regex("Role:\\s*([^\\n]+)", RegexOption.IGNORE_CASE).find(prompt)?.groupValues?.get(1)?.trim() ?: ""
                val company = Regex("Company:\\s*([^\\n]+)", RegexOption.IGNORE_CASE).find(prompt)?.groupValues?.get(1)?.trim() ?: ""
                val industry = Regex("Industry:\\s*([^\\n]+)", RegexOption.IGNORE_CASE).find(prompt)?.groupValues?.get(1)?.trim() ?: ""

                val greeting = if (name.isNotBlank()) "Hi $name," else "Hi,"
                when {
                    industry.contains("tech", ignoreCase = true) || industry.contains("ai", ignoreCase = true) || industry.contains("software", ignoreCase = true) || role.contains("architect", ignoreCase = true) || role.contains("engineer", ignoreCase = true) ->
                        "$greeting great connecting! Really impressed by the technical problems you're tackling at ${company.ifBlank { "your team" }}. Would love to grab a quick 15-minute chat next week to swap notes on architecture, product scaling, and software engineering."
                    industry.contains("finance", ignoreCase = true) || industry.contains("vc", ignoreCase = true) || industry.contains("invest", ignoreCase = true) || role.contains("partner", ignoreCase = true) ->
                        "$greeting thoroughly enjoyed our discussion regarding current market moves and investment opportunities. I'd love to schedule a brief 15-minute sync next week to compare notes on sector trends and explore strategic synergy with ${company.ifBlank { "your fund" }}."
                    industry.contains("health", ignoreCase = true) || industry.contains("bio", ignoreCase = true) || industry.contains("med", ignoreCase = true) || role.contains("clinical", ignoreCase = true) ->
                        "$greeting fantastic meeting you! Your insights into clinical operations and healthcare innovation at ${company.ifBlank { "your organization" }} were truly inspiring. Let's find 15 minutes next week to discuss potential technological synergies."
                    industry.contains("marketing", ignoreCase = true) || industry.contains("design", ignoreCase = true) || role.contains("designer", ignoreCase = true) ->
                        "$greeting great connecting! Really loved hearing your perspective on brand resonance and user experience design at ${company.ifBlank { "your team" }}. Let's grab coffee or jump on a quick 15-minute call next week to explore creative collaborations."
                    else ->
                        "$greeting great meeting you today! Loved hearing about your vision and initiatives at ${company.ifBlank { "your organization" }}. Would love to sync up for a quick 15-minute coffee chat next week to explore meaningful ways we can collaborate."
                }
            }
            lower.contains("summarize") || lower.contains("recap") || lower.contains("discussions from room") ->
                """
📌 Executive Overview:
Members engaged in collaborative discussions, sharing professional backgrounds and project insights.

💡 Key Ideas & Opportunities:
• Collaborative networking and domain knowledge shared by active members.
• Discussion on project milestones, technology topics, and opportunities.

🚀 Recommended Next Actions:
• Reach out directly to room participants to connect 1-on-1.
• Follow up on shared ideas and explore mutual synergies.
                """.trimIndent()
            (Regex("\\bbio\\b").containsMatchIn(lower) || lower.contains("profile bio")) && !lower.contains("recipient:") ->
                "Founder & Tech Builder building next-generation mobile products. Passionate about real-world digital identity, scalable distributed systems, and AI. Always excited to connect with visionary founders, investors, and engineers."
            lower.contains("icebreaker") || lower.contains("intro") ->
                "1. Direct: Hey! Great meeting you. Loved your work at your company and wanted to connect.\n2. Collaboration: Would love to explore potential tech synergies between our projects.\n3. Casual: Let's grab a quick coffee sometime this week!"
            lower.contains("pitch") || lower.contains("elevator") ->
                "Netero is a live digital identity platform where business cards auto-update in real time. When you change your phone, title, or company, all past connections update instantly with granular privacy control."
            else ->
                "That's a thoughtful question! Whether you're exploring creative ideas, casual thoughts, tech concepts, or looking to connect with industry leaders on Netero, I'm here to help. What specific aspect would you like to dive into?"
        }
    }
}
