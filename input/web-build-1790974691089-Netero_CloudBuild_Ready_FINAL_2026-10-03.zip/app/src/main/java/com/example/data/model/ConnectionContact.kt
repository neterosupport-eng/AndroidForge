package com.example.data.model

data class ConnectionContact(
    val id: String,
    val name: String,
    val jobTitle: String,
    val company: String,
    val source: String = "QR", // QR, Room, Profile, Search, Event
    val dateConnected: String = "Today",
    val locationMet: String = "",
    val lastContactedMillis: Long = System.currentTimeMillis(),
    val notes: String = "",
    val tags: List<String> = emptyList(),
    val email: String = "",
    val linkedin: String = "",
    val phone: String = "",
    val whatsapp: String = "",
    val portfolio: String = "",
    val profileImageUrl: String = "",
    val avatarInitial: String = "",
    val avatarBgHex: Long = 0xFF2962FF
)
