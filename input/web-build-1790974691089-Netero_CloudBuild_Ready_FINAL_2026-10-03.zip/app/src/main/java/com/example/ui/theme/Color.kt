package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val LinkedInBlue = Color(0xFF0A66C2)
val LinkedInLightBlue = Color(0xFF70B5F9)
val LinkedInDarkBg = Color(0xFF1D2226)
val LinkedInDarkSurface = Color(0xFF293138)
val LinkedInLightBg = Color(0xFFF3F2EF)
val LinkedInLightSurface = Color(0xFFFFFFFF)
val LinkedInTextDark = Color(0xFF191919)
val LinkedInTextLight = Color(0xFFE9E9E9)
val LinkedInTextGray = Color(0xFF666666)
val LinkedInGreen = Color(0xFF057642)

val PrimaryBlack = Color(0xFF191919) // used in some text
val PureWhite = Color(0xFFFFFFFF)
val TextGray = Color(0xFF666666)
val AccentBlue = Color(0xFF0A66C2) // Keep this for backward compatibility
val AccentBlueSubtle = Color(0x1F0A66C2)
val SuccessGreen = Color(0xFF057642)

val DarkSurface = LinkedInDarkSurface
val DarkSurfaceVariant = Color(0xFF38434F)
val DarkBorder = Color(0xFF434B53)
val LightSurface = LinkedInLightSurface
val LightSurfaceVariant = Color(0xFFE9F0F8)
val LightBorder = Color(0xFFDCE6F1)

val NeteroTeal = AccentBlue
val NeteroNavy = PrimaryBlack
val NeteroCyan = LinkedInLightBlue
val NeteroGreen = SuccessGreen
val LightGray = LinkedInLightBg
val AccentBlueHover = Color(0xFFDCE6F1)
val DarkBorderVariant = Color(0xFF434B53)
