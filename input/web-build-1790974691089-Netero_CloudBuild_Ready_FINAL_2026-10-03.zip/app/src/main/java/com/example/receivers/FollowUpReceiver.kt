package com.example.receivers

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.R

class FollowUpReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val contactName = intent.getStringExtra("contactName") ?: "your connection"
        val customMessage = intent.getStringExtra("customMessage") ?: "Time to follow up with $contactName!"
        
        val notificationManager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                "follow_up_channel",
                "Follow-Up Reminders",
                NotificationManager.IMPORTANCE_HIGH
            )
            notificationManager.createNotificationChannel(channel)
        }

        val notification = NotificationCompat.Builder(context, "follow_up_channel")
            .setSmallIcon(R.mipmap.ic_launcher_round)
            .setContentTitle("Asteron AI Smart Reminder")
            .setContentText(customMessage)
            .setStyle(NotificationCompat.BigTextStyle().bigText(customMessage))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .build()

        notificationManager.notify(contactName.hashCode(), notification)
    }
}
