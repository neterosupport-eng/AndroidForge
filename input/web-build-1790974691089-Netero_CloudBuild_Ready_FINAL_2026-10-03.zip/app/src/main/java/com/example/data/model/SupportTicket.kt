package com.example.data.model

data class SupportTicket(
    val id: String = "",
    val ticketId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userEmail: String = "",
    val userPhone: String = "",
    val subject: String = "",
    val message: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val status: String = "Under Review",
    val supportNote: String = "Our support team is reviewing your ticket and will reply directly to your email address."
)
