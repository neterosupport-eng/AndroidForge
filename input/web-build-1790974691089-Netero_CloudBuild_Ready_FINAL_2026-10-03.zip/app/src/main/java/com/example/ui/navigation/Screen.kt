package com.example.ui.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.MeetingRoom
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.outlined.Explore
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MeetingRoom
import androidx.compose.material.icons.outlined.People
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.ui.graphics.vector.ImageVector

sealed class Screen(
    val route: String,
    val title: String = "",
    val selectedIcon: ImageVector? = null,
    val unselectedIcon: ImageVector? = null
) {
    object Onboarding : Screen("onboarding")
    object Welcome : Screen("welcome")
    object ProfileSetup : Screen("profile_setup")
    object RoomDetail : Screen("room_detail/{roomId}") {
        fun createRoute(roomId: String) = "room_detail/$roomId"
    }
    object NeteroLockSettings : Screen("netero_lock_settings")
    object Analytics : Screen("analytics")
    object HelpDesk : Screen("help_desk")
    object ChatDetail : Screen("chat_detail/{contactId}") {
        fun createRoute(contactId: String) = "chat_detail/$contactId"
    }

    object PendingConnections : Screen("pending_connections")
    object RecommendedConnections : Screen("recommended_connections")    object Paywall : Screen("paywall")
    // Bottom Navigation destinations
    object Home : Screen(
        route = "home",
        title = "Home",
        selectedIcon = Icons.Filled.Home,
        unselectedIcon = Icons.Outlined.Home
    )

    object Discover : Screen(
        route = "discover",
        title = "Discover",
        selectedIcon = Icons.Filled.Explore,
        unselectedIcon = Icons.Outlined.Explore
    )

    object Rooms : Screen(
        route = "rooms",
        title = "Rooms",
        selectedIcon = Icons.Filled.MeetingRoom,
        unselectedIcon = Icons.Outlined.MeetingRoom
    )

    object Scan : Screen(
        route = "scan",
        title = "Scan",
        selectedIcon = Icons.Filled.QrCodeScanner,
        unselectedIcon = Icons.Outlined.QrCodeScanner
    )

    object Connections : Screen(
        route = "connections",
        title = "Connections",
        selectedIcon = Icons.Filled.People,
        unselectedIcon = Icons.Outlined.People
    )

    object Profile : Screen(
        route = "profile",
        title = "Profile",
        selectedIcon = Icons.Filled.Person,
        unselectedIcon = Icons.Outlined.Person
    )

    companion object {
        val bottomNavScreens: List<Screen>
            get() = listOf(Home, Rooms, Scan, Connections, Profile)
    }
}
