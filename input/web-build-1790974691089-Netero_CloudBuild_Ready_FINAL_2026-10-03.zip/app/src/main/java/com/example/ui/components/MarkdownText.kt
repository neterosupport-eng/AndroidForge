package com.example.ui.components

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.sp

@Composable
fun MarkdownText(
    text: String, 
    color: Color, 
    modifier: Modifier = Modifier,
    onTextLayout: (androidx.compose.ui.text.TextLayoutResult) -> Unit = {}
) {
    val onSurface = color
    val annotatedString = buildAnnotatedString {
        val lines = text.split("\n")
        for ((index, rawLine) in lines.withIndex()) {
            var currentLine = rawLine.trimEnd()

            // 1. Remove divider rules (---, ***, ___)
            if (currentLine.trim().matches(Regex("^[-*_]{3,}$"))) {
                if (index < lines.size - 1) append("\n")
                continue
            }

            // 2. Remove blockquote markers (> or >>)
            currentLine = currentLine.trimStart().replace(Regex("^>+\\s*"), "").trimStart()

            // 3. Remove hashtag headers (# Header, ## Header, ### Header, #### Header, etc.)
            val hadHashtags = currentLine.trimStart().startsWith("#")
            currentLine = currentLine.trimStart().replace(Regex("^#{1,6}\\s*"), "").trim()
            if (hadHashtags) {
                withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, fontSize = 16.sp, color = onSurface)) {
                    append(currentLine)
                }
            } else {
                // 4. Handle bullet points (* or - or +)
                val trimmed = currentLine.trimStart()
                if (trimmed.startsWith("* ") || trimmed.startsWith("- ") || trimmed.startsWith("+ ")) {
                    append("• ")
                    currentLine = trimmed.substring(2)
                }

                // 5. Handle bold (**text**) and italic (*text*)
                val parts = currentLine.split(Regex("(?=\\*\\*)|(?<=\\*\\*)"))
                var isBold = false
                for (part in parts) {
                    if (part == "**") {
                        isBold = !isBold
                    } else {
                        if (isBold) {
                            withStyle(style = SpanStyle(fontWeight = FontWeight.Bold, color = onSurface)) {
                                append(part)
                            }
                        } else {
                            val italicParts = part.split(Regex("(?=\\*)|(?<=\\*)"))
                            var isItalic = false
                            for (iPart in italicParts) {
                                if (iPart == "*") {
                                    isItalic = !isItalic
                                } else {
                                    if (isItalic) {
                                        withStyle(style = SpanStyle(fontStyle = FontStyle.Italic, color = onSurface)) {
                                            append(iPart)
                                        }
                                    } else {
                                        append(iPart)
                                    }
                                }
                            }
                        }
                    }
                }
            }
            if (index < lines.size - 1) {
                append("\n")
            }
        }
    }
    Text(
        text = annotatedString, 
        style = MaterialTheme.typography.bodyMedium, 
        color = color, 
        modifier = modifier,
        onTextLayout = onTextLayout
    )
}
