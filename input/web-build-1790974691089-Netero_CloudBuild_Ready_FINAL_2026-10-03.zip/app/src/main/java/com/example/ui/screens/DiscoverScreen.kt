package com.example.ui.screens
import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.ArrowBack
import com.example.ui.components.MutualConnectionsDialog

import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import kotlinx.coroutines.launch
import kotlinx.coroutines.delay

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.FilterList
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.platform.LocalUriHandler
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ConnectionStatus
import com.example.data.model.PrivacyLevel
import com.example.data.model.RecommendedPerson
import com.example.data.model.UserProfile
import com.example.ui.theme.AccentBlue

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiscoverScreen(
    userProfile: UserProfile,
    recommendedPeople: List<RecommendedPerson>,
    searchQuery: String,
    selectedCategory: String,
    recentSearches: List<String> = emptyList(),
    onSearchQueryChange: (String) -> Unit,
    onCategorySelect: (String) -> Unit,
    onConnectPerson: (String, String) -> Unit = { _, _ -> },
    onFetchMutuals: (List<String>, (List<UserProfile>) -> Unit) -> Unit = {_,_->},
    onRefreshAiMatches: () -> Unit = {},
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {},
    onAskAiClick: (String?) -> Unit = {},
    onOpenFullProfile: (RecommendedPerson) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val categories = listOf("All")

    var showConnectDialogForPerson by remember { mutableStateOf<RecommendedPerson?>(null) }
    var connectionNote by remember { mutableStateOf("") }

    val currentUserId = userProfile.username.lowercase().trim()
    val currentUserName = userProfile.fullName.lowercase().trim()

    // 24-Hour Auto-Refresh for AI Matchmaking
    val context = LocalContext.current
    var isRefreshing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    LaunchedEffect(Unit) {
        val prefs = context.getSharedPreferences("netero_prefs", Context.MODE_PRIVATE)
        val lastRefresh = prefs.getLong("last_ai_matchmaking_refresh", 0L)
        val now = System.currentTimeMillis()
        if (now - lastRefresh > 24 * 60 * 60 * 1000L) {
            prefs.edit().putLong("last_ai_matchmaking_refresh", now).apply()
            onRefreshAiMatches()
        }
    }

    val filteredList = recommendedPeople.filter { person ->
        // Reject blank, dot, or incomplete profiles without a valid name or title
        if (person.name.isBlank() || person.name.trim() == "." || !person.name.any { it.isLetter() } || person.name.trim().length < 2 || (person.jobTitle.isBlank() && person.company.isBlank()) || (person.jobTitle == "." && person.company == ".")) {
            return@filter false
        }

        // Exclude the current logged-in user who downloaded the app
        val isSelf = (person.name.isNotBlank() && person.name.trim().equals(currentUserName, ignoreCase = true)) ||
                     (person.id.isNotBlank() && (person.id.trim().equals(currentUserId, ignoreCase = true) || person.id.trim().equals(userProfile.phone.trim(), ignoreCase = true)))
        if (isSelf) return@filter false

        val matchesCategory = (selectedCategory == "All") || person.category.equals(selectedCategory, ignoreCase = true) || person.industry.contains(selectedCategory, ignoreCase = true)
        val matchesSearch = searchQuery.isBlank() ||
                person.name.contains(searchQuery, ignoreCase = true) ||
                person.company.contains(searchQuery, ignoreCase = true) ||
                person.jobTitle.contains(searchQuery, ignoreCase = true) ||
                person.industry.contains(searchQuery, ignoreCase = true) ||
                person.location.contains(searchQuery, ignoreCase = true) ||
                person.sharedInterests.any { it.contains(searchQuery, ignoreCase = true) }
        matchesCategory && matchesSearch
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = "Discover People",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "Professional connections & suggestions",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {},
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        PullToRefreshBox(
            isRefreshing = isRefreshing,
            onRefresh = {
                isRefreshing = true
                scope.launch {
                    onRefreshAiMatches()
                    delay(700)
                    isRefreshing = false
                }
            },
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
            // Privacy Banner
            if (userProfile.neteroLock.phoneVisibility != PrivacyLevel.PUBLIC) {
                val bannerText = if (userProfile.neteroLock.phoneVisibility == PrivacyLevel.PRIVATE) {
                    "🔒 Your phone number is completely private. Hidden from public discovery and QR scans."
                } else {
                    "Your phone number is hidden from public discovery. Only connections (QR scans) can see it."
                }
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant)
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(imageVector = Icons.Default.Lock, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Text(
                        text = bannerText,
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            
            // Search Input Field
            OutlinedTextField(
                value = searchQuery,
                onValueChange = onSearchQueryChange,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("discover_search_input"),
                placeholder = { Text("Search by name, company, role, or skills...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = "Search", tint = MaterialTheme.colorScheme.primary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { onSearchQueryChange("") }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = MaterialTheme.colorScheme.surface,
                    unfocusedContainerColor = MaterialTheme.colorScheme.surface,
                    focusedBorderColor = AccentBlue,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                    focusedTextColor = MaterialTheme.colorScheme.onSurface,
                    unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                ),
                shape = RoundedCornerShape(14.dp)
            )

            // AI Matchmaking Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clip(RoundedCornerShape(12.dp))
                    .background(
                        brush = androidx.compose.ui.graphics.Brush.horizontalGradient(
                            colors = listOf(
                                Color(0xFFE3F2FD),
                                Color(0xFFF3E5F5)
                            )
                        )
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "AI Matchmaker",
                            tint = Color(0xFF6200EA),
                            modifier = Modifier.size(24.dp)
                        )
                        Column {
                            Text(
                                text = "✨ AI Matchmaking",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                color = Color(0xFF4A148C)
                            )
                            Text(
                                text = "Personalized connections curated for your background",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFF6A1B9A)
                            )
                        }
                    }

                }
            }

            // Professionals List
            if (filteredList.isEmpty()) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 36.dp, horizontal = 24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Text(
                        text = if (searchQuery.isNotBlank()) "No direct matches found for '$searchQuery'" else "No other professionals in this category yet",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                    if (searchQuery.isNotBlank()) {
                        OutlinedButton(
                            onClick = { onSearchQueryChange("") }
                        ) {
                            Text("Clear Search Filter")
                        }
                    }
                }
            } else {
                LazyColumn(
                    verticalArrangement = Arrangement.spacedBy(14.dp),
                    contentPadding = PaddingValues(bottom = 24.dp)
                ) {
                    items(filteredList, key = { it.id }) { person ->
                        RecommendedPersonCard(
                            person = person,
                            onConnectClick = {
                                if (person.status == ConnectionStatus.NOT_CONNECTED) {
                                    showConnectDialogForPerson = person
                                    connectionNote = "Hi ${person.name.split(" ").firstOrNull() ?: person.name}! I noticed your work in ${person.industry} on NETERO and would love to connect."
                                }
                            },
                            onFetchMutuals = onFetchMutuals,
                            isPro = isPro,
                            onNavigateToPaywall = onNavigateToPaywall,
                            onOpenFullProfile = onOpenFullProfile
                        )
                    }
                }
            }
        }

        // Connection Note Dialog
        showConnectDialogForPerson?.let { person ->
            AlertDialog(
                onDismissRequest = { showConnectDialogForPerson = null },
                containerColor = MaterialTheme.colorScheme.surface,
                title = {
                    Text(
                        text = "Connect with ${person.name}",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(
                            text = "Add a personalized note to your NETERO connection request.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        OutlinedTextField(
                            value = connectionNote,
                            onValueChange = { connectionNote = it },
                            modifier = Modifier.fillMaxWidth(),
                            maxLines = 3,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = AccentBlue,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                                unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                            )
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            onConnectPerson(person.id, connectionNote)
                            showConnectDialogForPerson = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        Text("Send Request", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showConnectDialogForPerson = null }) {
                        Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            )
        }
        }

    }
    
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun RecommendedPersonCard(
    person: RecommendedPerson,
    onConnectClick: () -> Unit,
    onFetchMutuals: (List<String>, (List<UserProfile>) -> Unit) -> Unit,
    isPro: Boolean,
    onNavigateToPaywall: () -> Unit,
    onOpenFullProfile: (RecommendedPerson) -> Unit = {}
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current
    val scope = androidx.compose.runtime.rememberCoroutineScope()
    var mutualProfiles by remember { mutableStateOf<List<UserProfile>>(emptyList()) }
    var showMutualConnections by remember { mutableStateOf(false) }
    var isGeneratingResearch by remember { mutableStateOf(false) }
    var generatedResearch by remember { mutableStateOf<String?>(null) }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(20.dp))
            .clickable { onOpenFullProfile(person) },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Main Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top,
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(52.dp)
                        .clip(CircleShape)
                        .background(Color(person.avatarBgHex)),
                    contentAlignment = Alignment.Center
                ) {
                    if (person.profileImageUrl.isNotBlank()) {
                        coil.compose.AsyncImage(
                            model = com.example.utils.AttachmentHelper.getDisplayableImageModel(person.profileImageUrl),
                            contentDescription = "Profile Photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Text(
                            text = person.avatarInitial,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                }

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = person.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (person.isStudent || person.category == "Students") Icons.Default.School else Icons.Default.Work,
                            contentDescription = if (person.isStudent || person.category == "Students") "Student" else "Professional",
                            tint = if (person.isStudent || person.category == "Students") Color(0xFF6200EA) else MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = if (person.isStudent || person.category == "Students") "${person.jobTitle} @ ${person.company}" else "${person.jobTitle} • ${person.company}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        if (person.isStudent || person.category == "Students") {
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(4.dp))
                                    .background(Color(0xFF6200EA).copy(alpha = 0.12f))
                                    .padding(horizontal = 4.dp, vertical = 1.dp)
                            ) {
                                Text(
                                    text = "STUDENT",
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                                    color = Color(0xFF6200EA),
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.padding(top = 2.dp)
                    ) {
                        Icon(imageVector = Icons.Default.LocationOn, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                        Text(text = person.location, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = "•", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = person.industry, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    Text(
                        text = "Tap to view full profile & public links →",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }
            }

            // Clean Real-Time Industry & Mutual Relevance (No fake match percentage)
            if (person.matchReason.isNotBlank()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(10.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.People,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(
                            text = person.matchReason,
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            // Mutual Connections & Shared Interests
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (person.mutualConnectionsCount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(4.dp),
                        modifier = Modifier
                            .clip(RoundedCornerShape(4.dp))
                            .clickable { 
                                showMutualConnections = true
                                onFetchMutuals(person.connectionIds) { profiles ->
                                    mutualProfiles = profiles
                                }
                            }
                            .padding(4.dp)
                    ) {
                        Icon(imageVector = Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(14.dp))
                        Text(
                            text = "${person.mutualConnectionsCount} Mutual Connections",
                            style = MaterialTheme.typography.labelSmall.copy(textDecoration = TextDecoration.Underline),
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(4.dp))
                }

                FlowRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    person.sharedInterests.take(2).forEach { interest ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(6.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 6.dp, vertical = 2.dp)
                        ) {
                            Text(text = interest, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }

            // Actions
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // AI Insight Button
                Button(
                    onClick = {
                        if (!isPro) {
                            onNavigateToPaywall()
                        } else if (!isGeneratingResearch) {
                            isGeneratingResearch = true
                            scope.launch {
                                generatedResearch = com.example.data.api.GeminiAiHelper.researchProfile(
                                    name = person.name,
                                    role = person.jobTitle,
                                    company = person.company,
                                    context = "Recommended connection",
                                    linkedinUrl = person.linkedinUrl ?: "",
                                    portfolioUrl = person.portfolioUrl ?: "",
                                    websiteUrl = person.website ?: "",
                                    businessUrl = person.businessUrl ?: ""
                                )
                                isGeneratingResearch = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(42.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.tertiary),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(if (isGeneratingResearch) "Researching..." else "✨ Research ${person.name}", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                }
                
                if (generatedResearch != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = generatedResearch!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                if (!person.linkedinUrl.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = {
                            val raw = person.linkedinUrl.trim()
                            val url = when {
                                raw.startsWith("http://") || raw.startsWith("https://") -> raw
                                raw.contains("linkedin.com") -> "https://$raw"
                                else -> "https://www.linkedin.com/in/$raw"
                            }
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                try { uriHandler.openUri(url) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open LinkedIn: $url", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = Color(0xFF0077B5), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View LinkedIn Profile", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFF0077B5))
                    }
                }

                if (!person.portfolioUrl.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = {
                            val raw = person.portfolioUrl.trim()
                            val url = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                try { uriHandler.openUri(url) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open portfolio: $url", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Portfolio / Featured Work", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                    }
                }

                if (!person.website.isNullOrBlank() && person.website != person.portfolioUrl) {
                    OutlinedButton(
                        onClick = {
                            val raw = person.website.trim()
                            val url = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                try { uriHandler.openUri(url) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open website: $url", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.secondary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Visit Personal Website", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.secondary)
                    }
                }

                if (!person.businessUrl.isNullOrBlank()) {
                    OutlinedButton(
                        onClick = {
                            val raw = person.businessUrl.trim()
                            val url = if (raw.startsWith("http://") || raw.startsWith("https://")) raw else "https://$raw"
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(url)).apply {
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                try { uriHandler.openUri(url) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open business link: $url", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(42.dp),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(imageVector = Icons.Default.Work, contentDescription = null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("View Business / Store Link", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = Color(0xFF10B981))
                    }
                }

                // Connect Button
                Button(
                    onClick = onConnectClick,
                    enabled = (person.status == ConnectionStatus.NOT_CONNECTED),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(42.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when (person.status) {
                            ConnectionStatus.CONNECTED -> MaterialTheme.colorScheme.surfaceVariant
                            ConnectionStatus.PENDING -> MaterialTheme.colorScheme.surfaceVariant
                            ConnectionStatus.NOT_CONNECTED -> AccentBlue
                        }
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    when (person.status) {
                        ConnectionStatus.CONNECTED -> {
                            Icon(imageVector = Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Connected", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onBackground, maxLines = 1, softWrap = false)
                        }
                        ConnectionStatus.PENDING -> {
                            Text("Request Sent", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                        }
                        ConnectionStatus.NOT_CONNECTED -> {
                            Icon(imageVector = Icons.Default.PersonAdd, contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Connect", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold), color = Color.White, maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }
    
    if (showMutualConnections) {
        MutualConnectionsDialog(mutualProfiles = mutualProfiles, onDismissRequest = { showMutualConnections = false })
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun DiscoverProfileScreen(
    person: RecommendedPerson,
    onBack: () -> Unit,
    onConnect: () -> Unit
) {
    val context = LocalContext.current
    val uriHandler = LocalUriHandler.current

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Profile", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.Default.ArrowBack,
                            contentDescription = "Back"
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(androidx.compose.foundation.rememberScrollState())
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalArrangement = Arrangement.spacedBy(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(84.dp)
                        .clip(CircleShape)
                        .background(Color(person.avatarBgHex)),
                    contentAlignment = Alignment.Center
                ) {
                    if (person.profileImageUrl.isNotBlank()) {
                        coil.compose.AsyncImage(
                            model = com.example.utils.AttachmentHelper.getDisplayableImageModel(person.profileImageUrl),
                            contentDescription = "Profile Photo",
                            modifier = Modifier.fillMaxSize(),
                            contentScale = androidx.compose.ui.layout.ContentScale.Crop
                        )
                    } else {
                        Text(
                            text = person.avatarInitial,
                            style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                            color = Color.White
                        )
                    }
                }
                Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(
                        text = person.name,
                        style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (person.isStudent || person.category == "Students") "${person.jobTitle} @ ${person.company}" else "${person.jobTitle} • ${person.company}",
                        style = MaterialTheme.typography.bodyLarge,
                        color = MaterialTheme.colorScheme.primary,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = listOf(person.industry, person.location).filter { it.isNotBlank() }.joinToString(" • "),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            if (person.bio.isNotBlank()) {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("About", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    Text(person.bio, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }

            if (person.sharedInterests.isNotEmpty()) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Interests", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        person.sharedInterests.forEach { interest ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(20.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .padding(horizontal = 12.dp, vertical = 7.dp)
                            ) { Text(interest, style = MaterialTheme.typography.labelMedium) }
                        }
                    }
                }
            }

            val hasContact = person.isContactInfoPublic || !person.phone.isNullOrBlank() || !person.email.isNullOrBlank() || !person.linkedinUrl.isNullOrBlank() || !person.portfolioUrl.isNullOrBlank() || !person.website.isNullOrBlank()
            if (hasContact) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Public Contact & Links", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                        person.email?.takeIf { it.isNotBlank() }?.let { email ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { try { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email"))) } catch (_: Exception) {} }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Email, contentDescription = "Email", tint = MaterialTheme.colorScheme.primary)
                                Text(email, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        person.phone?.takeIf { it.isNotBlank() }?.let { phone ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { try { context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$phone"))) } catch (_: Exception) {} }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Phone, contentDescription = "Phone", tint = MaterialTheme.colorScheme.primary)
                                Text(phone, style = MaterialTheme.typography.bodyMedium)
                            }
                        }
                        person.linkedinUrl?.takeIf { it.isNotBlank() }?.let { li ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { try { uriHandler.openUri(if (li.startsWith("http")) li else "https://www.linkedin.com/in/$li") } catch (_: Exception) {} }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Share, contentDescription = "LinkedIn", tint = Color(0xFF0077B5))
                                Text("LinkedIn Profile", color = Color(0xFF0077B5), fontWeight = FontWeight.Bold)
                            }
                        }
                        person.portfolioUrl?.takeIf { it.isNotBlank() }?.let { port ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { try { uriHandler.openUri(if (port.startsWith("http")) port else "https://$port") } catch (_: Exception) {} }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Link, contentDescription = "Portfolio", tint = MaterialTheme.colorScheme.primary)
                                Text("Portfolio / Featured Work", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                            }
                        }
                        person.website?.takeIf { it.isNotBlank() && it != person.portfolioUrl }?.let { web ->
                            Row(modifier = Modifier.fillMaxWidth().clickable { try { uriHandler.openUri(if (web.startsWith("http")) web else "https://$web") } catch (_: Exception) {} }, verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                Icon(Icons.Default.Link, contentDescription = "Website", tint = MaterialTheme.colorScheme.secondary)
                                Text("Personal Website", color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            Button(
                onClick = onConnect,
                modifier = Modifier.fillMaxWidth().height(52.dp),
                enabled = person.status == ConnectionStatus.NOT_CONNECTED,
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = when (person.status) {
                        ConnectionStatus.CONNECTED -> "Already Connected"
                        ConnectionStatus.PENDING -> "Request Pending"
                        ConnectionStatus.NOT_CONNECTED -> "Connect with ${person.name}"
                    },
                    fontWeight = FontWeight.Bold
                )
            }
            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

