package com.example.ui.screens

import com.example.data.model.ConnectionStatus
import androidx.compose.material.icons.filled.Check
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.AlertDialog

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.LocationOn
import kotlinx.coroutines.launch
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.*
import com.example.ui.components.MutualConnectionsDialog
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RecommendedPerson

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RecommendedConnectionsScreen(
    recommendedPeople: List<RecommendedPerson>,
    onConnectPerson: (String, String) -> Unit = { _, _ -> },
    onNavigateBack: () -> Unit,
    onFetchMutuals: (List<String>, (List<com.example.data.model.UserProfile>) -> Unit) -> Unit = {_,_->},
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {}
) {
    val validRecommendedPeople = remember(recommendedPeople) {
        recommendedPeople.filter { p ->
            p.name.isNotBlank() && p.name.trim() != "." && p.name.length >= 2 && p.name.any { it.isLetter() } &&
            (p.jobTitle.isNotBlank() || p.company.isNotBlank()) && (p.jobTitle != "." && p.company != ".")
        }
    }
    var selectedPerson by remember { mutableStateOf<RecommendedPerson?>(null) }
    var showConnectDialogForPerson by remember { mutableStateOf<RecommendedPerson?>(null) }
    var connectionNote by remember { mutableStateOf("") }
    
    val scope = rememberCoroutineScope()
    var generatedResearch by remember { mutableStateOf<String?>(null) }
    var isGeneratingResearch by remember { mutableStateOf(false) }
    var showMutualConnections by remember { mutableStateOf(false) }
    var mutualProfiles by remember { mutableStateOf<List<com.example.data.model.UserProfile>>(emptyList()) }

    // Reset research when selection changes
    LaunchedEffect(selectedPerson) {
        generatedResearch = null
        isGeneratingResearch = false
    }
    
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("People You May Know") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { padding ->
        if (validRecommendedPeople.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(padding), contentAlignment = Alignment.Center) {
                Text("No recommendations at this time.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(validRecommendedPeople) { person ->
                    Card(
                        modifier = Modifier.fillMaxWidth().clickable { selectedPerson = person },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Box(modifier = Modifier.size(48.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                                Text(person.name.firstOrNull()?.toString() ?: "P", color = Color.White, fontWeight = FontWeight.Bold)
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(person.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onSurface)
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    Icon(
                                        imageVector = if (person.isStudent || person.category == "Students") Icons.Default.School else Icons.Default.Work,
                                        contentDescription = if (person.isStudent || person.category == "Students") "Student" else "Professional",
                                        tint = if (person.isStudent || person.category == "Students") Color(0xFF6200EA) else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(13.dp)
                                    )
                                    Text(
                                        text = if (person.isStudent || person.category == "Students") "${person.jobTitle} @ ${person.company}" else "${person.jobTitle} • ${person.company}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.weight(1f, fill = false),
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    if (person.isStudent || person.category == "Students") {
                                        Box(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(4.dp))
                                                .background(Color(0xFF6200EA).copy(alpha = 0.12f))
                                                .padding(horizontal = 4.dp, vertical = 1.dp)
                                        ) {
                                            Text(
                                                text = "STUDENT",
                                                style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                                                color = Color(0xFF6200EA),
                                                maxLines = 1,
                                                softWrap = false
                                            )
                                        }
                                    }
                                }
                                if (person.mutualConnectionsCount > 0) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(
                                            Icons.Default.People,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(13.dp)
                                        )
                                        Text(
                                            text = "${person.mutualConnectionsCount} mutual connections",
                                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold),
                                            color = MaterialTheme.colorScheme.primary
                                        )
                                    }
                                }
                                if (person.matchReason.isNotBlank()) {
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = person.matchReason,
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.secondary
                                    )
                                }
                            }
                            if (person.status == ConnectionStatus.PENDING) {
                                Surface(
                                    color = MaterialTheme.colorScheme.surfaceVariant,
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                                    ) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.primary)
                                        Text("Pending", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                            } else {
                                IconButton(
                                    onClick = {
                                        showConnectDialogForPerson = person
                                        connectionNote = "Hi ${person.name.split(" ").firstOrNull() ?: person.name}! I noticed your work at ${person.company} on NETERO and would love to connect."
                                    },
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Icon(
                                        Icons.Default.PersonAdd,
                                        contentDescription = "Connect",
                                        tint = MaterialTheme.colorScheme.primary
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    
    // Bottom Sheet for Profile Details
    if (selectedPerson != null) {
        ModalBottomSheet(
            onDismissRequest = { selectedPerson = null }
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 16.dp).padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // Profile Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(modifier = Modifier.size(64.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
                        if (selectedPerson!!.profileImageUrl.isNotBlank()) {
                            coil.compose.AsyncImage(
                                model = com.example.utils.AttachmentHelper.getDisplayableImageModel(selectedPerson!!.profileImageUrl),
                                contentDescription = "Profile Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Text(selectedPerson!!.name.first().toString(), color = Color.White, style = MaterialTheme.typography.titleLarge)
                        }
                    }
                    Column {
                        Text(selectedPerson!!.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Icon(
                                imageVector = if (selectedPerson!!.isStudent || selectedPerson!!.category == "Students") Icons.Default.School else Icons.Default.Work,
                                contentDescription = if (selectedPerson!!.isStudent || selectedPerson!!.category == "Students") "Student" else "Professional",
                                tint = if (selectedPerson!!.isStudent || selectedPerson!!.category == "Students") Color(0xFF6200EA) else MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = if (selectedPerson!!.isStudent || selectedPerson!!.category == "Students") "${selectedPerson!!.jobTitle} @ ${selectedPerson!!.company}" else "${selectedPerson!!.jobTitle} • ${selectedPerson!!.company}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.weight(1f, fill = false),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            if (selectedPerson!!.isStudent || selectedPerson!!.category == "Students") {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF6200EA).copy(alpha = 0.12f))
                                        .padding(horizontal = 4.dp, vertical = 1.dp)
                                ) {
                                    Text(
                                        text = "STUDENT",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold),
                                        color = Color(0xFF6200EA),
                                        maxLines = 1,
                                        softWrap = false
                                    )
                                }
                            }
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp), modifier = Modifier.padding(top = 4.dp)) {
                            Icon(Icons.Default.LocationOn, contentDescription = null, modifier = Modifier.size(14.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text("${selectedPerson!!.location} • ${selectedPerson!!.company}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
                
                // Relevance Section
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    Text(selectedPerson!!.matchReason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                
                // Mutuals & Tags
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (selectedPerson!!.mutualConnectionsCount > 0) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically, 
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(4.dp))
                                .clickable { 
                                    showMutualConnections = true
                                    onFetchMutuals(selectedPerson!!.connectionIds) { profiles ->
                                        mutualProfiles = profiles
                                    }
                                }
                                .padding(4.dp)
                        ) {
                            Icon(Icons.Default.People, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(16.dp))
                            Text("${selectedPerson!!.mutualConnectionsCount} Mutual Connections", style = MaterialTheme.typography.bodySmall.copy(textDecoration = TextDecoration.Underline), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                    selectedPerson!!.sharedInterests.take(2).forEach { interest ->
                        Text(interest, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }

                // AI Insight Button
                Button(
                    onClick = {
                        if (!isGeneratingResearch) {
                            isGeneratingResearch = true
                            scope.launch {
                                generatedResearch = com.example.data.api.GeminiAiHelper.researchProfile(
                                    name = selectedPerson!!.name,
                                    role = selectedPerson!!.jobTitle,
                                    company = selectedPerson!!.company,
                                    context = "Recommended connection",
                                    industry = selectedPerson!!.industry,
                                    bio = selectedPerson!!.bio,
                                    skills = selectedPerson!!.sharedInterests
                                )
                                isGeneratingResearch = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f), contentColor = MaterialTheme.colorScheme.tertiary),
                    shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)
                ) {
                    Text(if (isGeneratingResearch) "Researching..." else "✨ Research ${selectedPerson!!.name}")
                }

                if (generatedResearch != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(androidx.compose.foundation.shape.RoundedCornerShape(8.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = generatedResearch!!,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
                
                // Link Button
                val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
                if (!selectedPerson!!.portfolioUrl.isNullOrBlank()) {
                    val rawUrl = selectedPerson!!.portfolioUrl!!.trim()
                    val context = androidx.compose.ui.platform.LocalContext.current
                    TextButton(
                        onClick = {
                            val finalUrl = if (!rawUrl.startsWith("http://") && !rawUrl.startsWith("https://")) "https://$rawUrl" else rawUrl
                            try {
                                val intent = android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse(finalUrl)).apply {
                                    addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
                                }
                                context.startActivity(intent)
                            } catch (_: Exception) {
                                try { uriHandler.openUri(finalUrl) } catch (_: Exception) {
                                    android.widget.Toast.makeText(context, "Could not open portfolio: $finalUrl", android.widget.Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("View Featured Work", fontWeight = FontWeight.SemiBold)
                    }
                }
                
                // Action Button
                Button(
                    onClick = { 
                        if (selectedPerson!!.status == ConnectionStatus.NOT_CONNECTED) {
                            showConnectDialogForPerson = selectedPerson
                        } else {
                            onConnectPerson(selectedPerson!!.id, "")
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = when (selectedPerson!!.status) {
                            ConnectionStatus.CONNECTED -> MaterialTheme.colorScheme.surfaceVariant
                            ConnectionStatus.PENDING -> MaterialTheme.colorScheme.surfaceVariant
                            ConnectionStatus.NOT_CONNECTED -> MaterialTheme.colorScheme.primary
                        }
                    )
                ) {
                    when (selectedPerson!!.status) {
                        ConnectionStatus.CONNECTED -> {
                            Icon(Icons.Default.Check, contentDescription = null, tint = MaterialTheme.colorScheme.onBackground, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Connected", color = MaterialTheme.colorScheme.onBackground, maxLines = 1, softWrap = false)
                        }
                        ConnectionStatus.PENDING -> {
                            Text("Request Sent", color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, softWrap = false)
                        }
                        ConnectionStatus.NOT_CONNECTED -> {
                            Icon(Icons.Default.PersonAdd, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Connect", maxLines = 1, softWrap = false)
                        }
                    }
                }
            }
        }
    }

    // Connection Note Dialog
    showConnectDialogForPerson?.let { person ->
        AlertDialog(
            onDismissRequest = { showConnectDialogForPerson = null },
            containerColor = MaterialTheme.colorScheme.surface,
            title = {
                Text(
                    text = "Connect with ${person.name}",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Add a personalized note to your NETERO connection request.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = connectionNote,
                        onValueChange = { connectionNote = it },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = MaterialTheme.colorScheme.primary,
                            unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                            focusedTextColor = MaterialTheme.colorScheme.onSurface,
                            unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                        )
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onConnectPerson(person.id, connectionNote)
                        showConnectDialogForPerson = null
                    }
                ) {
                    Text("Send Request", color = MaterialTheme.colorScheme.onBackground, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(onClick = { showConnectDialogForPerson = null }) {
                    Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        )
    }
    if (showMutualConnections) {
        MutualConnectionsDialog(mutualProfiles = mutualProfiles, onDismissRequest = { showMutualConnections = false })
    }
}
