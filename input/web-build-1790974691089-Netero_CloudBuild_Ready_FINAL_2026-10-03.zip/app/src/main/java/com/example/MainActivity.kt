@file:OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
package com.example

import kotlin.OptIn

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import com.example.ui.navigation.NeteroNavGraph
import com.example.ui.theme.NeteroTheme
import com.example.ui.viewmodel.NeteroViewModel
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.result.IntentSenderRequest
import androidx.lifecycle.lifecycleScope
import kotlinx.coroutines.launch
import com.example.utils.InAppUpdateHelper

@OptIn(com.google.accompanist.permissions.ExperimentalPermissionsApi::class)
class MainActivity : ComponentActivity() {
    @android.annotation.SuppressLint("MissingPermission")
    private fun fetchLocationAndSave(name: String, title: String, org: String, source: String, notes: String) {
        lifecycleScope.launch {
            val locationString = com.example.utils.LocationHelper.getDeviceLocationString(this@MainActivity)
            viewModel.handleScanContact(name, title, org, source, notes, locationMet = locationString)
        }
    }

    private val viewModel: NeteroViewModel by viewModels()

    private val updateLauncher = registerForActivityResult(
        ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode != RESULT_OK) {
            android.util.Log.w("InAppUpdate", "Update flow failed or was cancelled by user: ${result.resultCode}")
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            com.google.firebase.FirebaseApp.initializeApp(this)
            if (!com.example.BuildConfig.DEBUG) {
                try {
                    val firebaseAppCheck = com.google.firebase.appcheck.FirebaseAppCheck.getInstance()
                    firebaseAppCheck.installAppCheckProviderFactory(
                        com.google.firebase.appcheck.playintegrity.PlayIntegrityAppCheckProviderFactory.getInstance()
                    )
                    android.util.Log.d("FirebaseAppCheck", "AppCheck configured successfully")
                } catch (e: Exception) {
                    android.util.Log.w("FirebaseAppCheck", "Play Integrity not available: ${e.message}")
                }
            }
        } catch (e: Exception) {
            android.util.Log.w("FirebaseInit", "Firebase init notice: ${e.message}")
        }

        com.example.utils.NotificationHelper.createNotificationChannels(this)
        android.util.Log.d("NeteroApp", "App initialized cleanly. Ready for demo.")

        // Check if device is emulator, test container, or running without Google Play Services
        val isEmulator = android.os.Build.FINGERPRINT.startsWith("generic")
                || android.os.Build.FINGERPRINT.startsWith("unknown")
                || android.os.Build.MODEL.contains("google_sdk")
                || android.os.Build.MODEL.contains("Emulator")
                || android.os.Build.MODEL.contains("Android SDK built for x86")
                || android.os.Build.MANUFACTURER.contains("Genymotion")
                || (android.os.Build.BRAND.startsWith("generic") && android.os.Build.DEVICE.startsWith("generic"))
                || android.os.Build.HARDWARE.contains("goldfish")
                || android.os.Build.HARDWARE.contains("ranchu")
                || android.os.Build.HARDWARE.contains("vsoc")
                || android.os.Build.HARDWARE.contains("cutf")
                || android.os.Build.PRODUCT.contains("sdk")
                || android.os.Build.PRODUCT.contains("cuttlefish")
                || android.os.Build.PRODUCT.contains("cf_")
                || android.os.Build.DEVICE.contains("vsoc")
                || android.os.Build.DEVICE.contains("cutf")

        // Google Play Billing is only available on real hardware with Google Play Store installed and signed in
        val hasPlayStore = try {
            packageManager.getPackageInfo("com.android.vending", 0) != null
        } catch (e: Exception) {
            false
        }

        if (!isEmulator && hasPlayStore) {
            try {
                if (!com.revenuecat.purchases.Purchases.isConfigured) {
                    com.revenuecat.purchases.Purchases.logLevel = com.revenuecat.purchases.LogLevel.ERROR
                    com.revenuecat.purchases.Purchases.configure(
                        com.revenuecat.purchases.PurchasesConfiguration.Builder(this, "goog_MpYDQlMKEdNPYiDproxrmrSpNLz").build()
                    )
                }
            } catch (e: Exception) {
                android.util.Log.w("NeteroApp", "Purchases configure notice: ${e.message}")
            }

            // Purchases configured
        } else {
            android.util.Log.i("NeteroApp", "Netero initialized in emulator / preview environment.")
        }
        // Check for in-app updates from Google Play Console (Flexible/Immediate notification like Zomato)
        InAppUpdateHelper.checkForAppUpdate(
            activity = this,
            updateLauncher = updateLauncher,
            onUpdateDownloaded = {
                runOnUiThread {
                    android.widget.Toast.makeText(
                        this,
                        "An update has been downloaded. Restarting app...",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                    InAppUpdateHelper.completeUpdate()
                }
            }
        )

        enableEdgeToEdge()
        setContent {
            val isDarkTheme by viewModel.isDarkTheme.collectAsState()
            
            val prefs = getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
            val neteroPrefs = getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)

            val profileName = neteroPrefs.getString("profile_name", "")?.trim()
                ?.ifBlank { prefs.getString("profile_name", "")?.trim() } ?: ""
            val profileUsername = neteroPrefs.getString("profile_username", "")?.trim()
                ?.ifBlank { prefs.getString("profile_username", "")?.trim() } ?: ""

            val hasValidProfile = profileName.isNotBlank() || profileUsername.isNotBlank()
            val loginFlag = prefs.getBoolean("is_logged_in", false) || neteroPrefs.getBoolean("is_logged_in", false)
            val isLoggedIn = hasValidProfile && loginFlag

            if (isLoggedIn) {
                prefs.edit().putBoolean("is_logged_in", true).apply()
                neteroPrefs.edit().putBoolean("is_logged_in", true).apply()
            } else {
                prefs.edit().putBoolean("is_logged_in", false).apply()
                neteroPrefs.edit().putBoolean("is_logged_in", false).apply()
            }
            val startDest = if (isLoggedIn) com.example.ui.navigation.Screen.Home.route else com.example.ui.navigation.Screen.Welcome.route
            
            val requiredPermissions = remember {
                val list = mutableListOf(
                    android.Manifest.permission.ACCESS_FINE_LOCATION,
                    android.Manifest.permission.ACCESS_COARSE_LOCATION
                )
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
                    list.add(android.Manifest.permission.POST_NOTIFICATIONS)
                }
                list
            }
            val appPermissionsState = com.google.accompanist.permissions.rememberMultiplePermissionsState(
                permissions = requiredPermissions
            )
            androidx.compose.runtime.LaunchedEffect(Unit) {
                if (!appPermissionsState.allPermissionsGranted) {
                    appPermissionsState.launchMultiplePermissionRequest()
                }
                if (isLoggedIn) {
                    viewModel.refreshCloudData()
                }
            }

            NeteroTheme(darkTheme = isDarkTheme) {
                NeteroNavGraph(viewModel = viewModel, startDestination = startDest)
            }
        }
    }
    override fun onResume() {
        super.onResume()
        InAppUpdateHelper.resumeUpdateIfDownloaded(this) {
            android.widget.Toast.makeText(
                this,
                "An update has been downloaded. Restarting app...",
                android.widget.Toast.LENGTH_LONG
            ).show()
            InAppUpdateHelper.completeUpdate()
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        InAppUpdateHelper.onDestroy()
    }
}
