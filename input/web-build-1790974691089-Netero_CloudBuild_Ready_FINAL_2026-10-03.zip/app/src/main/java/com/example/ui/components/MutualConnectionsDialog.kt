package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

data class MutualPerson(
    val name: String,
    val jobTitle: String,
    val avatarInitial: String,
    val avatarBgHex: Long,
    val roomInfo: String? = null
)

val fakeMutuals = emptyList<MutualPerson>() // Replaced with actual empty list to prevent ghost data

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MutualConnectionsDialog(
    mutualProfiles: List<com.example.data.model.UserProfile>,
    currentUserId: String = "",
    onDismissRequest: () -> Unit
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val cleanProfiles = remember(mutualProfiles, currentUserId) {
        val prefs = context.getSharedPreferences("netero_prefs", android.content.Context.MODE_PRIVATE)
        val myId = currentUserId.ifBlank { prefs.getString("current_user_id", "") ?: "" }
        val myEmail = prefs.getString("user_email", "") ?: ""
        val myName = prefs.getString("user_name", "") ?: ""

        mutualProfiles.filter { person ->
            person.fullName.isNotBlank() &&
            person.fullName.trim() != "." &&
            person.fullName.trim() != ".." &&
            (myId.isBlank() || person.id != myId) &&
            (myEmail.isBlank() || !person.email.equals(myEmail, ignoreCase = true)) &&
            (myName.isBlank() || !person.fullName.equals(myName, ignoreCase = true))
        }.distinctBy {
            if (it.id.isNotBlank()) it.id
            else if (it.email.isNotBlank()) it.email.trim().lowercase()
            else if (it.username.isNotBlank()) it.username.trim().lowercase()
            else it.fullName.trim().lowercase()
        }
    }

    AlertDialog(
        onDismissRequest = onDismissRequest,
        title = { Text("Mutual Connections") },
        text = {
            if (cleanProfiles.isEmpty()) {
                Text("No mutual connections found yet.", style = MaterialTheme.typography.bodyMedium)
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(cleanProfiles) { person ->
                        Row(
                            modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            val avatarColor = try {
                                Color(android.graphics.Color.parseColor(person.themeColorHex.ifBlank { "#6200EA" }))
                            } catch (e: Exception) {
                                Color(0xFF6200EA)
                            }
                            Box(
                                modifier = Modifier.size(40.dp).clip(CircleShape).background(avatarColor),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(text = if (person.fullName.isNotBlank()) person.fullName.first().uppercase() else "?", style = MaterialTheme.typography.titleMedium, color = Color.White)
                            }
                            Column {
                                Text(text = person.fullName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                                Text(text = person.jobTitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismissRequest) {
                Text("Close")
            }
        }
    )
}
