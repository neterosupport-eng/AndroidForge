package com.example.data.api

import android.util.Log
import android.content.ContentResolver
import android.net.Uri
import com.example.data.model.ConnectionContact
import com.example.data.model.PrivacyLevel
import com.example.data.model.UserProfile
import com.example.data.model.NeteroLockSettings
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await

class CloudSyncManager {

    private fun getStorageReference(): com.google.firebase.storage.StorageReference {
        return try {
            com.google.firebase.storage.FirebaseStorage.getInstance("gs://netero-network.firebasestorage.app").reference
        } catch (_: Exception) {
            com.google.firebase.storage.FirebaseStorage.getInstance().reference
        }
    }

    suspend fun uploadProfileImage(userId: String, contentResolver: ContentResolver, uri: Uri): String? {
        if (userId.isBlank()) return null
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            input.use { stream ->
                val storageRef = getStorageReference()
                val imageRef = storageRef.child("profiles/$userId/profile_picture.jpg")
                val metadata = com.google.firebase.storage.StorageMetadata.Builder()
                    .setContentType(contentResolver.getType(uri)?.takeIf { it.startsWith("image/") } ?: "image/jpeg")
                    .build()
                imageRef.putStream(stream, metadata).await()
                imageRef.downloadUrl.await().toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload profile image to Firebase Storage", e)
            null
        }
    }

    suspend fun deleteProfileImage(userId: String): Boolean {
        if (userId.isBlank()) return false
        return try {
            getStorageReference().child("profiles/$userId/profile_picture.jpg").delete().await()
            true
        } catch (e: Exception) {
            val message = e.message.orEmpty()
            if (message.contains("object-not-found", ignoreCase = true) || message.contains("not found", ignoreCase = true)) true else {
                Log.e(TAG, "Failed to delete profile image", e)
                false
            }
        }
    }


    
    fun submitSupportTicket(userId: String, email: String, subject: String, message: String) {
        if (firestore == null) return
        val ticket = hashMapOf(
            "userId" to userId,
            "email" to email,
            "subject" to subject,
            "message" to message,
            "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp(),
            "status" to "Ticket Raised"
        )
        firestore!!.collection("support_tickets").add(ticket)
            .addOnSuccessListener { Log.d(TAG, "Ticket submitted successfully") }
            .addOnFailureListener { Log.e(TAG, "Failed to submit ticket", it) }
    }

    private val TAG = "CloudSyncManager"

    val firestore: FirebaseFirestore? by lazy {
        try {
            FirebaseFirestore.getInstance()
        } catch (e: IllegalStateException) {
            Log.w(TAG, "Firebase is not initialized (no valid google-services.json). Cloud sync will run in local simulation mode.")
            null
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing Firestore: ${e.message}")
            null
        }
    }

    /**
     * Uploads the user's latest Netero profile to Firestore.
     * When any connected user is listening to this profile, they will receive the update in real time.
     */
    fun sendWelcomeEmail(toEmail: String, userName: String) {
        val db = firestore ?: return
        val mailData = hashMapOf(
            "to" to toEmail,
            "message" to hashMapOf(
                "subject" to "Welcome to Netero, $userName!",
                "html" to "<h3>Welcome to Netero!</h3><p>Hi $userName,</p><p>You have successfully joined Netero. We are thrilled to have you onboard.</p><p>Start building your professional network today!</p><br/><p>Best,<br/>The Netero Team</p>"
            ),
            "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        db.collection("mail").add(mailData)
            .addOnSuccessListener { Log.d(TAG, "Welcome email queued for delivery via Firebase Extension") }
            .addOnFailureListener { Log.e(TAG, "Failed to queue welcome email", it) }
    }

    suspend fun syncProfileToCloud(userId: String, profile: UserProfile, oldUsername: String? = null): Boolean {
        val db = firestore ?: return false
        val authUid = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid } catch (_: Exception) { null }
        val cleanUserId = userId.ifBlank { authUid ?: profile.username.ifBlank { "user_default" } }
        return try {
            val profileMap = hashMapOf(
                "id" to cleanUserId,
                "authUid" to (authUid ?: cleanUserId),
                "fullName" to profile.fullName,
                "profileImageUrl" to profile.profileImageUrl,
                "username" to profile.username,
                "headline" to profile.headline,
                "jobTitle" to profile.jobTitle,
                "company" to profile.company,
                "industry" to profile.industry,
                "bio" to profile.bio,
                "location" to profile.location,
                "website" to profile.website,
                "email" to profile.email,
                "phone" to profile.phone,
                "linkedinUrl" to profile.linkedinUrl,
                "businessUrl" to profile.businessUrl,
                "portfolioUrl" to profile.portfolioUrl,
                "skills" to profile.skills,
                "interests" to profile.interests,
                "networkingGoals" to profile.networkingGoals,
                "themeColorHex" to profile.themeColorHex,
                "phoneVisibility" to profile.neteroLock.phoneVisibility.name,
                "emailVisibility" to profile.neteroLock.emailVisibility.name,
                "socialVisibility" to profile.neteroLock.socialVisibility.name,
                "profileDiscovery" to profile.neteroLock.profileDiscovery.name,
                "portfolioVisibility" to profile.neteroLock.portfolioVisibility.name,
                "roomVisibility" to profile.neteroLock.roomVisibility,
                "connectionIds" to profile.connectionIds,
                "isStudent" to profile.isStudent,
                "dateOfBirth" to profile.dateOfBirth,
                "lastUpdated" to System.currentTimeMillis()
            )

            // Save to primary document
            db.collection("netero_profiles").document(cleanUserId).set(profileMap, SetOptions.merge()).await()

            // Also mirror to username document for direct discovery and search
            if (profile.username.isNotBlank() && profile.username != cleanUserId) {
                db.collection("netero_profiles").document(profile.username.trim()).set(profileMap, SetOptions.merge()).await()
            }

            // Also mirror to canonical email document for persistent login restore
            if (profile.email.isNotBlank()) {
                val emailDocId = "user_" + profile.email.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_")
                if (emailDocId != cleanUserId) {
                    db.collection("netero_profiles").document(emailDocId).set(profileMap, SetOptions.merge()).await()
                }
            }

            // Mirror to authUid if distinct
            if (authUid != null && authUid != cleanUserId) {
                db.collection("netero_profiles").document(authUid).set(profileMap, SetOptions.merge()).await()
            }

            // Clean up any stale or duplicate profile documents for this same user
            val docsToDelete = mutableSetOf<String>()
            if (profile.fullName.contains("Rahul Reddy", ignoreCase = true)) {
                docsToDelete.add("Rahul Reddy V")
                docsToDelete.add("Rahul Reddy V ")
            }
            if (!oldUsername.isNullOrBlank() && oldUsername.trim() != cleanUserId && oldUsername.trim() != profile.username.trim()) {
                docsToDelete.add(oldUsername.trim())
            }

            for (staleId in docsToDelete) {
                if (staleId != cleanUserId) {
                    try {
                        db.collection("netero_profiles").document(staleId).delete().await()
                        Log.d(TAG, "Purged duplicate/obsolete profile document: $staleId")
                    } catch (_: Exception) {}
                }
            }

            // Also check if any duplicate document exists with identical email
            if (profile.email.isNotBlank()) {
                try {
                    val emailQuery = db.collection("netero_profiles").whereEqualTo("email", profile.email.trim().lowercase()).get().await()
                    for (doc in emailQuery.documents) {
                        if (doc.id != cleanUserId) {
                            db.collection("netero_profiles").document(doc.id).delete()
                            Log.d(TAG, "Purged duplicate email profile document: ${doc.id}")
                        }
                    }
                } catch (_: Exception) {}
            }

            Log.d(TAG, "Profile live-synced successfully to single Firestore document: $cleanUserId")
            true
        } catch (e: Exception) {
            if (e is com.google.firebase.firestore.FirebaseFirestoreException && e.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                Log.w(TAG, "Failed to sync profile: PERMISSION_DENIED. Please sign in or update Firestore Security Rules.")
            } else {
                Log.e(TAG, "Failed to sync profile to cloud", e)
            }
            false
        }
    }

    fun parseUserProfile(doc: com.google.firebase.firestore.DocumentSnapshot): UserProfile {
        val docId = doc.id
        val explicitId = doc.getString("id") ?: docId
        return UserProfile(
            id = explicitId,
            fullName = doc.getString("fullName") ?: "",
            profileImageUrl = doc.getString("profileImageUrl") ?: "",
            username = doc.getString("username") ?: explicitId,
            headline = doc.getString("headline") ?: "",
            jobTitle = doc.getString("jobTitle") ?: "",
            company = doc.getString("company") ?: "",
            industry = doc.getString("industry") ?: "",
            bio = doc.getString("bio") ?: "",
            location = doc.getString("location") ?: "",
            website = doc.getString("website") ?: "",
            email = doc.getString("email") ?: "",
            phone = doc.getString("phone") ?: "",
            linkedinUrl = doc.getString("linkedinUrl") ?: "",
            businessUrl = doc.getString("businessUrl") ?: "",
            portfolioUrl = doc.getString("portfolioUrl") ?: "",
            skills = (doc.get("skills") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            interests = (doc.get("interests") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            networkingGoals = doc.getString("networkingGoals") ?: "",
            themeColorHex = doc.getString("themeColorHex") ?: "#007AFF",
            neteroLock = NeteroLockSettings(
                phoneVisibility = try { PrivacyLevel.valueOf(doc.getString("phoneVisibility") ?: "CONNECTIONS_ONLY") } catch (e: Exception) { PrivacyLevel.CONNECTIONS_ONLY },
                emailVisibility = try { PrivacyLevel.valueOf(doc.getString("emailVisibility") ?: "CONNECTIONS_ONLY") } catch (e: Exception) { PrivacyLevel.CONNECTIONS_ONLY },
                socialVisibility = try { PrivacyLevel.valueOf(doc.getString("socialVisibility") ?: "PUBLIC") } catch (e: Exception) { PrivacyLevel.PUBLIC },
                profileDiscovery = try { PrivacyLevel.valueOf(doc.getString("profileDiscovery") ?: "PUBLIC") } catch (e: Exception) { PrivacyLevel.PUBLIC },
                portfolioVisibility = try { PrivacyLevel.valueOf(doc.getString("portfolioVisibility") ?: "PUBLIC") } catch (e: Exception) { PrivacyLevel.PUBLIC },
                roomVisibility = doc.getBoolean("roomVisibility") ?: true
            ),
            connectionIds = (doc.get("connectionIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
            isStudent = doc.getBoolean("isStudent") ?: false,
            dateOfBirth = doc.getString("dateOfBirth") ?: "",
            qrScans = doc.getLong("qrScans")?.toInt() ?: 0,
            linkClicks = doc.getLong("linkClicks")?.toInt() ?: 0
        )
    }

    /**
     * Fetch live profiles for a batch of users (used for True Live-Sync of connections).
     */
    suspend fun fetchLiveProfiles(userIds: List<String>): Map<String, UserProfile> {
        val db = firestore ?: return emptyMap()
        val result = mutableMapOf<String, UserProfile>()
        if (userIds.isEmpty()) return result

        val cleanIds = userIds.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val chunks = cleanIds.chunked(10)
        for (chunk in chunks) {
            try {
                for (id in chunk) {
                    try {
                        val doc = db.collection("netero_profiles").document(id).get().await()
                        if (doc.exists()) {
                            val profile = parseUserProfile(doc)
                            result[id] = profile
                            result[doc.id] = profile
                            if (profile.username.isNotBlank()) result[profile.username] = profile
                            if (profile.id.isNotBlank()) result[profile.id] = profile
                        }
                    } catch (_: Exception) {}
                }

                try {
                    val snapshot = db.collection("netero_profiles").whereIn("id", chunk).get().await()
                    for (doc in snapshot.documents) {
                        val profile = parseUserProfile(doc)
                        result[doc.id] = profile
                        if (profile.username.isNotBlank()) result[profile.username] = profile
                        if (profile.id.isNotBlank()) result[profile.id] = profile
                    }
                } catch (_: Exception) {}

                try {
                    val snapshotUname = db.collection("netero_profiles").whereIn("username", chunk).get().await()
                    for (doc in snapshotUname.documents) {
                        val profile = parseUserProfile(doc)
                        result[doc.id] = profile
                        if (profile.username.isNotBlank()) result[profile.username] = profile
                        if (profile.id.isNotBlank()) result[profile.id] = profile
                    }
                } catch (_: Exception) {}
            } catch (e: Exception) {
                Log.e(TAG, "Error fetching live profiles", e)
            }
        }
        return result
    }


    suspend fun resolveAuthUidForIdentifiers(identifiers: List<String>): String? {
        val db = firestore ?: return null
        val clean = identifiers.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (clean.isEmpty()) return null
        // Prefer an explicit authUid field written by the current profile sync.
        for (id in clean) {
            try {
                val doc = db.collection("netero_profiles").document(id).get().await()
                val authUid = doc.getString("authUid")
                if (!authUid.isNullOrBlank()) return authUid
            } catch (_: Exception) {}
        }
        // Fall back to indexed profile fields for users who have not yet reopened
        // the app after the backend identity hardening.
        for (id in clean) {
            try {
                val emailMatch = db.collection("netero_profiles").whereEqualTo("email", id.lowercase()).limit(1).get().await()
                val authUid = emailMatch.documents.firstOrNull()?.getString("authUid")
                if (!authUid.isNullOrBlank()) return authUid
            } catch (_: Exception) {}
            try {
                val usernameMatch = db.collection("netero_profiles").whereEqualTo("username", id).limit(1).get().await()
                val authUid = usernameMatch.documents.firstOrNull()?.getString("authUid")
                if (!authUid.isNullOrBlank()) return authUid
            } catch (_: Exception) {}
        }
        return null
    }

    /**
     * Real-time Flow listener for a specific user profile in Firestore.
     */
    fun listenToUserProfile(userId: String): Flow<UserProfile?> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(null)
            close()
            return@callbackFlow
        }

        val registration: ListenerRegistration = db.collection("netero_profiles")
            .document(userId)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    if (error.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        Log.w(TAG, "Permission Denied: Cannot listen to profile $userId. Please sign in or update Firestore rules.")
                    } else {
                        Log.e(TAG, "Error listening to profile updates for $userId", error)
                    }
                    return@addSnapshotListener
                }

                if (snapshot != null && snapshot.exists()) {
                    val profile = parseUserProfile(snapshot)
                    trySend(profile)
                }
            }

        awaitClose {
            registration.remove()
        }
    }

    /**
     * Real-time Flow listener for connected contacts collection.
     * When any contact updates their profile, this emits the updated contact list in real time.
     */
    fun listenToConnectedContacts(userId: String): Flow<List<ConnectionContact>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val registration = db.collection("users").document(userId)
            .collection("connections")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    if (error.code == com.google.firebase.firestore.FirebaseFirestoreException.Code.PERMISSION_DENIED) {
                        Log.w(TAG, "Permission Denied: Cannot listen to connections for $userId. Please sign in or update Firestore rules.")
                    } else {
                        Log.e(TAG, "Error listening to connections for $userId", error)
                    }
                    return@addSnapshotListener
                }

                if (snapshot != null) {
                    val contacts = snapshot.documents.mapNotNull { doc ->
                        try {
                            ConnectionContact(
                                id = doc.id,
                                name = doc.getString("name") ?: "Contact",
                                jobTitle = doc.getString("jobTitle") ?: "Professional",
                                company = doc.getString("company") ?: "",
                                source = doc.getString("source") ?: "Cloud Sync",
                                dateConnected = doc.getString("dateConnected") ?: "Recently",
                                notes = doc.getString("notes") ?: "",
                                tags = (doc.get("tags") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                                email = doc.getString("email") ?: "",
                                linkedin = doc.getString("linkedin") ?: "",
                                phone = doc.getString("phone") ?: "",
                                avatarInitial = doc.getString("avatarInitial") ?: doc.getString("name")?.take(2)?.uppercase() ?: "NC",
                                avatarBgHex = doc.getLong("avatarBgHex") ?: 0xFF2962FF
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(contacts)
                }
            }

        awaitClose {
            registration.remove()
        }
    }

    /**
     * Simulates or executes a remote contact profile update in Firestore.
     * This updates the cloud card so the user sees live synchronization across devices.
     */
    
    
    fun listenToRooms(): Flow<List<com.example.data.model.Room>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("netero_rooms")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Cloud rooms sync unavailable (${error.message}). Using local rooms.")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val gson = com.google.gson.Gson()
                    val rooms = snapshot.documents.mapNotNull { doc ->
                        try {
                            val jsonString = doc.getString("room_json")
                            if (jsonString != null) {
                                val room = gson.fromJson(jsonString, com.example.data.model.Room::class.java)
                                room.copy(id = doc.id)
                            } else {
                                // Fallback
                                com.example.data.model.Room(
                                    id = doc.id,
                                    name = doc.getString("name") ?: "",
                                    description = doc.getString("description") ?: "",
                                    type = try { com.example.data.model.RoomType.valueOf(doc.getString("type") ?: "PUBLIC") } catch (e: Exception) { com.example.data.model.RoomType.PUBLIC },
                                    location = doc.getString("location") ?: "",
                                    tags = (doc.get("tags") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                                    password = doc.getString("password") ?: "",
                                    startDate = doc.getString("startDate") ?: "",
                                    startTime = doc.getString("startTime") ?: "",
                                    endDate = doc.getString("endDate") ?: "",
                                    endTime = doc.getString("endTime") ?: "",
                                    memberCount = (doc.getLong("memberCount") ?: 0).toInt(),
                                    isJoined = doc.getBoolean("isJoined") ?: false
                                )
                            }
                        } catch (e: Exception) {
                            null
                        }
                    }
                    trySend(rooms)
                }
            }
        awaitClose { registration.remove() }
    }

    
    suspend fun syncConnectionToCloud(userId: String, connection: ConnectionContact): Boolean {
        val db = firestore ?: return false
        return try {
            val contactMap = hashMapOf(
                "name" to connection.name,
                "jobTitle" to connection.jobTitle,
                "company" to connection.company,
                "source" to connection.source,
                "dateConnected" to connection.dateConnected,
                "notes" to connection.notes,
                "tags" to connection.tags,
                "email" to connection.email,
                "linkedin" to connection.linkedin,
                "phone" to connection.phone,
                "whatsapp" to connection.whatsapp,
                "avatarInitial" to connection.avatarInitial,
                "avatarBgHex" to connection.avatarBgHex,
                "locationMet" to connection.locationMet,
                "lastContactedMillis" to connection.lastContactedMillis
            )
            db.collection("users").document(userId)
                .collection("connections").document(connection.id)
                .set(contactMap, SetOptions.merge()).await()
                
            // Update the main profile's connectionIds array for live mutuals
            val cleanContactId = connection.id.removePrefix("c_").removePrefix("req_")
            try {
                db.collection("netero_profiles").document(userId).set(
                    mapOf("connectionIds" to com.google.firebase.firestore.FieldValue.arrayUnion(cleanContactId)), 
                    SetOptions.merge()
                ).await()
            } catch (_: Exception) {}
            try {
                db.collection("netero_profiles").document(cleanContactId).set(
                    mapOf("connectionIds" to com.google.firebase.firestore.FieldValue.arrayUnion(userId)), 
                    SetOptions.merge()
                ).await()
            } catch (_: Exception) {}

            true
        } catch (e: Exception) {
            Log.e(TAG, "Error syncing connection to cloud", e)
            false
        }
    }

    fun listenToConnections(userId: String): kotlinx.coroutines.flow.Flow<List<com.example.data.model.ConnectionContact>> = kotlinx.coroutines.flow.callbackFlow {
        val db = firestore
        if(db==null){ trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("users").document(userId).collection("connections").addSnapshotListener { snap, err ->
            if(err!=null || snap==null) return@addSnapshotListener
            val list = snap.documents.mapNotNull { doc ->
                try {
                    com.example.data.model.ConnectionContact(
                        id = doc.id,
                        name = doc.getString("name")?:"",
                        jobTitle = doc.getString("jobTitle")?:"",
                        company = doc.getString("company")?:"",
                        source = doc.getString("source")?:"",
                        dateConnected = doc.getString("dateConnected")?:"",
                        notes = doc.getString("notes")?:"",
                        tags = (doc.get("tags") as? List<String>) ?: emptyList(),
                        email = doc.getString("email")?:"",
                        phone = doc.getString("phone")?:"",
                        linkedin = doc.getString("linkedin")?:"",
                        avatarInitial = doc.getString("avatarInitial")?:"",
                        avatarBgHex = doc.getLong("avatarBgHex")?:0L,
                        locationMet = doc.getString("locationMet")?:""
                    )
                } catch(e:Exception){ null }
            }
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    suspend fun deleteConnectionFromCloud(userId: String, contactId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(userId)
                .collection("connections").document(contactId)
                .delete().await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deleteConnectionRelationshipFromCloud(
        userId: String,
        contactId: String,
        contactAliases: List<String> = emptyList()
    ): Boolean {
        val db = firestore ?: return false
        val aliases = (listOf(contactId) + contactAliases)
            .map { it.trim() }.filter { it.isNotBlank() }.distinct()
        return try {
            aliases.forEach { alias ->
                db.collection("users").document(userId).collection("connections").document(alias).delete().await()
            }
            aliases.forEach { alias ->
                db.collection("users").document(alias).collection("connections").document(userId).delete().await()
            }
            aliases.forEach { alias ->
                try { db.collection("netero_profiles").document(userId).update("connectionIds", com.google.firebase.firestore.FieldValue.arrayRemove(alias)).await() } catch (_: Exception) {}
                try { db.collection("netero_profiles").document(alias).update("connectionIds", com.google.firebase.firestore.FieldValue.arrayRemove(userId)).await() } catch (_: Exception) {}
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting connection relationship", e)
            false
        }
    }

    suspend fun syncChatMessageToCloud(
        userId: String,
        message: com.example.data.model.ChatMessage,
        senderName: String = "Someone",
        targetUserIds: List<String> = emptyList()
    ): Boolean {
        val db = firestore ?: return false
        if (userId.isBlank()) return false
        return try {
            val sentTime = if (message.sentAtMillis > 0L) message.sentAtMillis else System.currentTimeMillis()
            val msgMap = hashMapOf<String, Any>(
                "contactId" to message.contactId,
                "text" to message.text,
                "timestamp" to message.timestamp,
                "sentAtMillis" to sentTime,
                "senderId" to userId,
                "recipientId" to (targetUserIds.firstOrNull() ?: ""),
                "isFromMe" to message.isFromMe,
                "status" to message.status,
                "attachmentUrl" to (message.attachmentUrl ?: ""),
                "attachmentType" to (message.attachmentType ?: ""),
                "attachmentName" to (message.attachmentName ?: ""),
                "attachmentMimeType" to (message.attachmentMimeType ?: ""),
                "hiddenForUserIds" to emptyList<String>()
            )

            // Always persist the sender's copy first.
            db.collection("users").document(userId)
                .collection("chats").document(message.id)
                .set(msgMap, SetOptions.merge()).await()

            if (!message.isFromMe) return true

            // A message must have exactly one resolved recipient. Do not silently
            // fall back to email/name aliases: that was the source of the
            // "sender sees it, recipient does not" failure mode.
            val recipientIds = targetUserIds.map { it.trim() }
                .filter { it.isNotBlank() && it != userId }
                .distinct()
            if (recipientIds.isEmpty()) {
                Log.e(TAG, "Chat message ${message.id} has no resolved recipient")
                return false
            }

            val recipientId = recipientIds.first()
            val recipientMsgMap = hashMapOf<String, Any>(
                "contactId" to userId,
                "text" to message.text,
                "timestamp" to message.timestamp,
                "sentAtMillis" to sentTime,
                "senderId" to userId,
                "recipientId" to recipientId,
                "isFromMe" to false,
                "status" to "Delivered",
                "attachmentUrl" to (message.attachmentUrl ?: ""),
                "attachmentType" to (message.attachmentType ?: ""),
                "attachmentName" to (message.attachmentName ?: ""),
                "attachmentMimeType" to (message.attachmentMimeType ?: ""),
                "hiddenForUserIds" to emptyList<String>()
            )

            db.collection("users").document(recipientId)
                .collection("chats").document(message.id)
                .set(recipientMsgMap, SetOptions.merge()).await()

            // This document is consumed by the Firebase Cloud Function which
            // sends the actual FCM push using the recipient's stored token.
            db.collection("users").document(recipientId)
                .collection("notifications").add(
                    mapOf(
                        "type" to "MESSAGE",
                        "title" to "New Message from $senderName",
                        "body" to message.text.take(80),
                        "senderId" to userId,
                        "recipientId" to recipientId,
                        "timestamp" to System.currentTimeMillis()
                    )
                ).await()

            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to sync chat message ${message.id}", e)
            false
        }
    }

    fun listenToChatMessages(userId: String): Flow<List<com.example.data.model.ChatMessage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("users").document(userId)
            .collection("chats")
            .orderBy("sentAtMillis", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(100)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.e(TAG, "Real-time chat listener failed for user $userId", error)
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { doc ->
                        try {
                            val hiddenFor = (doc.get("hiddenForUserIds") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
                            if (hiddenFor.contains(userId)) return@mapNotNull null
                            val rawMillis = doc.getLong("sentAtMillis") ?: doc.getLong("timestamp_millis") ?: 0L
                            com.example.data.model.ChatMessage(
                                id = doc.id,
                                contactId = doc.getString("contactId") ?: "",
                                text = doc.getString("text") ?: "",
                                timestamp = doc.getString("timestamp") ?: "",
                                isFromMe = doc.getBoolean("isFromMe") ?: true,
                                status = doc.getString("status") ?: "Delivered",
                                sentAtMillis = if (rawMillis > 0L) rawMillis else System.currentTimeMillis(),
                                isDeleted = doc.getBoolean("isDeleted") ?: false,
                                isEdited = doc.getBoolean("isEdited") ?: false,
                                senderId = doc.getString("senderId") ?: "",
                                attachmentUrl = doc.getString("attachmentUrl")?.takeIf { it.isNotBlank() },
                                attachmentType = doc.getString("attachmentType")?.takeIf { it.isNotBlank() },
                                attachmentName = doc.getString("attachmentName")?.takeIf { it.isNotBlank() },
                                attachmentMimeType = doc.getString("attachmentMimeType")?.takeIf { it.isNotBlank() }
                            )
                        } catch (e: Exception) {
                            null
                        }
                    }.sortedBy { it.sentAtMillis }
                    trySend(messages)
                }
            }
        awaitClose { registration.remove() }
    }

    
    suspend fun syncAiMessageToCloud(userId: String, msgId: String, text: String, isFromUser: Boolean): Boolean {
        val db = firestore ?: return false
        return try {
            val msgMap = hashMapOf(
                "text" to text,
                "isFromUser" to isFromUser,
                "timestamp" to System.currentTimeMillis()
            )
            db.collection("users").document(userId)
                .collection("ai_chats").document(msgId)
                .set(msgMap, SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun clearAiMessagesFromCloud(userId: String): Boolean {
        val db = firestore ?: return false
        return try {
            val docs = db.collection("users").document(userId).collection("ai_chats").get().await()
            for (doc in docs) {
                doc.reference.delete().await()
            }
            true
        } catch (e: Exception) {
            false
        }
    }

    fun listenToAiMessages(userId: String): Flow<List<com.example.ui.viewmodel.AiAssistantMessage>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val registration = db.collection("users").document(userId)
            .collection("ai_chats")
            .orderBy("timestamp")
            .addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                if (snapshot != null) {
                    val messages = snapshot.documents.mapNotNull { doc ->
                        try {
                            val hiddenFor = (doc.get("hiddenForUserIds") as? List<*>)?.mapNotNull { it?.toString() } ?: emptyList()
                            if (hiddenFor.contains(userId)) return@mapNotNull null
                            com.example.ui.viewmodel.AiAssistantMessage(
                                text = doc.getString("text") ?: "",
                                isFromUser = doc.getBoolean("isFromUser") ?: false
                            )
                        } catch (e: Exception) { null }
                    }
                    trySend(messages)
                }
            }
        awaitClose { registration.remove() }
    }

    
    suspend fun deleteUserSubcollectionsAndRoot(targetUserId: String) {
        val db = firestore ?: return
        if (targetUserId.isBlank()) return
        val subcollections = listOf("chats", "connections", "ai_chats", "typing_status", "requests", "notifications", "profile_views")
        for (sub in subcollections) {
            try {
                val docs = db.collection("users").document(targetUserId).collection(sub).get().await()
                for (doc in docs.documents) {
                    try { doc.reference.delete().await() } catch (_: Exception) {}
                }
            } catch (_: Exception) {}
        }
        try { db.collection("users").document(targetUserId).delete().await() } catch (_: Exception) {}
    }

    suspend fun cleanCorruptProfiles() = withContext(Dispatchers.IO) {
        try {
            val db = firestore ?: return@withContext

            // 1. Purge orphaned subcollections under 'users' collection for legacy names
            val authUid = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid } catch (_: Exception) { null }
            val legacyUserFolders = listOf("Rahul Reddy V", "Rahul Reddy V ", "Rahul Reddy")
            for (legacyId in legacyUserFolders) {
                if (legacyId != authUid) {
                    deleteUserSubcollectionsAndRoot(legacyId)
                    Log.d(TAG, "cleanCorruptProfiles removed legacy users subcollections for: $legacyId")
                }
            }

            val snap = db.collection("netero_profiles").get().await()
            for (doc in snap.documents) {
                val docId = doc.id.trim()
                val name = doc.getString("fullName")?.trim() ?: ""
                val title = doc.getString("jobTitle")?.trim() ?: ""
                val comp = doc.getString("company")?.trim() ?: ""
                val isOldLegacyName = docId.equals("Rahul Reddy V", ignoreCase = true) || name.equals("Rahul Reddy V", ignoreCase = true)
                val isPunctuationOnly = (name == "." || name == "..") && title.isBlank() && comp.isBlank()
                if (isOldLegacyName || isPunctuationOnly) {
                    db.collection("netero_profiles").document(doc.id).delete()
                    Log.d(TAG, "cleanCorruptProfiles deleted legacy placeholder: ${doc.id}")
                }
            }
        } catch (_: Exception) {}
    }

    suspend fun searchUsers(
        query: String,
        currentUserId: String = "",
        currentUsername: String = "",
        currentUserEmail: String = ""
    ): List<com.example.data.model.RecommendedPerson> {
        val db = firestore ?: return emptyList()
        return try {
            val q = query.lowercase().trim()
            val cleanUid = currentUserId.trim()
            val cleanUsername = currentUsername.trim().lowercase()
            val cleanEmail = currentUserEmail.trim().lowercase()

            val result = db.collection("netero_profiles").get().await()
            result.documents.filter { doc ->
                // Username/email mirror docs are legacy lookup aliases. Search only canonical
                // Auth-UID profiles so one member cannot appear multiple times or with stale data.
                val authUid = (doc.getString("authUid") ?: "").trim()
                if (authUid.isBlank() || doc.id.trim() != authUid) return@filter false
                val docId = doc.id.trim()
                val docUsername = (doc.getString("username") ?: "").trim().lowercase()
                val docEmail = (doc.getString("email") ?: "").trim().lowercase()

                val isMeById = cleanUid.isNotBlank() && (docId == cleanUid || docUsername == cleanUid)
                val isMeByUsername = cleanUsername.isNotBlank() && (docUsername == cleanUsername || docId == cleanUsername)
                val isMeByEmail = cleanEmail.isNotBlank() && docEmail == cleanEmail

                !isMeById && !isMeByUsername && !isMeByEmail
            }.mapNotNull { doc ->
                val name = doc.getString("fullName")?.trim() ?: ""
                val title = doc.getString("jobTitle")?.trim() ?: ""
                val comp = doc.getString("company")?.trim() ?: ""
                val ind = doc.getString("industry")?.trim() ?: ""
                val bio = doc.getString("bio")?.trim() ?: ""
                val interests = (doc.get("interests") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                
                // Strictly filter out dot, double-dot, empty, placeholder, or invalid test profiles
                if (name.isBlank() || name == "." || name == ".." || name.length < 2 || !name.any { it.isLetter() }) return@mapNotNull null
                if (title == "." || comp == "." || title == ".." || comp == "..") return@mapNotNull null

                // Semantic industry and domain synonym expansion
                val searchSynonyms = when {
                    q.isBlank() -> emptySet()
                    q in listOf("ai", "artificial intelligence", "ml", "machine learning", "data", "nlp", "deep learning", "llm", "genai") ->
                        setOf("ai", "artificial intelligence", "ml", "machine learning", "deep learning", "data science", "nlp", "llm", "genai", "analytics")
                    q in listOf("saas", "sas", "software", "cloud", "b2b", "enterprise", "platform", "app") || q.contains("saas") ->
                        setOf("saas", "sas", "software", "cloud", "b2b", "enterprise", "platform", "developer", "engineer", "devops")
                    q in listOf("fintech", "finance", "banking", "crypto", "web3", "blockchain", "investor", "vc", "venture", "investment") ->
                        setOf("fintech", "finance", "banking", "payments", "crypto", "web3", "blockchain", "defi", "investor", "vc", "venture capital", "angel", "investment", "capital")
                    q in listOf("health", "healthcare", "biotech", "medical", "pharma", "healthtech", "doctor") ->
                        setOf("health", "healthcare", "biotech", "medical", "pharma", "healthtech", "medtech", "clinical", "life sciences")
                    q in listOf("marketing", "growth", "sales", "bd", "business development", "seo", "branding") ->
                        setOf("marketing", "growth", "sales", "business development", "seo", "branding", "content", "adtech")
                    q in listOf("product", "design", "ui", "ux", "pm", "product manager") ->
                        setOf("product", "design", "ui", "ux", "pm", "product manager", "product design")
                    q in listOf("founder", "ceo", "entrepreneur", "co-founder", "startup", "cto", "leadership") ->
                        setOf("founder", "ceo", "entrepreneur", "co-founder", "startup", "cto", "cpo", "coo", "executive")
                    q in listOf("student", "intern", "university", "college", "graduate", "fresher") ->
                        setOf("student", "intern", "university", "college", "graduate", "fresher", "academic", "researcher")
                    else -> setOf(q)
                }

                val allTargetText = "$name $title $comp $ind $bio ${interests.joinToString(" ")}".lowercase()
                val isSemanticMatch = q.isBlank() || searchSynonyms.any { syn -> allTargetText.contains(syn) }

                if (isSemanticMatch) {
                    val avatarInitial = name.split(" ")
                        .filter { it.isNotBlank() }
                        .mapNotNull { it.firstOrNull()?.uppercase() }
                        .take(2)
                        .joinToString("")
                        .ifBlank { name.take(2).uppercase() }

                    val rawPhone = doc.getString("phone")
                    val phoneVis = doc.getString("phoneVisibility") ?: "CONNECTIONS_ONLY"
                    val emailVis = doc.getString("emailVisibility") ?: "CONNECTIONS_ONLY"
                    val socialVis = doc.getString("socialVisibility") ?: "PUBLIC"
                    val portfolioVis = doc.getString("portfolioVisibility") ?: "PUBLIC"

                    val phoneVal = if (phoneVis.equals("PUBLIC", ignoreCase = true)) rawPhone else null
                    val emailVal = if (emailVis.equals("PUBLIC", ignoreCase = true)) doc.getString("email") else null
                    val linkedinVal = if (socialVis.equals("PRIVATE", ignoreCase = true)) null else (doc.getString("linkedinUrl") ?: doc.getString("linkedin"))
                    val websiteVal = if (socialVis.equals("PRIVATE", ignoreCase = true)) null else doc.getString("website")
                    val businessVal = if (socialVis.equals("PRIVATE", ignoreCase = true)) null else doc.getString("businessUrl")
                    val portfolioVal = if (portfolioVis.equals("PRIVATE", ignoreCase = true)) null else (doc.getString("portfolioUrl") ?: doc.getString("portfolio") ?: doc.getString("website"))
                    val isPublic = phoneVis.equals("PUBLIC", ignoreCase = true) || emailVis.equals("PUBLIC", ignoreCase = true)

                    com.example.data.model.RecommendedPerson(
                        id = doc.id,
                        name = name,
                        username = doc.getString("username") ?: "",
                        jobTitle = title,
                        company = comp,
                        industry = ind,
                        location = doc.getString("location") ?: "",
                        mutualConnectionsCount = 0,
                        sharedInterests = interests,
                        category = "Search",
                        email = emailVal,
                        phone = phoneVal,
                        linkedinUrl = linkedinVal,
                        isContactInfoPublic = isPublic,
                        portfolioUrl = portfolioVal,
                        website = websiteVal,
                        businessUrl = businessVal,
                        bio = bio,
                        avatarInitial = avatarInitial,
                        avatarBgHex = 0xFF2962FF,
                        connectionIds = (doc.get("connectionIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList(),
                        profileImageUrl = doc.getString("profileImageUrl") ?: "",
                        asteronResearchSummary = (doc.get("asteronResearch") as? Map<*, *>)?.get("summary")?.toString() ?: ""
                    )
                } else null
            }
        } catch(e:Exception){ emptyList() }
    }



    companion object {
        const val FREE_STORAGE_LIMIT_BYTES: Long = 500L * 1024L * 1024L
    }

    /**
     * Atomically reserves free-user attachment storage. Pro users bypass the
     * quota. Reservations prevent two simultaneous uploads from exceeding the
     * 500 MB allowance.
     */
    suspend fun reserveStorage(userId: String, bytes: Long, isPro: Boolean): Boolean {
        if (isPro) return true
        if (userId.isBlank() || bytes <= 0L || bytes > FREE_STORAGE_LIMIT_BYTES) return false
        val db = firestore ?: return false
        return try {
            db.runTransaction { tx ->
                val ref = db.collection("users").document(userId)
                val snap = tx.get(ref)
                val used = snap.getLong("storageUsedBytes") ?: 0L
                val reserved = snap.getLong("storageReservedBytes") ?: 0L
                if (used < 0L || reserved < 0L || used + reserved + bytes > FREE_STORAGE_LIMIT_BYTES) {
                    throw IllegalStateException("FREE_STORAGE_LIMIT_REACHED")
                }
                tx.set(ref, mapOf("storageReservedBytes" to reserved + bytes), SetOptions.merge())
                null
            }.await()
            true
        } catch (e: Exception) {
            Log.w(TAG, "Storage reservation denied for $userId: ${e.message}")
            false
        }
    }

    suspend fun commitStorageReservation(userId: String, bytes: Long, isPro: Boolean): Boolean {
        if (isPro || bytes <= 0L) return true
        val db = firestore ?: return false
        return try {
            db.runTransaction { tx ->
                val ref = db.collection("users").document(userId)
                val snap = tx.get(ref)
                val used = snap.getLong("storageUsedBytes") ?: 0L
                val reserved = snap.getLong("storageReservedBytes") ?: 0L
                val nextReserved = (reserved - bytes).coerceAtLeast(0L)
                val nextUsed = used + bytes
                if (nextUsed > FREE_STORAGE_LIMIT_BYTES) {
                    throw IllegalStateException("FREE_STORAGE_LIMIT_REACHED")
                }
                tx.set(ref, mapOf(
                    "storageUsedBytes" to nextUsed,
                    "storageReservedBytes" to nextReserved
                ), SetOptions.merge())
                null
            }.await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to commit storage usage", e)
            false
        }
    }

    suspend fun releaseStorageReservation(userId: String, bytes: Long, isPro: Boolean) {
        if (isPro || bytes <= 0L) return
        val db = firestore ?: return
        try {
            db.runTransaction { tx ->
                val ref = db.collection("users").document(userId)
                val snap = tx.get(ref)
                val reserved = snap.getLong("storageReservedBytes") ?: 0L
                tx.set(ref, mapOf("storageReservedBytes" to (reserved - bytes).coerceAtLeast(0L)), SetOptions.merge())
                null
            }.await()
        } catch (e: Exception) {
            Log.w(TAG, "Failed to release storage reservation", e)
        }
    }

    suspend fun getStorageUsage(userId: String): Long {
        val db = firestore ?: return 0L
        return try {
            db.collection("users").document(userId).get().await().getLong("storageUsedBytes")?.coerceAtLeast(0L) ?: 0L
        } catch (_: Exception) { 0L }
    }

    suspend fun deleteAttachment(path: String): Boolean {
        if (path.isBlank()) return false
        return try {
            getStorageReference().child(path).delete().await()
            true
        } catch (e: Exception) {
            Log.w(TAG, "Failed to delete attachment: $path", e)
            false
        }
    }

    suspend fun uploadAttachment(
        path: String,
        contentResolver: ContentResolver,
        uri: Uri,
        mimeType: String?,
        originalName: String? = null
    ): String? {
        return try {
            val input = contentResolver.openInputStream(uri) ?: return null
            input.use { stream ->
                val storageRef = getStorageReference()
                val fileRef = storageRef.child(path)
                val safeMime = mimeType?.takeIf { it.isNotBlank() } ?: "application/octet-stream"
                val metadataBuilder = com.google.firebase.storage.StorageMetadata.Builder()
                    .setContentType(safeMime)
                if (!originalName.isNullOrBlank()) {
                    metadataBuilder.setCustomMetadata("originalName", originalName.take(240))
                }
                fileRef.putStream(stream, metadataBuilder.build()).await()
                fileRef.downloadUrl.await().toString()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload attachment: $path", e)
            null
        }
    }

    /**
     * Real-time listener for all user profiles in Netero.
     * Used by NeteroViewModel to auto-update existing contacts when a connection edits
     * their name (e.g. Rahul -> Rahul Reddy), company, title, or industry.
     */
    fun listenToAllProfiles(): Flow<List<UserProfile>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = db.collection("netero_profiles").addSnapshotListener { snap, err ->
            if (err != null || snap == null) return@addSnapshotListener
            // Only consume canonical Auth-UID profile documents here.
            // Username/email mirror documents intentionally carry the same authUid,
            // but may lag briefly; using them could cause a stale mirror to win.
            val list = snap.documents
                .filter { doc ->
                    val authUid = doc.getString("authUid")
                    !authUid.isNullOrBlank() && doc.id == authUid
                }
                .mapNotNull { doc ->
                    try {
                        parseUserProfile(doc)
                    } catch (e: Exception) {
                        null
                    }
                }
            trySend(list)
        }
        awaitClose { reg.remove() }
    }

    suspend fun sendConnectionRequest(
        fromUserId: String,
        toUserId: String,
        req: com.example.ui.viewmodel.ConnectionRequest,
        targetAliases: List<String> = emptyList()
    ): Boolean {
        return try {
            val targetCandidates = (listOf(toUserId) + targetAliases).map { it.trim() }.filter { it.isNotBlank() }.distinct()
            val resolvedRecipient = if (targetCandidates.contains(toUserId)) {
                resolveAuthUidForIdentifiers(targetCandidates) ?: toUserId
            } else null
            if (resolvedRecipient.isNullOrBlank() || resolvedRecipient == fromUserId) return false
            val functions = com.google.firebase.functions.FirebaseFunctions.getInstance()
            functions.getHttpsCallable("sendNeteroConnectionRequest").call(
                mapOf(
                    "recipientId" to resolvedRecipient,
                    "message" to req.message,
                    "senderName" to req.senderName,
                    "senderTitle" to req.senderTitle,
                    "senderCompany" to req.senderCompany,
                    "avatarBgHex" to req.avatarBgHex,
                    "isQrScan" to req.isQrScan
                )
            ).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Server-side connection request failed", e)
            false
        }
    }

    fun listenToConnectionRequests(userId: String): Flow<List<com.example.ui.viewmodel.ConnectionRequest>> = callbackFlow {
        val db = firestore
        if(db==null){ trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("users").document(userId).collection("requests").addSnapshotListener { snap, err ->
            if(err!=null || snap==null) return@addSnapshotListener
            val reqs = snap.documents.mapNotNull { doc ->
                try {
                    com.example.ui.viewmodel.ConnectionRequest(
                        id = doc.id,
                        senderName = doc.getString("senderName")?:"",
                        senderTitle = doc.getString("senderTitle")?:"",
                        senderCompany = doc.getString("senderCompany")?:"",
                        message = doc.getString("message")?:"",
                        timeAgo = doc.getString("timeAgo")?:"",
                        avatarInitial = doc.getString("avatarInitial")?:"",
                        avatarBgHex = doc.getLong("avatarBgHex")?:0L,
                        timestamp = doc.getLong("timestamp")?:0L,
                        isQrScan = doc.getBoolean("isQrScan") ?: false,
                        senderId = doc.getString("senderId") ?: doc.id
                    )
                } catch(e:Exception){ null }
            }
            trySend(reqs)
        }
        awaitClose { reg.remove() }
    }

    suspend fun acceptConnectionServerSide(senderId: String): Boolean {
        return try {
            val functions = com.google.firebase.functions.FirebaseFunctions.getInstance()
            functions.getHttpsCallable("acceptNeteroConnection").call(mapOf("senderId" to senderId)).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Server-side connection acceptance failed", e)
            false
        }
    }

    suspend fun sendMessageServerSide(
        recipientId: String,
        message: com.example.data.model.ChatMessage,
        senderName: String
    ): Boolean {
        return try {
            val functions = com.google.firebase.functions.FirebaseFunctions.getInstance()
            functions.getHttpsCallable("sendNeteroMessage").call(mapOf(
                "recipientId" to recipientId,
                "messageId" to message.id,
                "text" to message.text,
                "sentAtMillis" to if (message.sentAtMillis > 0L) message.sentAtMillis else System.currentTimeMillis(),
                "attachmentUrl" to (message.attachmentUrl ?: ""),
                "attachmentType" to (message.attachmentType ?: ""),
                "attachmentName" to (message.attachmentName ?: ""),
                "attachmentMimeType" to (message.attachmentMimeType ?: ""),
                "senderName" to senderName
            )).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Server-side message delivery failed", e)
            false
        }
    }

    suspend fun mutateRoomServerSide(roomId: String, action: String, targetId: String? = null): Boolean {
        return try {
            val functions = com.google.firebase.functions.FirebaseFunctions.getInstance()
            val payload = mutableMapOf<String, Any>("roomId" to roomId, "action" to action)
            if (!targetId.isNullOrBlank()) payload["targetId"] = targetId
            functions.getHttpsCallable("mutateNeteroRoom").call(payload).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Server-side room mutation failed: $action/$roomId", e)
            false
        }
    }

    suspend fun markConnectionAsMutual(userAId: String, userBId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(userAId)
                .collection("connections").document(userBId)
                .set(mapOf("tags" to listOf("MUTUAL"), "source" to "Connected"), SetOptions.merge()).await()
            db.collection("users").document(userBId)
                .collection("connections").document(userAId)
                .set(mapOf("tags" to listOf("MUTUAL"), "source" to "Connected"), SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun sendNotification(userId: String, notifMap: Map<String, Any>): Boolean {
        val db = firestore ?: return false
        return try {
            val senderId = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "" } catch (_: Exception) { "" }
            val enriched = notifMap.toMutableMap().apply {
                put("recipientId", userId)
                if (!containsKey("senderId") && senderId.isNotBlank()) put("senderId", senderId)
            }
            db.collection("users").document(userId).collection("notifications").add(enriched).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun postRoomDiscussion(roomId: String, discussion: com.example.data.model.RoomDiscussion): Boolean {
        val db = firestore ?: return false
        return try {
            val discMap = hashMapOf(
                "id" to discussion.id,
                "authorName" to discussion.authorName,
                "authorTitle" to discussion.authorTitle,
                "content" to discussion.content,
                "timeAgo" to discussion.timeAgo,
                "likesCount" to discussion.likesCount,
                "authorId" to discussion.authorId,
                "isEdited" to discussion.isEdited,
                "isDeleted" to discussion.isDeleted,
                "attachmentUrl" to (discussion.attachmentUrl ?: ""),
                "attachmentType" to (discussion.attachmentType ?: ""),
                "attachmentName" to (discussion.attachmentName ?: ""),
                "attachmentMimeType" to (discussion.attachmentMimeType ?: ""),
                "timestamp" to System.currentTimeMillis()
            )
            db.collection("netero_rooms").document(roomId)
                .collection("discussions").document(discussion.id)
                .set(discMap, SetOptions.merge()).await()
            true
        } catch (e: Exception) {
            false
        }
    }

    suspend fun deleteRoomDiscussionInCloud(roomId: String, discussionId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("netero_rooms").document(roomId)
                .collection("discussions").document(discussionId)
                .update("isDeleted", true, "content", "🚫 This message was deleted").await()
            true
        } catch (e: Exception) {
            false
        }
    }

    fun listenToRoomDiscussions(roomId: String): Flow<List<com.example.data.model.RoomDiscussion>> = callbackFlow {
        val db = firestore
        if (db == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val reg = db.collection("netero_rooms").document(roomId)
            .collection("discussions")
            .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
            .limit(80)
            .addSnapshotListener { snap, err ->
                if (err != null || snap == null) return@addSnapshotListener
                val list = snap.documents.mapNotNull { doc ->
                    try {
                        com.example.data.model.RoomDiscussion(
                            id = doc.getString("id") ?: doc.id,
                            authorName = doc.getString("authorName") ?: "",
                            authorTitle = doc.getString("authorTitle") ?: "",
                            content = doc.getString("content") ?: "",
                            timeAgo = doc.getString("timeAgo") ?: "Recently",
                            likesCount = doc.getLong("likesCount")?.toInt() ?: 0,
                            authorId = doc.getString("authorId") ?: "",
                            isEdited = doc.getBoolean("isEdited") ?: false,
                            isDeleted = doc.getBoolean("isDeleted") ?: false,
                            attachmentUrl = doc.getString("attachmentUrl")?.takeIf { it.isNotBlank() },
                            attachmentType = doc.getString("attachmentType")?.takeIf { it.isNotBlank() },
                            attachmentName = doc.getString("attachmentName")?.takeIf { it.isNotBlank() },
                            attachmentMimeType = doc.getString("attachmentMimeType")?.takeIf { it.isNotBlank() }
                        )
                    } catch (e: Exception) { null }
                }
                trySend(list)
            }
        awaitClose { reg.remove() }
    }

    suspend fun deleteConnectionRequest(userId: String, requestId: String) {
        firestore?.collection("users")?.document(userId)?.collection("requests")?.document(requestId)?.delete()?.await()
    }

    suspend fun deleteConnectionRequestFromAliases(
        recipientAliases: List<String>,
        requestIds: List<String>
    ) {
        val db = firestore ?: return
        val targets = recipientAliases.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        val ids = requestIds.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        for (target in targets) {
            for (requestId in ids) {
                try { db.collection("users").document(target).collection("requests").document(requestId).delete().await() } catch (_: Exception) {}
            }
        }
    }
    
    suspend fun recordProfileView(viewedId: String, viewerName: String, viewerRole: String) {
        val db = firestore ?: return
        try {
            val viewerId = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "" } catch (_: Exception) { "" }
            val map = hashMapOf("viewerName" to viewerName, "viewerRole" to viewerRole, "viewerId" to viewerId, "timestamp" to System.currentTimeMillis())
            db.collection("users").document(viewedId).collection("profile_views").add(map).await()
            val notif = hashMapOf("type" to "VIEW", "title" to "New Profile View", "body" to "$viewerName viewed your profile.", "senderId" to viewerId, "recipientId" to viewedId, "timestamp" to System.currentTimeMillis())
            db.collection("users").document(viewedId).collection("notifications").add(notif).await()
        } catch(e:Exception){}
    }

    fun listenToProfileViews(userId: String): Flow<List<Pair<String, String>>> = callbackFlow {
        val db = firestore
        if(db==null){ trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("users").document(userId).collection("profile_views").orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(50).addSnapshotListener { snap, err ->
            if(err!=null || snap==null) return@addSnapshotListener
            val views = snap.documents.mapNotNull { doc ->
                val n = doc.getString("viewerName")
                val r = doc.getString("viewerRole")
                if(n!=null && r!=null) n to r else null
            }
            trySend(views)
        }
        awaitClose { reg.remove() }
    }

    suspend fun deleteChatMessageFromCloud(userId: String, msgId: String, otherUserId: String? = null): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(userId).collection("chats").document(msgId).update("isDeleted", true, "text", "🚫 This message was deleted").await()
            if (otherUserId != null) {
                db.collection("users").document(otherUserId).collection("chats").document(msgId).update("isDeleted", true, "text", "🚫 This message was deleted").await()
            }
            true
        } catch(e:Exception){ false }
    }

    suspend fun deleteChatMessageForUser(userId: String, msgId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(userId).collection("chats").document(msgId)
                .update("hiddenForUserIds", com.google.firebase.firestore.FieldValue.arrayUnion(userId)).await()
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to persist delete-for-me", e)
            false
        }
    }

    suspend fun editChatMessageInCloud(userId: String, msgId: String, newText: String, otherUserId: String? = null): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("users").document(userId).collection("chats").document(msgId).update("text", newText, "isEdited", true).await()
            if (otherUserId != null) {
                db.collection("users").document(otherUserId).collection("chats").document(msgId).update("text", newText, "isEdited", true).await()
            }
            true
        } catch(e:Exception){ false }
    }
    
    fun sendNotification(userId: String, title: String, body: String) {
        val db = firestore ?: return
        val senderId = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "" } catch (_: Exception) { "" }
        val notif = hashMapOf(
            "title" to title,
            "body" to body,
            "recipientId" to userId,
            "senderId" to senderId,
            "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp()
        )
        db.collection("users").document(userId).collection("notifications").add(notif)
    }

    fun listenToNotifications(userId: String): Flow<List<com.example.ui.viewmodel.AppNotification>> = callbackFlow {
        val db = firestore
        if(db==null){ trySend(emptyList()); close(); return@callbackFlow }
        val reg = db.collection("users").document(userId).collection("notifications").orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING).limit(50).addSnapshotListener { snap, err ->
            if(err!=null || snap==null) return@addSnapshotListener
            val notifs = snap.documents.mapNotNull { doc ->
                com.example.ui.viewmodel.AppNotification(
                    id = doc.id,
                    title = doc.getString("title")?:"",
                    body = doc.getString("body")?:"",
                    timeAgo = "Recently"
                )
            }
            trySend(notifs)
        }
        awaitClose { reg.remove() }
    }

    suspend fun syncRoom(room: com.example.data.model.Room): Boolean {
        val db = firestore ?: return false
        return try {
            val gson = com.google.gson.Gson()
            val sharedRoom = room.copy(
                isJoined = false,
                isJoinRequested = false,
                // Discussions have their own real-time subcollection. Do not
                // serialize a stale/local copy into the room document.
                discussions = emptyList()
            )
            val roomJson = gson.toJson(sharedRoom)
            val roomMap = hashMapOf(
                "room_json" to roomJson,
                // Fallbacks for older structure
                "name" to room.name,
                "description" to room.description,
                "type" to room.type.name,
                "location" to room.location,
                "tags" to room.tags,
                "password" to room.password,
                "startDate" to room.startDate,
                "startTime" to room.startTime,
                "endDate" to room.endDate,
                "endTime" to room.endTime,
                "memberCount" to room.memberCount,
                "adminId" to room.adminId,
                "adminIds" to (room.members.filter { it.isAdmin }.map { it.id } + room.speakers.filter { it.isAdmin }.map { it.id } + listOf(room.adminId)).filter { it.isNotBlank() }.distinct(),
                "onlyAdminsCanChat" to room.onlyAdminsCanChat,
                "memberIds" to room.members.map { it.id }
            )
            db.collection("netero_rooms").document(room.id).set(roomMap, SetOptions.merge()).await()
            true
        } catch(e: Exception) {
            false
        }
    }

    suspend fun deleteRoom(roomId: String): Boolean {
        val db = firestore ?: return false
        return try {
            db.collection("netero_rooms").document(roomId).delete().await()
            true
        } catch(e: Exception) {
            Log.e(TAG, "Failed to delete room", e)
            false
        }
    }

    suspend fun createNewRoom(room: com.example.data.model.Room): Boolean {
        return syncRoom(room)
    }


    suspend fun updateRemoteContactCard(
        contactId: String,
        updatedJobTitle: String,
        updatedCompany: String,
        updatedPhone: String? = null,
        updatedNotes: String? = null
    ): Boolean {
        val db = firestore ?: return false
        return try {
            val updateMap = mutableMapOf<String, Any>(
                "jobTitle" to updatedJobTitle,
                "company" to updatedCompany,
                "lastUpdated" to System.currentTimeMillis()
            )
            if (updatedPhone != null) updateMap["phone"] = updatedPhone
            if (updatedNotes != null) updateMap["notes"] = updatedNotes

            db.collection("netero_profiles").document(contactId).set(updateMap, SetOptions.merge()).await()
            Log.d(TAG, "Remote contact card updated live in Firestore for $contactId")
            true
        } catch (e: Exception) {
            Log.e(TAG, "Error updating remote contact card", e)
            false
        }
    }
    /**
     * Permanently deletes all user data from Firestore across all collections:
     * - Profile in `netero_profiles/{userId}` and any matching email/phone profile docs
     * - Subcollections in `users/{userId}` (chats, connections, ai_chats, typing_status, requests, notifications, profile_views)
     * - Created rooms in `netero_rooms`
     */
    suspend fun permanentlyDeleteUserFromCloud(
        userId: String,
        username: String = "",
        userEmail: String = "",
        userPhone: String = "",
        fullName: String = ""
    ): Boolean = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val db = firestore ?: return@withContext false
        try {
            // Collect all candidate user identifiers to ensure zero leftover data
            val candidateUserIds = mutableSetOf<String>()
            if (userId.isNotBlank()) candidateUserIds.add(userId.trim())
            if (username.isNotBlank()) candidateUserIds.add(username.trim())
            if (userEmail.isNotBlank()) {
                candidateUserIds.add(userEmail.trim())
                candidateUserIds.add("user_" + userEmail.trim().lowercase().replace(Regex("[^a-zA-Z0-9_]"), "_"))
            }
            if (userPhone.isNotBlank()) candidateUserIds.add(userPhone.trim())
            try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid?.let { candidateUserIds.add(it) } } catch (_: Exception) {}
            if (fullName.isNotBlank()) {
                candidateUserIds.add(fullName.trim())
                if (fullName.contains("Rahul Reddy", ignoreCase = true)) {
                    candidateUserIds.add("Rahul Reddy")
                    candidateUserIds.add("Rahul Reddy V")
                    candidateUserIds.add("Rahul Reddy V ")
                }
            }

            // 1. Delete all subcollections and root docs from 'users' collection
            for (id in candidateUserIds) {
                deleteUserSubcollectionsAndRoot(id)
            }

            // Remove reverse connection/request references held under other users so a future
            // account using the same verified identity cannot inherit old relationship state.
            try {
                val allUserDocs = db.collection("users").get().await().documents
                for (userDoc in allUserDocs) {
                    for (alias in candidateUserIds) {
                        if (alias.isBlank()) continue
                        try { userDoc.reference.collection("connections").document(alias).delete().await() } catch (_: Exception) {}
                        try { userDoc.reference.collection("requests").document(alias).delete().await() } catch (_: Exception) {}
                    }
                    // Remove direct-message copies from every user's inbox so recreating the
                    // same email/username cannot resurrect an old conversation.
                    try {
                        val chatDocs = userDoc.reference.collection("chats").get().await().documents
                        for (chat in chatDocs) {
                            val contactId = chat.getString("contactId") ?: ""
                            val senderId = chat.getString("senderId") ?: ""
                            if (candidateUserIds.any { id -> id.isNotBlank() && (contactId.equals(id, true) || senderId.equals(id, true)) }) {
                                chat.reference.delete().await()
                            }
                        }
                    } catch (_: Exception) {}
                    try {
                        val notificationDocs = userDoc.reference.collection("notifications").get().await().documents
                        for (notification in notificationDocs) {
                            val senderId = notification.getString("senderId") ?: ""
                            if (candidateUserIds.any { id -> id.isNotBlank() && senderId.equals(id, true) }) {
                                notification.reference.delete().await()
                            }
                        }
                    } catch (_: Exception) {}
                }
            } catch (e: Exception) {
                Log.w(TAG, "Could not remove every reverse relationship during account deletion: ${e.message}")
            }

            // 2. Delete profile documents by UID and candidates
            for (id in candidateUserIds) {
                try {
                    db.collection("netero_profiles").document(id).delete().await()
                } catch (_: Exception) {}
            }
            
            // 3. Delete any netero_rooms created or administered by this user
            try {
                val roomsSnap = db.collection("netero_rooms").get().await()
                for (doc in roomsSnap.documents) {
                    val adminId = doc.getString("adminId") ?: ""
                    val creatorId = doc.getString("creatorId") ?: ""
                    val roomJson = doc.getString("room_json") ?: ""
                    val isMyRoom = candidateUserIds.any { id ->
                        id.isNotBlank() && (
                            adminId.equals(id, ignoreCase = true) ||
                            creatorId.equals(id, ignoreCase = true) ||
                            roomJson.contains("\"adminId\":\"$id\"") ||
                            roomJson.contains("\"creatorId\":\"$id\"")
                        )
                    }
                    if (isMyRoom) {
                        doc.reference.delete().await()
                        Log.d(TAG, "Deleted created room: ${doc.id}")
                    } else {
                        // If user joined this room, remove user from room's member list
                        try {
                            val members = doc.get("members") as? List<*>
                            if (members != null && candidateUserIds.any { id -> members.contains(id) }) {
                                val updatedMembers = members.filter { m -> !candidateUserIds.contains(m.toString()) }
                                doc.reference.update("members", updatedMembers).await()
                            }
                        } catch (_: Exception) {}
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error cleaning rooms on account deletion: ${e.message}")
            }

            // 4. Delete all support tickets submitted by this user
            try {
                val ticketsSnap = db.collection("support_tickets").whereEqualTo("userId", userId).get().await()
                for (doc in ticketsSnap.documents) {
                    doc.reference.delete().await()
                    Log.d(TAG, "Deleted support ticket: ${doc.id}")
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error cleaning support tickets on account deletion: ${e.message}")
            }

            // 5. Delete queued mail notifications for this user
            if (userEmail.isNotBlank()) {
                try {
                    val mailDocs = db.collection("mail").whereEqualTo("to", userEmail.trim().lowercase()).get().await()
                    for (doc in mailDocs.documents) {
                        doc.reference.delete().await()
                    }
                } catch (_: Exception) {}
            }

            // 6. Delete profile image from Firebase Storage if present
            for (id in candidateUserIds) {
                try {
                    getStorageReference().child("profiles/$id/profile_picture.jpg").delete().await()
                } catch (_: Exception) {}
            }

            // 7. Delete any netero_profiles doc indexed by username directly
            if (username.isNotBlank()) {
                try {
                    db.collection("netero_profiles").document(username.trim()).delete().await()
                } catch (_: Exception) {}
                try {
                    val userDocs = db.collection("netero_profiles").whereEqualTo("username", username.trim()).get().await()
                    for (doc in userDocs.documents) {
                        doc.reference.delete().await()
                    }
                } catch (_: Exception) {}
            }

            // 4. Delete any netero_profiles doc matching this email or phone or fullName
            if (userEmail.isNotBlank()) {
                try {
                    val emailDocs = db.collection("netero_profiles").whereEqualTo("email", userEmail.trim()).get().await()
                    for (doc in emailDocs.documents) {
                        doc.reference.delete().await()
                    }
                } catch (_: Exception) {}
            }
            if (userPhone.isNotBlank()) {
                try {
                    val phoneDocs = db.collection("netero_profiles").whereEqualTo("phone", userPhone.trim()).get().await()
                    for (doc in phoneDocs.documents) {
                        doc.reference.delete().await()
                    }
                } catch (_: Exception) {}
            }
            if (fullName.isNotBlank()) {
                try {
                    val nameDocs = db.collection("netero_profiles").whereEqualTo("fullName", fullName.trim()).get().await()
                    for (doc in nameDocs.documents) {
                        doc.reference.delete().await()
                    }
                } catch (_: Exception) {}
            }

            true
        } catch (e: Exception) {
            android.util.Log.e("CloudSyncManager", "permanentlyDeleteUserFromCloud failed", e)
            false
        }
    }

    suspend fun submitSupportTicket(
        userId: String,
        userName: String,
        userEmail: String,
        userPhone: String,
        subject: String,
        message: String
    ): Pair<Boolean, String> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext Pair(false, "")
        val randomNum = (1000..9999).random()
        val ticketId = "NETERO-HELP-$randomNum"
        val docId = "ticket_${System.currentTimeMillis()}"
        return@withContext try {
            val ticketData = hashMapOf(
                "id" to docId,
                "ticketId" to ticketId,
                "userId" to userId,
                "userName" to userName,
                "userEmail" to userEmail.trim().lowercase(),
                "userPhone" to userPhone,
                "subject" to subject,
                "message" to message,
                "status" to "Ticket Raised",
                "supportNote" to "Your support ticket has been raised. Our team will contact you if a response is needed.",
                "timestamp" to System.currentTimeMillis()
            )
            // 1. Save to support_tickets in Firestore
            db.collection("support_tickets").document(docId).set(ticketData).await()

            // 2. Queue in Firestore 'mail' collection so email is dispatched & tracked in Firebase console
            if (userEmail.isNotBlank()) {
                val mailData = hashMapOf(
                    "to" to userEmail.trim().lowercase(),
                    "message" to hashMapOf(
                        "subject" to "[Ticket #$ticketId] NETERO Support: We received your inquiry - $subject",
                        "text" to "Hi $userName,\n\nWe have received your support inquiry (Ticket #$ticketId):\n\nSubject: $subject\nMessage: $message\n\nOur team is reviewing it and will respond to this email address within 15 minutes.\n\nBest,\nThe NETERO Support Team",
                        "html" to """
                            <div style="font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; max-width: 580px; margin: 0 auto; padding: 24px; border: 1px solid #e2e8f0; border-radius: 12px;">
                                <h2 style="color: #0A66C2; margin-top: 0;">NETERO Support Ticket Created</h2>
                                <p style="font-size: 15px; color: #334155;">Hi <strong>$userName</strong>,</p>
                                <p style="color: #475569; font-size: 14px;">We have received your support request. Our engineering and support team is actively reviewing your issue.</p>
                                <div style="background-color: #f8fafc; border-left: 4px solid #0A66C2; padding: 16px; margin: 20px 0; border-radius: 4px;">
                                    <p style="margin: 0 0 6px 0; font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: bold;">Ticket ID</p>
                                    <p style="margin: 0 0 12px 0; font-size: 16px; font-weight: bold; color: #0A66C2;">#$ticketId</p>
                                    <p style="margin: 0 0 6px 0; font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: bold;">Subject</p>
                                    <p style="margin: 0 0 12px 0; font-size: 14px; color: #1e293b;">$subject</p>
                                    <p style="margin: 0 0 6px 0; font-size: 12px; color: #64748b; text-transform: uppercase; font-weight: bold;">Your Inquiry</p>
                                    <p style="margin: 0; font-size: 14px; color: #334155; white-space: pre-wrap;">$message</p>
                                </div>
                                <p style="font-size: 14px; color: #475569;">Our support team will reply directly to this email address (<strong>$userEmail</strong>). You can also monitor your ticket status anytime in the NETERO Help Desk inside the app.</p>
                                <hr style="border: none; border-top: 1px solid #e2e8f0; margin: 24px 0;" />
                                <p style="font-size: 12px; color: #94a3b8; margin: 0;">NETERO Help Desk &bull; netero.support@gmail.com</p>
                            </div>
                        """.trimIndent()
                    ),
                    "timestamp" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                )
                db.collection("mail").add(mailData)
            }

            // 3. Also dispatch via direct SMTP
            try {
                EmailOtpService.sendSupportTicketEmail(
                    userEmail = userEmail,
                    userName = userName,
                    ticketId = ticketId,
                    subject = subject,
                    message = message
                )
            } catch (_: Exception) {}

            Pair(true, ticketId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to submit support ticket", e)
            Pair(false, "")
        }
    }

    suspend fun fetchSupportTickets(userId: String, userEmail: String): List<com.example.data.model.SupportTicket> = withContext(Dispatchers.IO) {
        val db = firestore ?: return@withContext emptyList()
        return@withContext try {
            val list = mutableListOf<com.example.data.model.SupportTicket>()
            val docsById = if (userId.isNotBlank()) {
                db.collection("support_tickets").whereEqualTo("userId", userId).get().await().documents
            } else emptyList()
            val docsByEmail = if (userEmail.isNotBlank()) {
                db.collection("support_tickets").whereEqualTo("userEmail", userEmail.trim().lowercase()).get().await().documents
            } else emptyList()

            val allDocs = (docsById + docsByEmail).distinctBy { it.id }
            for (doc in allDocs) {
                val t = com.example.data.model.SupportTicket(
                    id = doc.id,
                    ticketId = doc.getString("ticketId") ?: doc.id,
                    userId = doc.getString("userId") ?: "",
                    userName = doc.getString("userName") ?: "",
                    userEmail = doc.getString("userEmail") ?: "",
                    userPhone = doc.getString("userPhone") ?: "",
                    subject = doc.getString("subject") ?: "",
                    message = doc.getString("message") ?: "",
                    timestamp = doc.getLong("timestamp") ?: System.currentTimeMillis(),
                    status = "Ticket Raised",
                    supportNote = "Your support ticket has been raised. Our team will contact you if a response is needed."
                )
                list.add(t)
            }
            list.sortedByDescending { it.timestamp }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun listenToDiscoverFeed(userId: String, username: String = "", email: String = ""): kotlinx.coroutines.flow.Flow<List<com.example.data.model.RecommendedPerson>> = kotlinx.coroutines.flow.callbackFlow {
        val reg = firestore?.collection("netero_profiles")?.addSnapshotListener { snapshot, _ ->
            if (snapshot == null) return@addSnapshotListener
            val list = snapshot.documents.mapNotNull { doc ->
                val id = doc.id
                val name = doc.getString("fullName") ?: ""
                if (name.isBlank() || id == userId) return@mapNotNull null
                com.example.data.model.RecommendedPerson(
                    id = id,
                    name = name,
                    jobTitle = doc.getString("jobTitle") ?: "",
                    company = doc.getString("company") ?: "",
                    industry = doc.getString("industry") ?: "",
                    location = doc.getString("location") ?: "",
                    status = com.example.data.model.ConnectionStatus.NOT_CONNECTED,
                    profileImageUrl = doc.getString("profileImageUrl") ?: "",
                    avatarInitial = name.take(2).uppercase(),
                    username = doc.getString("username") ?: "",
                    email = doc.getString("email") ?: "",
                    phone = doc.getString("phone") ?: "",
                    website = doc.getString("website") ?: "",
                    linkedinUrl = doc.getString("linkedinUrl") ?: "",
                    businessUrl = doc.getString("businessUrl") ?: "",
                    portfolioUrl = doc.getString("portfolioUrl") ?: "",
                    connectionIds = (doc.get("connectionIds") as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                )
            }
            trySend(list)
        }
        awaitClose { reg?.remove() }
    }

    suspend fun setTypingStatus(userId: String, contactId: String, isTyping: Boolean) {
        try {
            firestore?.collection("users")?.document(contactId)
                ?.collection("typing")?.document(userId)
                ?.set(mapOf("isTyping" to isTyping, "timestamp" to System.currentTimeMillis()))
        } catch (_: Exception) {}
    }

    suspend fun markMessagesAsRead(userId: String, contactId: String) {
        try {
            val unread = firestore?.collection("users")?.document(userId)?.collection("chats")
                ?.whereEqualTo("contactId", contactId)
                ?.whereEqualTo("status", "Delivered")?.get()?.await()
            unread?.documents?.forEach { it.reference.update("status", "Read") }
        } catch (_: Exception) {}
    }

    fun listenToTypingStatus(userId: String, contactId: String): kotlinx.coroutines.flow.Flow<Boolean> = kotlinx.coroutines.flow.callbackFlow {
        val reg = firestore?.collection("users")?.document(userId)
            ?.collection("typing")?.document(contactId)
            ?.addSnapshotListener { snapshot, _ ->
                val isTyping = snapshot?.getBoolean("isTyping") ?: false
                trySend(isTyping)
            }
        awaitClose { reg?.remove() }
    }

    suspend fun blockUser(userId: String, contactId: String) {
        try {
            firestore?.collection("users")?.document(userId)
                ?.collection("blocked")?.document(contactId)
                ?.set(mapOf("blockedAt" to System.currentTimeMillis()))
        } catch (_: Exception) {}
    }

    suspend fun muteRoom(userId: String, roomId: String) {
        try {
            firestore?.collection("users")?.document(userId)
                ?.collection("muted_rooms")?.document(roomId)
                ?.set(mapOf("mutedAt" to System.currentTimeMillis()))
        } catch (_: Exception) {}
    }
}
