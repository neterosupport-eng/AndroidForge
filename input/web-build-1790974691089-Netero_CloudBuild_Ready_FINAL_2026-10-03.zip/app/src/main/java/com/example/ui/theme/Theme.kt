package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = LinkedInLightBlue,
    onPrimary = LinkedInDarkBg,
    primaryContainer = Color(0xFF004182),
    onPrimaryContainer = LinkedInLightBlue,
    secondary = LinkedInGreen,
    onSecondary = PureWhite,
    background = LinkedInDarkBg,
    onBackground = LinkedInTextLight,
    surface = LinkedInDarkSurface,
    onSurface = LinkedInTextLight,
    surfaceVariant = DarkSurfaceVariant,
    onSurfaceVariant = Color(0xFFB0B8C1),
    outline = DarkBorder,
    outlineVariant = DarkBorderVariant
)

private val LightColorScheme = lightColorScheme(
    primary = LinkedInBlue,
    onPrimary = PureWhite,
    primaryContainer = LightSurfaceVariant,
    onPrimaryContainer = LinkedInBlue,
    secondary = LinkedInGreen,
    onSecondary = PureWhite,
    background = LinkedInLightBg,
    onBackground = LinkedInTextDark,
    surface = LinkedInLightSurface,
    onSurface = LinkedInTextDark,
    surfaceVariant = LightSurfaceVariant,
    onSurfaceVariant = LinkedInTextGray,
    outline = LightBorder,
    outlineVariant = LightBorder
)

@Composable
fun NeteroTheme(
    darkTheme: Boolean = isSystemInDarkTheme(), // Default to system theme, but will be overridden if state is passed
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme
    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
