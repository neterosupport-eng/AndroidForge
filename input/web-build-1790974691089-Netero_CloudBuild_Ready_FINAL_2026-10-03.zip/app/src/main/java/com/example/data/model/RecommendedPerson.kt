package com.example.data.model

enum class ConnectionStatus {
    NOT_CONNECTED,
    PENDING,
    CONNECTED
}

data class RecommendedPerson(
    val id: String = "",
    val name: String = "",
    val username: String = "",
    val jobTitle: String = "",
    val company: String = "",
    val industry: String = "",
    val location: String = "", // General city e.g. Bengaluru
    val mutualConnectionsCount: Int = 0,
    val sharedInterests: List<String> = emptyList(),
    val category: String = "Tech", // Founders, Investors, Students, Creators, Tech, etc.
    val email: String? = null,
    val phone: String? = null,
    val linkedinUrl: String? = null,
    val isContactInfoPublic: Boolean = false,
    val matchPercentage: Int = 92,
    val matchReason: String = "Industry Match • 3 Mutual Connections",
    val portfolioUrl: String? = null,
    val website: String? = null,
    val businessUrl: String? = null,
    val bio: String = "",
    val avatarInitial: String = "",
    val avatarBgHex: Long = 0xFF2962FF,
    var status: ConnectionStatus = ConnectionStatus.NOT_CONNECTED,
    val connectionIds: List<String> = emptyList(),
    val isStudent: Boolean = false,
    val profileImageUrl: String = "",
    val asteronResearchSummary: String = ""
)
