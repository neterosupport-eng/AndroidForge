package com.example.data.api

import com.google.firebase.functions.FirebaseFunctions
import kotlinx.coroutines.tasks.await

/**
 * App-facing email service. OTP generation, Gmail credentials, rate limiting,
 * storage and verification live in Firebase Functions; no mail credentials are
 * shipped inside the Android binary.
 */
object EmailOtpService {
    private val functions by lazy { FirebaseFunctions.getInstance() }

    suspend fun sendEmailOtp(email: String): Boolean {
        val normalized = email.trim().lowercase()
        if (normalized.isBlank()) return false
        return try {
            val result = functions.getHttpsCallable("sendNeteroOtp")
                .call(mapOf("email" to normalized))
                .await()
            (result.data as? Map<*, *>)?.get("ok") == true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun verifyEmailOtp(email: String, otpCode: String): Boolean {
        val normalized = email.trim().lowercase()
        val code = otpCode.trim()
        if (normalized.isBlank() || code.length != 6) return false
        return try {
            val result = functions.getHttpsCallable("verifyNeteroOtp")
                .call(mapOf("email" to normalized, "code" to code))
                .await()
            (result.data as? Map<*, *>)?.get("ok") == true
        } catch (_: Exception) {
            false
        }
    }

    suspend fun sendSupportTicketEmail(
        userEmail: String,
        userName: String,
        ticketId: String,
        subject: String,
        message: String
    ): Boolean {
        return try {
            val result = functions.getHttpsCallable("sendNeteroSupportEmail")
                .call(
                    mapOf(
                        "userEmail" to userEmail.trim().lowercase(),
                        "userName" to userName,
                        "ticketId" to ticketId,
                        "subject" to subject,
                        "message" to message
                    )
                )
                .await()
            (result.data as? Map<*, *>)?.get("ok") == true
        } catch (_: Exception) {
            false
        }
    }
}
