package com.example.data.model

data class AiLearnedProfile(
    val learnedInterests: List<String> = emptyList(),
    val recentSearchQueries: List<String> = emptyList(),
    val targetIndustries: List<String> = emptyList(),
    val targetRoles: List<String> = emptyList(),
    val aiNetworkingPersona: String = "",
    val aiTargetSynergies: List<String> = emptyList(),
    val lastAnalyzedTimestamp: Long = 0L
)
