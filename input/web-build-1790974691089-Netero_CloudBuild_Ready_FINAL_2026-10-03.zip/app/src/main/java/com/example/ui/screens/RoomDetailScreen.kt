package com.example.ui.screens

import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material.icons.filled.School
import android.widget.Toast
import android.content.Context
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.ui.platform.LocalContext
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.TextButton
import androidx.compose.foundation.Image
import androidx.compose.ui.graphics.asImageBitmap
import android.content.Intent
import android.net.Uri
import com.example.utils.QrCodeGenerator
import androidx.compose.ui.text.style.TextOverflow

import androidx.compose.material.icons.filled.RemoveModerator

import com.example.data.model.RoomType

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.AttachFile
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Block
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Group
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.PersonAdd
import androidx.compose.material.icons.filled.DateRange

import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.People
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Close
import androidx.compose.foundation.gestures.detectTransformGestures
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll

import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Room
import com.example.data.model.RoomDiscussion
import com.example.data.model.RoomMember
import com.example.data.model.RoomOpportunity
import com.example.data.model.RoomSpeaker
import com.example.data.model.UserProfile
import com.example.ui.theme.AccentBlue
import com.example.data.model.ConnectionContact

import androidx.compose.runtime.rememberCoroutineScope
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun RoomDetailScreen(
    room: Room,
    connectionsList: List<ConnectionContact>,
    onNavigateBack: () -> Unit,
    onToggleJoinRoom: (String) -> Unit,
    onPostDiscussion: (String, String) -> Unit,
    onPostDiscussionAttachment: (String, String, android.net.Uri, String, String?, String?) -> Unit = {_,_,_,_,_,_->},
    onConnectMember: (String, String) -> Unit = { _, _ -> },
    onDeleteRoom: (String) -> Unit,
    onRemoveMember: (String) -> Unit,
    onAcceptRequest: (String, String) -> Unit = { _, _ -> },
    onDenyRequest: (String, String) -> Unit = { _, _ -> },
    onToggleAdminOnlyChat: (String) -> Unit = {},
    onToggleRoomPrivacy: (String) -> Unit = {},
    onToggleAdmin: (String, String) -> Unit = { _, _ -> },
    onPostOpportunity: (RoomOpportunity) -> Unit = {},
    onDeleteOpportunity: (String) -> Unit = {},
    onDeleteDisc: (String) -> Unit = {},
    currentUserName: String = "",
    onMakeSpeaker: (String, String) -> Unit = { _, _ -> },
    onRemoveSpeaker: (String, String) -> Unit = { _, _ -> },
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {},
    userProfile: UserProfile? = null,
    onNavigateToChat: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableStateOf(0) }
    var noteDialogTarget by remember { mutableStateOf<Pair<String, String>?>(null) }
    var fullScreenImageUrl by remember { mutableStateOf<String?>(null) }
    val tabs = listOf("People", "Speakers", "Chat", "Jobs")
    val context = LocalContext.current
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    val cloudSync = remember { com.example.data.api.CloudSyncManager() }
    var discussionInput by remember { mutableStateOf("") }
    var selectedMemberForSheet by remember { mutableStateOf<RoomMember?>(null) }
    var memberFullProfile by remember { mutableStateOf<UserProfile?>(null) }
    val scope = rememberCoroutineScope()
    var generatedResearch by remember { mutableStateOf<String?>(null) }
    var isGeneratingResearch by remember { mutableStateOf(false) }

    androidx.compose.runtime.LaunchedEffect(selectedMemberForSheet) {
        generatedResearch = null
        isGeneratingResearch = false
        memberFullProfile = null
        if (selectedMemberForSheet != null) {
            val mem = selectedMemberForSheet!!
            try {
                val profiles = cloudSync.fetchLiveProfiles(listOf(mem.id))
                memberFullProfile = profiles[mem.id]
            } catch (_: Exception) {}
        }
    }
    
    var showRoomMenu by remember { mutableStateOf(false) }
    var showRoomQrDialog by remember { mutableStateOf(false) }

    var showExitRoom1 by remember { mutableStateOf(false) }
    var showExitRoom2 by remember { mutableStateOf(false) }
    var showDeleteRoom1 by remember { mutableStateOf(false) }
    var showDeleteRoom2 by remember { mutableStateOf(false) }
    var showRemoveMember1 by remember { mutableStateOf(false) }
    var showRemoveMember2 by remember { mutableStateOf(false) }
    var showMemberMenu by remember { mutableStateOf(false) }
    var showMakeAdmin1 by remember { mutableStateOf(false) }
    var showMakeAdmin2 by remember { mutableStateOf(false) }
    var showMakeSpeaker1 by remember { mutableStateOf(false) }
    var showMakeSpeaker2 by remember { mutableStateOf(false) }
    var showAddPeopleSheet by remember { mutableStateOf(false) }
    var showRequestsSheet by remember { mutableStateOf(false) }
    var memberToRemove by remember { mutableStateOf("") }
    var memberToModify by remember { mutableStateOf("") }
    var opportunityToDelete by remember { mutableStateOf("") }
    var showDeleteOpportunity1 by remember { mutableStateOf(false) }
    var showDeleteOpportunity2 by remember { mutableStateOf(false) }
    var speakerToRemove by remember { mutableStateOf("") }
    var showRemoveSpeaker1 by remember { mutableStateOf(false) }
    var showRemoveSpeaker2 by remember { mutableStateOf(false) }
    var showMutualConnections by remember { mutableStateOf(false) }
    var isProfileHiddenInRoom by remember(room.id) { mutableStateOf(false) }
    
    var showAiSummaryDialog by remember { mutableStateOf(false) }
    var aiSummaryText by remember { mutableStateOf<String?>(null) }
    var isGeneratingSummary by remember { mutableStateOf(false) }

    val currentAuthUid = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: ""
    val currentProfileId = userProfile?.id ?: ""
    val currentUsername = userProfile?.username ?: ""
    val currentFullName = userProfile?.fullName ?: currentUserName
    val isCurrentUserAdmin = room.isCreatedByMe || 
        (currentAuthUid.isNotBlank() && room.adminId == currentAuthUid) ||
        (currentProfileId.isNotBlank() && room.adminId == currentProfileId) ||
        (currentUsername.isNotBlank() && room.adminId.equals(currentUsername, ignoreCase = true)) ||
        (currentFullName.isNotBlank() && room.adminId.equals(currentFullName, ignoreCase = true)) ||
        room.members.any { m ->
            m.isAdmin && (
                (currentAuthUid.isNotBlank() && m.id == currentAuthUid) ||
                (currentProfileId.isNotBlank() && m.id == currentProfileId) ||
                (currentUsername.isNotBlank() && m.id.equals(currentUsername, ignoreCase = true)) ||
                (currentFullName.isNotBlank() && m.name.equals(currentFullName, ignoreCase = true))
            )
        } ||
        room.speakers.any { s ->
            s.isAdmin && (
                (currentAuthUid.isNotBlank() && s.id == currentAuthUid) ||
                (currentProfileId.isNotBlank() && s.id == currentProfileId) ||
                (currentUsername.isNotBlank() && s.id.equals(currentUsername, ignoreCase = true)) ||
                (currentFullName.isNotBlank() && s.name.equals(currentFullName, ignoreCase = true))
            )
        }

    val isCurrentUserSpeaker = isCurrentUserAdmin ||
        room.speakers.any { s ->
            (currentAuthUid.isNotBlank() && s.id == currentAuthUid) ||
            (currentProfileId.isNotBlank() && s.id == currentProfileId) ||
            (currentUsername.isNotBlank() && s.id.equals(currentUsername, ignoreCase = true)) ||
            (currentFullName.isNotBlank() && s.name.equals(currentFullName, ignoreCase = true))
        } ||
        room.members.any { m ->
            m.isSpeaker && (
                (currentAuthUid.isNotBlank() && m.id == currentAuthUid) ||
                (currentProfileId.isNotBlank() && m.id == currentProfileId) ||
                (currentUsername.isNotBlank() && m.id.equals(currentUsername, ignoreCase = true)) ||
                (currentFullName.isNotBlank() && m.name.equals(currentFullName, ignoreCase = true))
            )
        }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = room.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground,
                        maxLines = 1
                    )
                },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack, modifier = Modifier.testTag("back_button")) {
                        Icon(imageVector = Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back", tint = MaterialTheme.colorScheme.onBackground)
                    }
                },
                actions = {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(end = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Button(
                            onClick = { 
                                if (room.isJoined) {
                                    showExitRoom1 = true
                                } else {
                                    onToggleJoinRoom(room.id)
                                }
                            },
                            modifier = Modifier.height(36.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (room.isJoined) MaterialTheme.colorScheme.error.copy(alpha = 0.15f) else if (room.isJoinRequested) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.2f) else AccentBlue,
                                contentColor = if (room.isJoined) MaterialTheme.colorScheme.error else if (room.isJoinRequested) MaterialTheme.colorScheme.onSurfaceVariant else Color.White
                            )
                        ) {
                            Text(if (room.isJoined) "Exit Room" else if (room.isJoinRequested) "Requested" else "Join Room", style = MaterialTheme.typography.labelSmall)
                        }
                        
                        if (isCurrentUserAdmin) {
                            IconButton(onClick = { showAddPeopleSheet = true }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.PersonAdd, "Add People", tint = MaterialTheme.colorScheme.onBackground)
                            }
                        }
                        
                        IconButton(
                            onClick = {
                                showAiSummaryDialog = true
                                if (!isGeneratingSummary) {
                                    isGeneratingSummary = true
                                    scope.launch {
                                        val summary = com.example.data.api.GeminiAiHelper.summarizeRoomDiscussions(
                                            roomName = room.name,
                                            messages = room.discussions.map { it.authorName to it.content }
                                        )
                                        aiSummaryText = summary
                                        isGeneratingSummary = false
                                    }
                                }
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(Icons.Default.AutoAwesome, "AI Discussion Recap", tint = AccentBlue)
                        }

                        Box {
                            IconButton(onClick = { showRoomMenu = true }, modifier = Modifier.size(36.dp)) {
                                Icon(Icons.Default.MoreVert, "More Options", tint = MaterialTheme.colorScheme.onBackground)
                            }
                            DropdownMenu(
                                expanded = showRoomMenu,
                                onDismissRequest = { showRoomMenu = false }
                            ) {
                                if (isCurrentUserAdmin || room.type == RoomType.PUBLIC) {
                                    DropdownMenuItem(
                                        text = { Text("Invite via QR Code") },
                                        onClick = { 
                                            showRoomMenu = false
                                            showRoomQrDialog = true
                                        },
                                        leadingIcon = { Icon(Icons.Default.QrCode, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Share Invite Link") },
                                        onClick = {
                                            showRoomMenu = false
                                            val intent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(Intent.EXTRA_TEXT, "Join the networking room '${room.name}' on Netero!\nDownload app: https://play.google.com/store/apps/details?id=com.aistudio.netero.network.xpkq\nRoom code: ${room.id}")
                                            }
                                            context.startActivity(Intent.createChooser(intent, "Share Room"))
                                        },
                                        leadingIcon = { Icon(Icons.Default.Share, null) }
                                    )
                                }
                                if (room.isCreatedByMe) {
                                    DropdownMenuItem(
                                        text = { Text("Join Requests (${room.joinRequests.size})") },
                                        onClick = { 
                                            showRoomMenu = false
                                            showRequestsSheet = true
                                        },
                                        leadingIcon = { Icon(Icons.Default.Group, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (room.type == com.example.data.model.RoomType.PRIVATE) "Make Room Public" else "Make Room Private") },
                                        onClick = { 
                                            showRoomMenu = false
                                            onToggleRoomPrivacy(room.id)
                                        },
                                        leadingIcon = { Icon(if (room.type == com.example.data.model.RoomType.PRIVATE) Icons.Default.LockOpen else Icons.Default.Lock, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text(if (room.onlyAdminsCanChat) "Enable Open Chat" else "Admins Only Chat") },
                                        onClick = { 
                                            showRoomMenu = false
                                            onToggleAdminOnlyChat(room.id)
                                        },
                                        leadingIcon = { Icon(Icons.AutoMirrored.Filled.Chat, null) }
                                    )
                                    DropdownMenuItem(
                                        text = { Text("Delete Room", color = MaterialTheme.colorScheme.error) },
                                        onClick = { 
                                            showRoomMenu = false
                                            showDeleteRoom1 = true
                                        },
                                        leadingIcon = { Icon(Icons.Default.Delete, null, tint = MaterialTheme.colorScheme.error) }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text(if (isProfileHiddenInRoom) "Show My Profile in Room" else "Hide My Profile in Room (Incognito)") },
                                    onClick = {
                                        showRoomMenu = false
                                        isProfileHiddenInRoom = !isProfileHiddenInRoom
                                        android.widget.Toast.makeText(context, if (isProfileHiddenInRoom) "Profile hidden from room members" else "Profile visible in room", android.widget.Toast.LENGTH_SHORT).show()
                                    },
                                    leadingIcon = { Icon(Icons.Default.People, null) }
                                )
                            }
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            // Header Info Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .border(0.5.dp, MaterialTheme.colorScheme.outline)
                    .padding(18.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(text = room.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f))
                    Spacer(modifier = Modifier.height(8.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                        if (room.startDate.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(4.dp))
                                Text("${room.startDate} ${room.startTime}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                        if (room.endDate.isNotBlank()) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text("to", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Spacer(Modifier.width(8.dp))
                                Icon(Icons.Default.DateRange, contentDescription = null, modifier = Modifier.size(16.dp), tint = MaterialTheme.colorScheme.primary)
                                Spacer(Modifier.width(4.dp))
                                Text("${room.endDate} ${room.endTime}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                }
            }

            // Tabs
            TabRow(
                selectedTabIndex = selectedTabIndex,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = MaterialTheme.colorScheme.primary,
                indicator = { tabPositions ->
                    TabRowDefaults.SecondaryIndicator(
                        modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = MaterialTheme.colorScheme.primary
                    )
                }
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = selectedTabIndex == index,
                        onClick = { selectedTabIndex = index },
                        text = {
                            Text(
                                text = title,
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Normal),
                                color = if (selectedTabIndex == index) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                            )
                        }
                    )
                }
            }

            // Tab Content
            Box(modifier = Modifier.weight(1f).padding(horizontal = 20.dp, vertical = 12.dp)) {
                when (selectedTabIndex) {
                    0 -> RoomMembersList(
                        roomName = room.name,
                        roomCategory = room.type.label,
                        members = if (isProfileHiddenInRoom) room.members.filter { it.name != currentUserName && it.id != (userProfile?.id ?: "") } else room.members,
                        userProfile = userProfile,
                        onConnect = { memberId ->
                            val m = room.members.find { it.id == memberId }
                            noteDialogTarget = Pair(memberId, m?.name ?: "Member")
                        },
                        onMemberClick = { selectedMemberForSheet = it }
                    )
                    1 -> RoomSpeakersList(
                        speakers = room.speakers, 
                        isAdmin = isCurrentUserAdmin,
                        currentUserName = currentUserName,
                        onRemoveSpeaker = { sId -> speakerToRemove = sId; showRemoveSpeaker1 = true },
                        onConnect = { speakerId ->
                            val s = room.speakers.find { it.id == speakerId }
                            noteDialogTarget = Pair(speakerId, s?.name ?: "Speaker")
                        },
                        onSpeakerClick = { sId -> 
                            val member = room.members.find { it.id == sId }
                            if (member != null) {
                                selectedMemberForSheet = member
                            } else {
                                val speaker = room.speakers.find { it.id == sId }
                                if (speaker != null) {
                                    selectedMemberForSheet = RoomMember(
                                        id = speaker.id,
                                        name = speaker.name,
                                        jobTitle = speaker.jobTitle,
                                        company = speaker.company,
                                        category = "Speakers",
                                        isConnected = speaker.isConnected,
                                        avatarInitial = speaker.avatarInitial,
                                        avatarBgHex = speaker.avatarBgHex,
                                        isAdmin = speaker.isAdmin,
                                        isSpeaker = true
                                    )
                                }
                            }
                        }
                    )
                    2 -> RoomDiscussionsList(
                        discussions = room.discussions,
                        inputText = discussionInput,
                        onInputChanged = { discussionInput = it },
                        onPost = {
                            onPostDiscussion(room.id, discussionInput)
                            discussionInput = ""
                        },
                        onlyAdminsCanChat = room.onlyAdminsCanChat,
                        isAdmin = isCurrentUserAdmin,
                        currentUserId = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: "user_id_123",
                        onDeleteDisc = onDeleteDisc,
                        onSendAttachment = { uri, type, mimeType, originalName ->
                            onPostDiscussionAttachment(room.id, discussionInput, uri, type, mimeType, originalName)
                            discussionInput = ""
                        },
                        onImageClick = { fullScreenImageUrl = it }
                    )
                    3 -> RoomOpportunitiesList(
                        opportunities = room.opportunities, 
                        isAdmin = isCurrentUserAdmin, 
                        onApply = {},
                        isArchived = room.isArchived,
                        onPostOpportunity = onPostOpportunity, onDeleteOpportunity = { oppId -> opportunityToDelete = oppId; showDeleteOpportunity1 = true }
                    )
                }
            }
        }
    }
    

    if (showRoomQrDialog) {
        val qrBitmap = QrCodeGenerator.generateQrCode(context, "netero://room/${room.id}", width = 600, height = 600)
        AlertDialog(
            onDismissRequest = { showRoomQrDialog = false },
            title = { Text("Room Invite QR", color = MaterialTheme.colorScheme.onBackground) },
            text = {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("Scan this code to join ${room.name}", style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "Room QR Code",
                            modifier = Modifier.size(250.dp)
                        )
                    }
                }
            },
            confirmButton = {
                Button(onClick = { showRoomQrDialog = false }) {
                    Text("Close")
                }
            },
            dismissButton = {
                androidx.compose.material3.TextButton(
                    onClick = {
                        val intent = android.content.Intent(android.content.Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(android.content.Intent.EXTRA_TEXT, "Join the networking room '${room.name}' on Netero!\nDownload app: https://play.google.com/store/apps/details?id=com.aistudio.netero.network.xpkq\nRoom code: ${room.id}")
                        }
                        context.startActivity(android.content.Intent.createChooser(intent, "Share Room"))
                    }
                ) {
                    Icon(androidx.compose.material.icons.Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Share Code")
                }
            }
        )
    }

    if (showAiSummaryDialog) {
        val clipboardManager = androidx.compose.ui.platform.LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { showAiSummaryDialog = false },
            title = {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.AutoAwesome,
                        contentDescription = null,
                        tint = AccentBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Text("Room Discussion Recap", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "Room: ${room.name}",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold),
                        color = MaterialTheme.colorScheme.primary
                    )

                    if (isGeneratingSummary) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            CircularProgressIndicator(
                                color = AccentBlue,
                                modifier = Modifier.size(36.dp),
                                strokeWidth = 3.dp
                            )
                            Text(
                                text = "Synthesizing discussions with Asteron AI...",
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    } else {
                        Text(
                            text = aiSummaryText ?: "No summary generated yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            },
            confirmButton = {
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    if (aiSummaryText != null && !isGeneratingSummary) {
                        androidx.compose.material3.TextButton(
                            onClick = {
                                clipboardManager.setText(androidx.compose.ui.text.AnnotatedString(aiSummaryText ?: ""))
                                android.widget.Toast.makeText(context, "Summary copied to clipboard!", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Copy")
                        }
                        IconButton(
                            onClick = {
                                isGeneratingSummary = true
                                scope.launch {
                                    val summary = com.example.data.api.GeminiAiHelper.summarizeRoomDiscussions(
                                        roomName = room.name,
                                        messages = room.discussions.map { it.authorName to it.content }
                                    )
                                    aiSummaryText = summary
                                    isGeneratingSummary = false
                                }
                            }
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Regenerate", tint = AccentBlue)
                        }
                    }
                    Button(
                        onClick = { showAiSummaryDialog = false },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        Text("Done")
                    }
                }
            },
            dismissButton = null
        )
    }

    if (selectedMemberForSheet != null) {
        val member = selectedMemberForSheet!!
        val connectedContact = connectionsList.find { 
            it.id == member.id || 
            it.name.equals(member.name, ignoreCase = true) ||
            it.id.removePrefix("c_").removePrefix("req_") == member.id.removePrefix("c_").removePrefix("req_")
        }
        val isAlreadyConnected = connectedContact != null && !connectedContact.tags.contains("PENDING_CONNECT_BACK")

        ModalBottomSheet(
            onDismissRequest = { selectedMemberForSheet = null },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(horizontal = 24.dp, vertical = 16.dp)
                    .padding(bottom = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Profile Header with Avatar & Details
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(68.dp)
                            .clip(CircleShape)
                            .background(Color(member.avatarBgHex)),
                        contentAlignment = Alignment.Center
                    ) {
                        val profilePic = memberFullProfile?.profileImageUrl
                        if (!profilePic.isNullOrBlank()) {
                            coil.compose.AsyncImage(
                                model = com.example.utils.AttachmentHelper.getDisplayableImageModel(profilePic),
                                contentDescription = "Profile Photo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        } else {
                            Text(
                                text = member.avatarInitial,
                                color = Color.White,
                                style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                            )
                        }
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = member.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Text(
                            text = "${member.jobTitle} • ${member.company}",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp),
                            modifier = Modifier.padding(top = 4.dp)
                        ) {
                            Icon(
                                Icons.Default.LocationOn,
                                contentDescription = null,
                                modifier = Modifier.size(14.dp),
                                tint = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = memberFullProfile?.location?.takeIf { it.isNotBlank() } ?: member.company,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Row(
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(top = 6.dp)
                        ) {
                            if (member.isAdmin) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(AccentBlue)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        "ADMIN",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                            }
                            if (member.isSpeaker) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(Color(0xFF651FFF))
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        "SPEAKER",
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                                        color = Color.White
                                    )
                                }
                            }
                            val categoryLabel = memberFullProfile?.industry?.takeIf { it.isNotBlank() } ?: member.category
                            if (categoryLabel.isNotBlank() && categoryLabel != "General") {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(4.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(horizontal = 6.dp, vertical = 2.dp)
                                ) {
                                    Text(
                                        categoryLabel,
                                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                        }
                    }
                    if (isCurrentUserAdmin) {
                        Box {
                            IconButton(onClick = { showMemberMenu = true }) {
                                Icon(Icons.Default.MoreVert, "More Options", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            DropdownMenu(
                                expanded = showMemberMenu,
                                onDismissRequest = { showMemberMenu = false }
                            ) {
                                DropdownMenuItem(
                                    text = { Text(if (member.isAdmin) "Demote from Admin" else "Promote to Admin") },
                                    onClick = { 
                                        showMemberMenu = false
                                        memberToModify = member.id
                                        showMakeAdmin1 = true
                                    }
                                )
                                if (!member.isSpeaker) {
                                    DropdownMenuItem(
                                        text = { Text("Make Speaker") },
                                        onClick = { 
                                            showMemberMenu = false
                                            memberToModify = member.id
                                            showMakeSpeaker1 = true
                                        }
                                    )
                                } else {
                                    DropdownMenuItem(
                                        text = { Text("Remove Speaker", color = MaterialTheme.colorScheme.error) },
                                        onClick = { 
                                            showMemberMenu = false
                                            speakerToRemove = member.id
                                            showRemoveSpeaker1 = true
                                        }
                                    )
                                }
                                DropdownMenuItem(
                                    text = { Text("Remove from Room", color = MaterialTheme.colorScheme.error) },
                                    onClick = { 
                                        showMemberMenu = false
                                        memberToRemove = member.id
                                        showRemoveMember1 = true
                                    }
                                )
                            }
                        }
                    }
                }

                // About / Bio Section
                val bioText = memberFullProfile?.bio?.takeIf { it.isNotBlank() } 
                    ?: "Professional active in ${room.name} networking community."
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            "About & Bio",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Text(
                            bioText,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        if (memberFullProfile?.interests?.isNotEmpty() == true) {
                            Text(
                                "Interests: " + memberFullProfile!!.interests.joinToString(", "),
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(top = 4.dp)
                            )
                        }
                    }
                }

                // AI Deep Research & Bio Insights Button
                Button(
                    onClick = {
                        if (!isGeneratingResearch) {
                            isGeneratingResearch = true
                            scope.launch {
                                val contextualIndustry = if (member.category != "Speakers" && member.category != "General" && member.category.isNotBlank()) member.category else room.name
                                generatedResearch = com.example.data.api.GeminiAiHelper.researchProfile(
                                    name = member.name,
                                    role = member.jobTitle,
                                    company = member.company,
                                    context = "Room member in '${room.name}' (${room.type.label})",
                                    industry = contextualIndustry,
                                    bio = bioText
                                )
                                isGeneratingResearch = false
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().height(44.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.tertiary.copy(alpha = 0.2f),
                        contentColor = MaterialTheme.colorScheme.tertiary
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        if (isGeneratingResearch) "✨ Researching Bio & Context..." else "✨ AI Deep Research & Insights",
                        style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                    )
                }

                if (generatedResearch != null) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(14.dp)
                    ) {
                        Text(
                            text = generatedResearch!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }

                // Public Contact Details & Links
                val linkedin = memberFullProfile?.linkedinUrl?.takeIf { it.isNotBlank() }
                val portfolio = memberFullProfile?.portfolioUrl?.takeIf { it.isNotBlank() }
                val website = memberFullProfile?.website?.takeIf { it.isNotBlank() }
                val email = memberFullProfile?.email?.takeIf { it.isNotBlank() }
                val phone = memberFullProfile?.phone?.takeIf { it.isNotBlank() }

                if (linkedin != null || portfolio != null || website != null || email != null || phone != null) {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                "Public Links & Contact",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (linkedin != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        val url = if (linkedin.startsWith("http")) linkedin else "https://www.linkedin.com/in/$linkedin"
                                        try { uriHandler.openUri(url) } catch (_: Exception) {}
                                    },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Share, contentDescription = null, tint = Color(0xFF0077B5), modifier = Modifier.size(16.dp))
                                    Text("LinkedIn Profile", style = MaterialTheme.typography.bodyMedium.copy(color = Color(0xFF0077B5), fontWeight = FontWeight.Bold))
                                }
                            }
                            if (portfolio != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        val url = if (portfolio.startsWith("http")) portfolio else "https://$portfolio"
                                        try { uriHandler.openUri(url) } catch (_: Exception) {}
                                    },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Link, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Text("Portfolio / Website", style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold))
                                }
                            }
                            if (email != null) {
                                Row(
                                    modifier = Modifier.fillMaxWidth().clickable {
                                        try { context.startActivity(Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$email"))) } catch (_: Exception) {}
                                    },
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Icon(Icons.Default.Email, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                                    Text(email, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }
                        }
                    }
                }

                // Action Buttons (Connect or Message)
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (isAlreadyConnected) {
                        Button(
                            onClick = {
                                selectedMemberForSheet = null
                                connectedContact?.let { onNavigateToChat(it.id) }
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                        ) {
                            Icon(Icons.Default.Chat, "Chat", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Send WhatsApp-Style Message", maxLines = 1, softWrap = false)
                        }
                    } else if (!member.isConnected) {
                        Button(
                            onClick = { 
                                noteDialogTarget = Pair(member.id, member.name)
                                selectedMemberForSheet = null
                            },
                            modifier = Modifier.fillMaxWidth().height(48.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                        ) {
                            Icon(Icons.Default.PersonAdd, "Connect", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(4.dp))
                            Text("Connect", maxLines = 1, softWrap = false)
                        }
                    } else {
                        OutlinedButton(
                            onClick = { },
                            enabled = false,
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        ) {
                            Icon(Icons.Default.Check, "Request Sent", modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Request Sent • Pending Approval", maxLines = 1, softWrap = false)
                        }
                    }
                }
                
                Spacer(modifier = Modifier.height(16.dp))
            }
        }

        if (noteDialogTarget != null) {
            val targetId = noteDialogTarget!!.first
            val targetName = noteDialogTarget!!.second
            var noteText by remember(noteDialogTarget) { 
                mutableStateOf("Hi $targetName, I came across your profile in '${room.name}' and would love to connect!") 
            }
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { noteDialogTarget = null },
                title = {
                    Text("Connect with $targetName", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            "Add a note to your connection request (optional):",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        OutlinedTextField(
                            value = noteText,
                            onValueChange = { if (it.length <= 300) noteText = it },
                            placeholder = { Text("Write a note...") },
                            modifier = Modifier.fillMaxWidth().height(110.dp),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Text(
                            "${noteText.length}/300",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.align(Alignment.End)
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            val id = targetId
                            val name = targetName
                            noteDialogTarget = null
                            onConnectMember(id, noteText.trim())
                            android.widget.Toast.makeText(context, "Connection request sent to $name!", android.widget.Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                    ) {
                        Text("Send Request", maxLines = 1, softWrap = false)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { noteDialogTarget = null }) {
                        Text("Cancel")
                    }
                }
            )
        }
        
        if (showMutualConnections) {
            androidx.compose.material3.AlertDialog(
                onDismissRequest = { showMutualConnections = false },
                title = { Text("Mutual Connections") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF4CAF50)), contentAlignment = Alignment.Center) { Text("R", color = Color.White) }
                            Text("Rahul Reddy")
                        }
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            Box(modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(0xFF9C27B0)), contentAlignment = Alignment.Center) { Text("S", color = Color.White) }
                            Text("Sneha Rao")
                        }
                    }
                },
                confirmButton = {
                    androidx.compose.material3.TextButton(onClick = { showMutualConnections = false }) {
                        Text("Close")
                    }
                }
            )
        }
    }

    if (showExitRoom1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showExitRoom1 = false },
            title = { Text("Leave Room?") },
            text = { Text("Are you sure you want to leave this room?") },
            confirmButton = { Button(onClick = { showExitRoom1 = false; showExitRoom2 = true }) { Text("Leave") } },
            dismissButton = { OutlinedButton(onClick = { showExitRoom1 = false }) { Text("Cancel") } }
        )
    }
    if (showExitRoom2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showExitRoom2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Do you really want to leave this room? This is your final confirmation.") },
            confirmButton = { Button(onClick = { showExitRoom2 = false; onToggleJoinRoom(room.id) }) { Text("Yes, Leave") } },
            dismissButton = { OutlinedButton(onClick = { showExitRoom2 = false }) { Text("Cancel") } }
        )
    }

    if (showDeleteRoom1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteRoom1 = false },
            title = { Text("Delete Room?") },
            text = { Text("Are you sure you want to delete this room?") },
            confirmButton = { Button(onClick = { showDeleteRoom1 = false; showDeleteRoom2 = true }) { Text("Delete") } },
            dismissButton = { OutlinedButton(onClick = { showDeleteRoom1 = false }) { Text("Cancel") } }
        )
    }
    if (showDeleteRoom2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteRoom2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Do you really want to delete this room? This is your final confirmation.") },
            confirmButton = { Button(onClick = { showDeleteRoom2 = false; onDeleteRoom(room.id); onNavigateBack() }) { Text("Yes, Delete") } },
            dismissButton = { OutlinedButton(onClick = { showDeleteRoom2 = false }) { Text("Cancel") } }
        )
    }

    if (showRemoveMember1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRemoveMember1 = false },
            title = { Text("Remove Member?") },
            text = { Text("Are you sure you want to remove this member from the room?") },
            confirmButton = { Button(onClick = { showRemoveMember1 = false; showRemoveMember2 = true }) { Text("Remove") } },
            dismissButton = { OutlinedButton(onClick = { showRemoveMember1 = false }) { Text("Cancel") } }
        )
    }
    if (showRemoveMember2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRemoveMember2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Do you really want to remove this member? This is your final confirmation.") },
            confirmButton = { Button(onClick = { showRemoveMember2 = false; onRemoveMember(memberToRemove); selectedMemberForSheet = null }) { Text("Yes, Remove") } },
            dismissButton = { OutlinedButton(onClick = { showRemoveMember2 = false }) { Text("Cancel") } }
        )
    }

    if (showMakeAdmin1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showMakeAdmin1 = false },
            title = { Text("Modify Admin Privileges?") },
            text = { Text("Are you sure you want to change this person's admin status?") },
            confirmButton = { Button(onClick = { showMakeAdmin1 = false; showMakeAdmin2 = true }) { Text("Confirm") } },
            dismissButton = { OutlinedButton(onClick = { showMakeAdmin1 = false }) { Text("Cancel") } }
        )
    }

    if (showMakeAdmin2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showMakeAdmin2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Are you absolutely sure you want to change their admin privileges?") },
            confirmButton = { Button(onClick = { showMakeAdmin2 = false; onToggleAdmin(room.id, memberToModify); selectedMemberForSheet = null }) { Text("Yes, Confirm") } },
            dismissButton = { OutlinedButton(onClick = { showMakeAdmin2 = false }) { Text("Cancel") } }
        )
    }

    if (showMakeSpeaker1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showMakeSpeaker1 = false },
            title = { Text("Make Speaker?") },
            text = { Text("Are you sure you want to make this person a speaker?") },
            confirmButton = { Button(onClick = { showMakeSpeaker1 = false; showMakeSpeaker2 = true }) { Text("Make Speaker") } },
            dismissButton = { OutlinedButton(onClick = { showMakeSpeaker1 = false }) { Text("Cancel") } }
        )
    }

    if (showMakeSpeaker2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showMakeSpeaker2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Are you absolutely sure you want to give them speaking rights?") },
            confirmButton = { Button(onClick = { showMakeSpeaker2 = false; onMakeSpeaker(room.id, memberToModify); selectedMemberForSheet = null }) { Text("Yes, Make Speaker") } },
            dismissButton = { OutlinedButton(onClick = { showMakeSpeaker2 = false }) { Text("Cancel") } }
        )
    }

    if (showRemoveSpeaker1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRemoveSpeaker1 = false },
            title = { Text("Remove Speaker?") },
            text = { Text("Are you sure you want to remove this person as a speaker?") },
            confirmButton = { Button(onClick = { showRemoveSpeaker1 = false; showRemoveSpeaker2 = true }) { Text("Remove Speaker") } },
            dismissButton = { OutlinedButton(onClick = { showRemoveSpeaker1 = false }) { Text("Cancel") } }
        )
    }

    if (showRemoveSpeaker2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showRemoveSpeaker2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Are you absolutely sure you want to revoke their speaking rights?") },
            confirmButton = { Button(onClick = { showRemoveSpeaker2 = false; onRemoveSpeaker(room.id, speakerToRemove); selectedMemberForSheet = null }) { Text("Yes, Remove Speaker") } },
            dismissButton = { OutlinedButton(onClick = { showRemoveSpeaker2 = false }) { Text("Cancel") } }
        )
    }

    if (showDeleteOpportunity1) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteOpportunity1 = false },
            title = { Text("Delete Opportunity?") },
            text = { Text("Are you sure you want to delete this opportunity?") },
            confirmButton = { Button(onClick = { showDeleteOpportunity1 = false; showDeleteOpportunity2 = true }) { Text("Delete") } },
            dismissButton = { OutlinedButton(onClick = { showDeleteOpportunity1 = false }) { Text("Cancel") } }
        )
    }

    if (showDeleteOpportunity2) {
        androidx.compose.material3.AlertDialog(
            onDismissRequest = { showDeleteOpportunity2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("Are you absolutely sure you want to delete this? This action cannot be undone.") },
            confirmButton = { Button(onClick = { showDeleteOpportunity2 = false; onDeleteOpportunity(opportunityToDelete) }) { Text("Yes, Delete") } },
            dismissButton = { OutlinedButton(onClick = { showDeleteOpportunity2 = false }) { Text("Cancel") } }
        )
    }

    if (showAddPeopleSheet) {
        var addSearchQuery by remember { mutableStateOf("") }
        var sentInvites by remember { mutableStateOf(setOf<String>()) }

        ModalBottomSheet(
            onDismissRequest = { showAddPeopleSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)) {
                Text("Add people from your connections", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(16.dp))
                
                OutlinedTextField(
                    value = addSearchQuery,
                    onValueChange = { addSearchQuery = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Search connections...") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                    singleLine = true,
                    shape = RoundedCornerShape(12.dp)
                )
                Spacer(modifier = Modifier.height(16.dp))
                
                val displayConnections = if (addSearchQuery.isEmpty()) connectionsList else connectionsList.filter { it.name.contains(addSearchQuery, ignoreCase = true) }
                
                if (displayConnections.isEmpty()) {
                    Text("No connections to invite.", color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(vertical = 24.dp))
                } else {
                    LazyColumn(modifier = Modifier.heightIn(max = 300.dp)) {
                        items(displayConnections) { contact ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(contact.name, style = MaterialTheme.typography.bodyLarge)
                                val isSent = sentInvites.contains(contact.id)
                                Button(
                                    onClick = { sentInvites = sentInvites + contact.id },
                                    enabled = !isSent,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = if (isSent) MaterialTheme.colorScheme.surfaceVariant else AccentBlue,
                                        disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant,
                                        disabledContentColor = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                ) { 
                                    if (isSent) {
                                        Icon(Icons.Default.Check, "Sent", modifier = Modifier.size(16.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Invite Sent")
                                    } else {
                                        Text("Invite")
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (showRequestsSheet) {
        ModalBottomSheet(
            onDismissRequest = { showRequestsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp)) {
                Text("Join Requests", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold))
                Spacer(modifier = Modifier.height(16.dp))
                if (room.joinRequests.isEmpty()) {
                    Text("No pending requests.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else {
                    LazyColumn {
                        items(room.joinRequests) { req ->
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Box(
                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color(req.avatarBgHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = req.avatarInitial, style = MaterialTheme.typography.titleMedium, color = Color.White)
                                    }
                                    Column {
                                        Text(req.name, style = MaterialTheme.typography.bodyLarge.copy(fontWeight = FontWeight.SemiBold))
                                        Text(req.jobTitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    IconButton(onClick = { onAcceptRequest(room.id, req.id) }) {
                                        Icon(Icons.Default.Check, "Accept", tint = AccentBlue)
                                    }
                                    IconButton(onClick = { onDenyRequest(room.id, req.id) }) {
                                        Icon(Icons.Default.Delete, "Deny", tint = MaterialTheme.colorScheme.error)
                                    }
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    if (fullScreenImageUrl != null) {
        androidx.compose.ui.window.Dialog(
            onDismissRequest = { fullScreenImageUrl = null },
            properties = androidx.compose.ui.window.DialogProperties(
                usePlatformDefaultWidth = false,
                dismissOnBackPress = true,
                dismissOnClickOutside = true
            )
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.95f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 24.dp)
                        .align(Alignment.TopCenter),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { fullScreenImageUrl = null }) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color.White,
                            modifier = Modifier.size(28.dp)
                        )
                    }
                    Text(
                        text = "Photo",
                        color = Color.White,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(Modifier.size(48.dp))
                }

                var scale by remember { mutableStateOf(1f) }
                var offset by remember { mutableStateOf(androidx.compose.ui.geometry.Offset.Zero) }

                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(vertical = 70.dp)
                        .pointerInput(Unit) {
                            detectTransformGestures { _, pan, zoom, _ ->
                                scale = (scale * zoom).coerceIn(1f, 4f)
                                if (scale > 1f) {
                                    offset += pan
                                } else {
                                    offset = androidx.compose.ui.geometry.Offset.Zero
                                }
                            }
                        },
                    contentAlignment = Alignment.Center
                ) {
                    coil.compose.AsyncImage(
                        model = com.example.utils.AttachmentHelper.getDisplayableImageModel(fullScreenImageUrl),
                        contentDescription = "Full Screen Photo",
                        modifier = Modifier
                            .fillMaxSize()
                            .graphicsLayer(
                                scaleX = scale,
                                scaleY = scale,
                                translationX = offset.x,
                                translationY = offset.y
                            ),
                        contentScale = androidx.compose.ui.layout.ContentScale.Fit
                    )
                }
            }
        }
    }
}

@Composable
private fun RoomMembersList(
    roomName: String = "",
    roomCategory: String = "",
    members: List<RoomMember>,
    userProfile: UserProfile? = null,
    onConnect: (String) -> Unit,
    onMemberClick: (RoomMember) -> Unit
) {
    val sortedMembers = remember(members, userProfile) {
        if (userProfile == null || members.isEmpty()) {
            members
        } else {
            val userKeywords = (userProfile.interests + listOf(userProfile.industry, userProfile.jobTitle, userProfile.company))
                .flatMap { it.lowercase().split(Regex("[^a-zA-Z0-9]+")) }
                .filter { it.length > 2 }
                .toSet()

            val userRoleLower = userProfile.jobTitle.lowercase()
            val isFounder = userRoleLower.contains("founder") || userRoleLower.contains("ceo") || userRoleLower.contains("co-founder")
            val isInvestor = userRoleLower.contains("investor") || userRoleLower.contains("vc") || userRoleLower.contains("partner") || userRoleLower.contains("angel")
            val isEngineer = userRoleLower.contains("engineer") || userRoleLower.contains("developer") || userRoleLower.contains("tech") || userRoleLower.contains("architect")
            val isProductOrDesign = userRoleLower.contains("product") || userRoleLower.contains("designer") || userRoleLower.contains("ux") || userRoleLower.contains("ui")

            val scored = members.map { member ->
                val memberText = "${member.name} ${member.jobTitle} ${member.company} ${member.category}".lowercase()
                var score = 0

                // 1. Keyword & domain overlap
                userKeywords.forEach { kw ->
                    if (memberText.contains(kw)) score += 3
                }

                // 2. Industry synergy
                if (userProfile.industry.isNotBlank() && memberText.contains(userProfile.industry.lowercase())) {
                    score += 5
                }

                // 3. Complementary role synergy (e.g. Founder + Investor, Engineer + Product)
                val memRoleLower = member.jobTitle.lowercase()
                val memCatLower = member.category.lowercase()
                val isMemberInvestor = memRoleLower.contains("investor") || memCatLower.contains("investor") || memRoleLower.contains("vc") || memRoleLower.contains("angel")
                val isMemberFounder = memRoleLower.contains("founder") || memCatLower.contains("founder") || memRoleLower.contains("ceo")
                val isMemberTech = memRoleLower.contains("engineer") || memRoleLower.contains("developer") || memCatLower.contains("developer")
                val isMemberProduct = memRoleLower.contains("product") || memRoleLower.contains("designer")

                if (isFounder && isMemberInvestor) score += 8
                if (isInvestor && isMemberFounder) score += 8
                if (isEngineer && (isMemberProduct || isMemberFounder)) score += 6
                if (isProductOrDesign && (isMemberTech || isMemberFounder)) score += 6
                if (isFounder && (isMemberTech || isMemberProduct)) score += 5

                Pair(member, score)
            }

            // Top matches scored highest appear at the top, rest down below
            scored.sortedByDescending { it.second }.map { it.first }
        }
    }

    val topMatchIds = remember(sortedMembers, userProfile) {
        if (userProfile != null && sortedMembers.size > 1) {
            sortedMembers.take(minOf(10, (sortedMembers.size + 1) / 2)).map { it.id }.toSet()
        } else {
            emptySet()
        }
    }

    var memberSearch by remember { mutableStateOf("") }
    val filteredMembers = remember(sortedMembers, memberSearch) {
        if (memberSearch.isBlank()) sortedMembers
        else sortedMembers.filter {
            it.name.contains(memberSearch, ignoreCase = true) ||
            it.jobTitle.contains(memberSearch, ignoreCase = true) ||
            it.company.contains(memberSearch, ignoreCase = true) ||
            it.category.contains(memberSearch, ignoreCase = true)
        }
    }

    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        // Compact search bar for room members
        OutlinedTextField(
            value = memberSearch,
            onValueChange = { memberSearch = it },
            placeholder = { Text("Search ${sortedMembers.size} members...", style = MaterialTheme.typography.bodySmall) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp),
            shape = RoundedCornerShape(12.dp),
            singleLine = true
        )

        if (filteredMembers.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(
                    text = if (memberSearch.isNotBlank()) "No members match '$memberSearch'" else "No members listed in this room yet.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodyMedium
                )
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 100.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp),
                modifier = Modifier.weight(1f)
            ) {
                items(filteredMembers, key = { it.id }) { member ->
                    val isTopSynergy = topMatchIds.contains(member.id)
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onMemberClick(member) },
                        colors = CardDefaults.cardColors(
                            containerColor = if (isTopSynergy) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.7f) else MaterialTheme.colorScheme.surface
                        )
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(8.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(38.dp)
                                    .clip(CircleShape)
                                    .background(Color(member.avatarBgHex)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = member.avatarInitial,
                                    style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }

                            Text(
                                text = member.name,
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 11.sp
                                ),
                                color = MaterialTheme.colorScheme.onBackground,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )

                            Text(
                                text = member.jobTitle.ifBlank { member.company },
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 9.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center
                            )

                            Row(
                                horizontalArrangement = Arrangement.spacedBy(3.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                if (member.isAdmin) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(AccentBlue)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("Admin", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold), color = Color.White)
                                    }
                                }
                                if (isTopSynergy && !member.isAdmin) {
                                    Box(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(4.dp))
                                            .background(MaterialTheme.colorScheme.primaryContainer)
                                            .padding(horizontal = 4.dp, vertical = 1.dp)
                                    ) {
                                        Text("✨ Match", style = MaterialTheme.typography.labelSmall.copy(fontSize = 8.sp, fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                    }
                                }
                                if (member.isConnected) {
                                    Icon(
                                        imageVector = Icons.Default.Check,
                                        contentDescription = "Connected",
                                        tint = Color(0xFF00C853),
                                        modifier = Modifier.size(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun RoomSpeakersList(
    speakers: List<RoomSpeaker>, 
    isAdmin: Boolean = false,
    currentUserName: String = "",
    onRemoveSpeaker: (String) -> Unit = {},
    onConnect: (String) -> Unit = {},
    onSpeakerClick: (String) -> Unit = {}
) {
    val context = LocalContext.current
    if (speakers.isEmpty()) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("No featured speakers announced yet.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    } else {
        LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(speakers) { speaker ->
                val isMe = speaker.name.equals(currentUserName, ignoreCase = true)
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onSpeakerClick(speaker.id) },
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Box(
                            modifier = Modifier.size(48.dp).clip(CircleShape).background(Color(speaker.avatarBgHex)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = speaker.avatarInitial, style = MaterialTheme.typography.titleLarge, color = MaterialTheme.colorScheme.onBackground)
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(text = speaker.name, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                                if (isMe) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(AccentBlue).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                        Text("You", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = Color.White)
                                    }
                                }
                                if (speaker.isAdmin) {
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Box(modifier = Modifier.clip(RoundedCornerShape(4.dp)).background(MaterialTheme.colorScheme.primary).padding(horizontal = 6.dp, vertical = 2.dp)) {
                                        Text("Admin", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp), color = Color.White)
                                    }
                                }
                            }
                            Text(text = "${speaker.jobTitle} @ ${speaker.company}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                        }
                        
                        if (isMe) {
                            // Can't connect to yourself
                        } else {
                            Button(
                                onClick = { 
                                    onConnect(speaker.id)
                                },
                                enabled = !speaker.isConnected,
                                modifier = Modifier.height(32.dp),
                                contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = if (speaker.isConnected) MaterialTheme.colorScheme.surfaceVariant else AccentBlue,
                                    contentColor = if (speaker.isConnected) MaterialTheme.colorScheme.onSurfaceVariant else Color.White
                                )
                            ) {
                                Text(
                                    text = if (speaker.isConnected) "Request Sent" else "Connect",
                                    style = MaterialTheme.typography.labelSmall,
                                    maxLines = 1,
                                    softWrap = false
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(androidx.compose.foundation.ExperimentalFoundationApi::class)
@Composable
fun RoomDiscussionsList(
    discussions: List<RoomDiscussion>,
    inputText: String,
    onInputChanged: (String) -> Unit,
    onPost: () -> Unit,
    onlyAdminsCanChat: Boolean = false,
    isAdmin: Boolean = false,
    isArchived: Boolean = false,
    currentUserId: String = "",
    onDeleteDisc: (String) -> Unit = {},
    onSendAttachment: (android.net.Uri, String, String?, String?) -> Unit = {_,_,_,_->},
    onImageClick: (String) -> Unit = {}
) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val launcher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            try {
                val mimeType = context.contentResolver.getType(uri)
                val attachmentType = if (mimeType?.startsWith("image") == true) "image" else "document"
                val originalName = runCatching {
                    context.contentResolver.query(
                        uri,
                        arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),
                        null, null, null
                    )?.use { cursor ->
                        if (cursor.moveToFirst() && !cursor.isNull(0)) cursor.getString(0) else null
                    }
                }.getOrNull()
                onSendAttachment(uri, attachmentType, mimeType, originalName)
                android.widget.Toast.makeText(context, "Uploading attachment...", android.widget.Toast.LENGTH_SHORT).show()
            } catch (e: Exception) {
                android.widget.Toast.makeText(context, "Error selecting file: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
            }
        }
    }
    Column(modifier = Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        // Post Input Box
        if ((!onlyAdminsCanChat || isAdmin) && !isArchived) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = inputText,
                    onValueChange = onInputChanged,
                    modifier = Modifier.weight(1f),
                    placeholder = { Text("Share an update or question in room...", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface
                    ),
                    shape = RoundedCornerShape(12.dp),
                    trailingIcon = {
                        IconButton(onClick = { launcher.launch("*/*") }) {
                            Icon(Icons.Default.AttachFile, contentDescription = "Attach File", tint = MaterialTheme.colorScheme.primary)
                        }
                    }
                )
                Button(
                    onClick = onPost,
                    modifier = Modifier.height(52.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.AutoMirrored.Filled.Send, contentDescription = "Post")
                }
            }
        } else {
            Box(
                modifier = Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.1f), RoundedCornerShape(12.dp)).padding(16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Only admins can send messages in this room.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }

        // Discussion Thread
        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.weight(1f)
        ) {
            items(discussions) { disc ->
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = disc.authorName, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text(text = disc.timeAgo, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                var showMenu by remember { mutableStateOf(false) }
                                Box {
                                    androidx.compose.material3.IconButton(
                                        onClick = { showMenu = true },
                                        modifier = Modifier.size(24.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.MoreVert,
                                            contentDescription = "Options",
                                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                    androidx.compose.material3.DropdownMenu(
                                        expanded = showMenu,
                                        onDismissRequest = { showMenu = false }
                                    ) {
                                        if (disc.authorId == currentUserId || isAdmin) {
                                            androidx.compose.material3.DropdownMenuItem(
                                                text = { Text("Delete Message") },
                                                onClick = {
                                                    showMenu = false
                                                    onDeleteDisc(disc.id)
                                                },
                                                leadingIcon = { Icon(Icons.Default.Delete, contentDescription = null, tint = MaterialTheme.colorScheme.error) }
                                            )
                                        }
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { Text("Block User") },
                                            onClick = {
                                                showMenu = false
                                                android.widget.Toast.makeText(context, "User blocked.", android.widget.Toast.LENGTH_SHORT).show()
                                            },
                                            leadingIcon = { Icon(Icons.Default.Block, contentDescription = null) }
                                        )
                                        androidx.compose.material3.DropdownMenuItem(
                                            text = { Text("Report Message") },
                                            onClick = {
                                                showMenu = false
                                                android.widget.Toast.makeText(context, "Message reported for review.", android.widget.Toast.LENGTH_SHORT).show()
                                            },
                                            leadingIcon = { Icon(Icons.Default.Flag, contentDescription = null) }
                                        )
                                    }
                                }
                            }
                        }
                        Text(text = disc.authorTitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = if(disc.content.contains("🚫")) "🚫 This message was deleted" else disc.content, style = if(disc.content.contains("🚫")) MaterialTheme.typography.bodySmall.copy(fontStyle=androidx.compose.ui.text.font.FontStyle.Italic) else MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f))
                        if (disc.attachmentUrl != null && !disc.content.contains("🚫")) {
                            Spacer(modifier = Modifier.height(4.dp))
                            val context = LocalContext.current
                            val isImage = disc.attachmentType == "image" || disc.attachmentUrl.contains(".jpg") || disc.attachmentUrl.contains(".jpeg") || disc.attachmentUrl.contains(".png") || disc.attachmentUrl.contains("alt=media") || disc.attachmentUrl.startsWith("data:image")
                            if (isImage) {
                                coil.compose.AsyncImage(
                                    model = com.example.utils.AttachmentHelper.getDisplayableImageModel(disc.attachmentUrl),
                                    contentDescription = "Attachment",
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(180.dp)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            disc.attachmentUrl.let { onImageClick(it) }
                                        },
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            } else {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            com.example.utils.AttachmentHelper.openDocument(context, disc.attachmentUrl, "room_file_${disc.id}")
                                        }
                                        .padding(vertical = 4.dp)
                                        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(8.dp))
                                        .padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Default.Download, contentDescription = "Download Document", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Column {
                                        Text("Download / Open Document", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                        Text("Tap to save and view", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun RoomOpportunitiesList(
    opportunities: List<RoomOpportunity>, 
    isAdmin: Boolean, 
    isArchived: Boolean = false,
    onApply: () -> Unit = {},
    onPostOpportunity: (RoomOpportunity) -> Unit = {},
    onDeleteOpportunity: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    var showPostForm by remember { mutableStateOf(false) }
    
    Column(modifier = Modifier.fillMaxSize()) {
        if (!isArchived) {
            Button(
                onClick = { showPostForm = true },
                modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
            ) {
                Icon(Icons.Default.Add, "Post Opportunity", modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text("Post New Opportunity / Job Link")
            }
        }

        if (opportunities.isEmpty()) {
            Box(modifier = Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text("No active job or funding opportunities listed.", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        } else {
            LazyColumn(verticalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.weight(1f)) {
            items(opportunities) { opp ->
                Card(
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = opp.title, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground, modifier = Modifier.weight(1f))
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(6.dp))
                                        .background(AccentBlue.copy(alpha = 0.2f))
                                        .padding(horizontal = 8.dp, vertical = 2.dp)
                                ) {
                                    Text(text = opp.type, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                }
                                if (isAdmin) {
                                    androidx.compose.material3.IconButton(onClick = { onDeleteOpportunity(opp.id) }, modifier = Modifier.size(24.dp)) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }

                        Text(text = opp.companyOrAuthor, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(text = opp.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.85f))
                        
                        if (!opp.applicationLink.isNullOrBlank()) {
                            val cleanLink = opp.applicationLink.trim()
                            val fullUrl = if (cleanLink.startsWith("http://", ignoreCase = true) || cleanLink.startsWith("https://", ignoreCase = true)) cleanLink else "https://$cleanLink"
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(AccentBlue.copy(alpha = 0.12f))
                                    .clickable {
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(intent)
                                        } catch (e: Exception) {
                                            try {
                                                uriHandler.openUri(fullUrl)
                                            } catch (e2: Exception) {
                                                Toast.makeText(context, "Could not open website: $fullUrl", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Link, contentDescription = null, tint = AccentBlue, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(6.dp))
                                Text(
                                    text = opp.applicationLink,
                                    style = MaterialTheme.typography.labelMedium.copy(color = AccentBlue, textDecoration = androidx.compose.ui.text.style.TextDecoration.Underline, fontWeight = FontWeight.Bold),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Text(
                                    text = "Open Website ↗",
                                    style = MaterialTheme.typography.labelSmall.copy(color = AccentBlue, fontWeight = FontWeight.Bold)
                                )
                            }
                        }

                        Button(
                            onClick = { 
                                if (!opp.applicationLink.isNullOrBlank()) {
                                    val cleanLink = opp.applicationLink.trim()
                                    val fullUrl = if (cleanLink.startsWith("http://", ignoreCase = true) || cleanLink.startsWith("https://", ignoreCase = true)) cleanLink else "https://$cleanLink"
                                    try {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(fullUrl)).apply {
                                            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                        }
                                        context.startActivity(intent)
                                    } catch (e: Exception) {
                                        try {
                                            uriHandler.openUri(fullUrl)
                                        } catch (e2: Exception) {
                                            Toast.makeText(context, "Could not open website: $fullUrl", Toast.LENGTH_SHORT).show()
                                        }
                                    }
                                } else {
                                    onApply()
                                }
                            },
                            modifier = Modifier.fillMaxWidth().height(42.dp).padding(top = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                        ) {
                            Icon(Icons.Default.Link, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(Modifier.width(6.dp))
                            Text(if (!opp.applicationLink.isNullOrBlank()) "Open Website / Apply" else "Apply", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        }
                    }
                }
            }
        }
    }
    
    if (showPostForm) {
        var role by remember { mutableStateOf("") }
        var type by remember { mutableStateOf("Hiring") }
        var experience by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var link by remember { mutableStateOf("") }
        
        ModalBottomSheet(
            onDismissRequest = { showPostForm = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 16.dp).padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text("Post New Opportunity", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                
                OutlinedTextField(
                    value = role,
                    onValueChange = { role = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Role / Opportunity Title") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
                
                OutlinedTextField(
                    value = experience,
                    onValueChange = { experience = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Experience / Requirements") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
                
                OutlinedTextField(
                    value = description,
                    onValueChange = { description = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Description") },
                    minLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
                
                OutlinedTextField(
                    value = link,
                    onValueChange = { link = it },
                    modifier = Modifier.fillMaxWidth(),
                    label = { Text("Application Link / Website URL") },
                    placeholder = { Text("e.g. https://company.com/apply") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )
                
                Button(
                    onClick = {
                        val opp = RoomOpportunity(
                            id = "opp_${System.currentTimeMillis()}",
                            title = role,
                            type = type,
                            companyOrAuthor = "Netero Member",
                            description = "Requirements: $experience\n\n$description",
                            applicationLink = link.trim()
                        )
                        onPostOpportunity(opp)
                        showPostForm = false
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue, disabledContainerColor = MaterialTheme.colorScheme.surfaceVariant),
                    enabled = role.isNotBlank() && experience.isNotBlank() && description.isNotBlank()
                ) {
                    Text("Post Opportunity")
                }
            }
        }
    }
}
}
