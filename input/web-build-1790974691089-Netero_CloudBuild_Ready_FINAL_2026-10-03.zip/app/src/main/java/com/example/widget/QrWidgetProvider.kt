package com.example.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Color
import android.widget.RemoteViews
import com.example.MainActivity
import com.example.R
import com.google.zxing.BarcodeFormat
import com.google.zxing.qrcode.QRCodeWriter

class QrWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (appWidgetId in appWidgetIds) {
            updateAppWidget(context, appWidgetManager, appWidgetId)
        }
    }
}

internal fun updateAppWidget(context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int) {
    val views = RemoteViews(context.packageName, R.layout.widget_qr)

    // Read from SharedPreferences
    val prefs = context.getSharedPreferences("netero_prefs", Context.MODE_PRIVATE)
    val savedName = prefs.getString("profile_name", "Netero User") ?: "Netero User"
    val savedTitle = prefs.getString("profile_title", "Professional") ?: "Professional"
    val savedCompany = prefs.getString("profile_company", "Network") ?: "Network"
    val savedPhone = prefs.getString("profile_phone", "") ?: ""
    val savedEmail = prefs.getString("profile_email", "") ?: ""
    val savedLinkedin = prefs.getString("profile_linkedin", "") ?: ""
    val savedWebsite = prefs.getString("profile_website", "") ?: ""
    val savedBusiness = prefs.getString("profile_business", "") ?: ""
    val savedPortfolio = prefs.getString("profile_portfolio", "") ?: ""

    // Generate QR Code bitmap offline - simple vCard
    var vCard = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:$savedName\r\nORG:$savedCompany\r\nTITLE:$savedTitle\r\n"
    if (savedPhone.isNotBlank()) vCard += "TEL:$savedPhone\r\n"
    if (savedEmail.isNotBlank()) vCard += "EMAIL:$savedEmail\r\n"
    if (savedLinkedin.isNotBlank()) vCard += "URL:$savedLinkedin\r\n"
    if (savedWebsite.isNotBlank()) vCard += "URL:$savedWebsite\r\n"
    if (savedBusiness.isNotBlank()) vCard += "URL:$savedBusiness\r\n"
    if (savedPortfolio.isNotBlank()) vCard += "URL:$savedPortfolio\r\n"
    vCard += "END:VCARD"
    val size = 512
    val writer = QRCodeWriter()
    try {
        val bitMatrix = writer.encode(vCard, BarcodeFormat.QR_CODE, size, size)
        val bitmap = Bitmap.createBitmap(size, size, Bitmap.Config.RGB_565)
        for (x in 0 until size) {
            for (y in 0 until size) {
                bitmap.setPixel(x, y, if (bitMatrix.get(x, y)) Color.BLACK else Color.WHITE)
            }
        }
        views.setImageViewBitmap(R.id.widget_qr_image, bitmap)
    } catch (e: Exception) {
        e.printStackTrace()
    }

    val intent = Intent(context, MainActivity::class.java)
    val pendingIntent = PendingIntent.getActivity(
        context, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
    )
    views.setOnClickPendingIntent(R.id.widget_root, pendingIntent)

    appWidgetManager.updateAppWidget(appWidgetId, views)
}
