package com.example.ui.screens

import kotlinx.coroutines.tasks.await
import androidx.compose.ui.platform.LocalHapticFeedback
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material.icons.filled.CameraAlt


import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.runtime.DisposableEffect
import androidx.compose.material.icons.filled.Payment
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.WifiOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import com.example.utils.QrCodeGenerator
import androidx.compose.foundation.Image
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import android.content.Intent

import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.UserProfile
import com.example.ui.theme.AccentBlue
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.NeteroTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

data class ScannedContactData(
    val name: String, 
    val role: String, 
    val company: String,
    val email: String? = null,
    val linkedin: String? = null,
    val phone: String? = null,
    val source: String = "QR",
    val tags: List<String>? = null
)

@Composable
fun QrScreen(
    userProfile: UserProfile,
    onHandleScanContact: (String, String, String, String, String?, String?, String?, String?, List<String>?) -> Unit,
    onRoomScanned: (String) -> Unit = {},
    onNavigateToPaywall: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var selectedTabIndex by remember { mutableIntStateOf(0) } // 0: My QR Code, 1: Scan QR
    var pendingScan by remember { mutableStateOf<ScannedContactData?>(null) }
    val tabs = listOf("My QR Code", "Scan QR Code")

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(top = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top TabBar
        TabRow(
            selectedTabIndex = selectedTabIndex,
            containerColor = MaterialTheme.colorScheme.background,
            contentColor = MaterialTheme.colorScheme.onPrimary,
            indicator = { tabPositions ->
                if (selectedTabIndex < tabPositions.size) {
                    TabRowDefaults.SecondaryIndicator(
                        Modifier.tabIndicatorOffset(tabPositions[selectedTabIndex]),
                        color = MaterialTheme.colorScheme.primary,
                        height = 3.dp
                    )
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp)
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTabIndex == index,
                    onClick = { selectedTabIndex = index },
                    modifier = Modifier
                        .height(48.dp)
                        .testTag(if (index == 0) "tab_my_qr" else "tab_scan_qr")
                ) {
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontWeight = if (selectedTabIndex == index) FontWeight.Bold else FontWeight.Medium
                        ),
                        color = if (selectedTabIndex == index) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        // Tab Content
        when (selectedTabIndex) {
            0 -> MyQrTabContent(userProfile = userProfile)
            1 -> ScanQrTabContent(
                onHandleScanContact = { n, r, c, e, l, p, t -> pendingScan = ScannedContactData(n, r, c, e, l, p, "QR", t) },
                onRoomScanned = onRoomScanned,
                isPro = userProfile.isPro,
                onNavigateToPaywall = onNavigateToPaywall
            )
        }
    }

    if (pendingScan != null) {
        AddNoteDialog(
            contactData = pendingScan!!,
            onDismiss = { pendingScan = null },
            onSave = { notes -> 
                onHandleScanContact(pendingScan!!.name, pendingScan!!.role, pendingScan!!.company, pendingScan!!.source, notes, pendingScan!!.email, pendingScan!!.linkedin, pendingScan!!.phone, pendingScan!!.tags)
                pendingScan = null
            }
        )
    }
}

@Composable
fun AddNoteDialog(
    contactData: ScannedContactData,
    onDismiss: () -> Unit,
    onSave: (String) -> Unit
) {
    var notes by remember { mutableStateOf("") }
    val context = LocalContext.current
    var hasScanned by remember { mutableStateOf(false) }
    
    val speechRecognizerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            val data = result.data
            val matches = data?.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS)
            if (!matches.isNullOrEmpty()) {
                notes = if (notes.isEmpty()) matches[0] else notes + " " + matches[0]
            }
        }
    }

    androidx.compose.material3.AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = MaterialTheme.colorScheme.surface,
        title = {
            Text("Add Note for ${contactData.name}", color = MaterialTheme.colorScheme.onBackground, style = MaterialTheme.typography.titleLarge)
        },
        text = {
            Column {
                Text("Where did you meet? What was discussed?", color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodyMedium)
                Spacer(modifier = Modifier.height(16.dp))
                
                androidx.compose.material3.OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(120.dp),
                    placeholder = { Text("E.g., Met at Bangalore Summit. Follow up about AI integration.", color = MaterialTheme.colorScheme.onSurfaceVariant) },
                    colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = MaterialTheme.colorScheme.background,
                        unfocusedContainerColor = MaterialTheme.colorScheme.background,
                        focusedTextColor = MaterialTheme.colorScheme.onSurface,
                        unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                        focusedBorderColor = AccentBlue,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    shape = RoundedCornerShape(12.dp)
                )
                
                Spacer(modifier = Modifier.height(12.dp))
                
                Button(
                    onClick = {
                        val intent = android.content.Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                            putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Speak your note now...")
                        }
                        try {
                            speechRecognizerLauncher.launch(intent)
                        } catch (e: Exception) {
                            android.widget.Toast.makeText(context, "Voice input not supported", android.widget.Toast.LENGTH_SHORT).show()
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.background, contentColor = AccentBlue),
                    border = androidx.compose.foundation.BorderStroke(1.dp, AccentBlue),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(imageVector = Icons.Filled.Mic, contentDescription = "Voice Input", modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Use Voice Assistant")
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(notes) },
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text("Save & Connect")
            }
        },
        dismissButton = {
            androidx.compose.material3.TextButton(onClick = onDismiss) {
                Text("Cancel", color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    )
}

@Composable
private fun MyQrTabContent(userProfile: UserProfile) {
    var isCopied by remember { mutableStateOf(false) }
    var isOfflineMode by remember { mutableStateOf(true) }
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current
    var hasScanned by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 24.dp)
            .padding(bottom = 90.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        // QR Code Box Card
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(24.dp))
                .background(MaterialTheme.colorScheme.surface)
                .border(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.5f), RoundedCornerShape(24.dp))
                .padding(28.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(20.dp)
            ) {
                // User Name & Role Header
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        text = userProfile.fullName,
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                        androidx.compose.material3.Icon(
                            imageVector = if (userProfile.isStudent) Icons.Default.School else Icons.Default.Work,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp),
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "${userProfile.jobTitle} @ ${userProfile.company}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                // Always generate standard vCard format so any phone camera or app saves contact immediately
                val qrContent = remember(userProfile) {
                    val name = userProfile.fullName.ifBlank { "Netero User" }
                    val title = userProfile.jobTitle.ifBlank { "Professional" }
                    val company = userProfile.company.ifBlank { "Network" }
                    
                    var vCard = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:$name\r\nORG:$company\r\nTITLE:$title\r\n"
                    if (userProfile.phone.isNotBlank() && userProfile.neteroLock.phoneVisibility != com.example.data.model.PrivacyLevel.PRIVATE) vCard += "TEL:${userProfile.phone}\r\n"
                    if (userProfile.email.isNotBlank()) vCard += "EMAIL:${userProfile.email}\r\n"
                    if (userProfile.linkedinUrl.isNotBlank()) vCard += "URL:${userProfile.linkedinUrl}\r\n"
                    if (userProfile.website.isNotBlank() && !userProfile.website.contains("netero", ignoreCase = true)) {
                        vCard += "URL:${userProfile.website}\r\n"
                    } else {
                        vCard += "URL:https://play.google.com/store/apps/details?id=com.aistudio.netero.network.xpkq\r\n"
                    }
                    if (userProfile.businessUrl.isNotBlank()) vCard += "URL:${userProfile.businessUrl}\r\n"
                    if (userProfile.portfolioUrl.isNotBlank()) vCard += "URL:${userProfile.portfolioUrl}\r\n"
                    if (userProfile.username.isNotBlank()) vCard += "X-NETERO-USER:${userProfile.username}\r\n"
                    if (userProfile.industry.isNotBlank()) vCard += "X-NETERO-INDUSTRY:${userProfile.industry}\r\n"
                    val uid = try { com.google.firebase.auth.FirebaseAuth.getInstance().currentUser?.uid ?: userProfile.username } catch(e: Exception) { userProfile.username }
                    vCard += "NOTE:NETERO_UID:$uid|USER:${userProfile.username}|INDUSTRY:${userProfile.industry}\r\n"
                    vCard += "END:VCARD"
                    vCard
                }
                val context = LocalContext.current
    var hasScanned by remember { mutableStateOf(false) }
                val qrBitmap = remember(qrContent, context) {
                    QrCodeGenerator.generateQrCode(context = context, content = qrContent, width = 512, height = 512)
                }

                Box(
                    modifier = Modifier
                        .size(220.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(MaterialTheme.colorScheme.surface)
                        .padding(16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    if (qrBitmap != null) {
                        Image(
                            bitmap = qrBitmap.asImageBitmap(),
                            contentDescription = "User QR Code",
                            modifier = Modifier.fillMaxSize(),
                            
                        )
                    } else {
                        // Fallback in case generation fails
                        Text("QR Code Error", color = MaterialTheme.colorScheme.surface)
                    }
                }

                Text(
                    text = "Works with any smartphone camera.\nNo app required.",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    textAlign = TextAlign.Center
                )
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Offline Mode Toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .background(if (isOfflineMode) AccentBlue.copy(alpha = 0.1f) else MaterialTheme.colorScheme.surface)
                .border(1.dp, if (isOfflineMode) AccentBlue.copy(alpha = 0.3f) else MaterialTheme.colorScheme.outline, RoundedCornerShape(16.dp))
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.WifiOff,
                    contentDescription = "Offline Mode",
                    tint = if (isOfflineMode) AccentBlue else MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(24.dp)
                )
                Column {
                    Text(
                        text = if (isOfflineMode) "Offline Mode Active" else "Offline Mode Inactive",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (isOfflineMode) "Share vCard directly without internet" else "Share your online profile link",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
            Switch(
                checked = isOfflineMode,
                onCheckedChange = { isOfflineMode = it },
                colors = SwitchDefaults.colors(
                    checkedThumbColor = MaterialTheme.colorScheme.onBackground,
                    checkedTrackColor = AccentBlue
                )
            )
        }

        Spacer(modifier = Modifier.height(24.dp))
        }
    }

@Preview(showBackground = true)
@Composable
fun QrScreenPreview() {
    NeteroTheme(darkTheme = true) {
        QrScreen(
            userProfile = UserProfile(),
            onHandleScanContact = { _, _, _, _, _, _, _, _, _ -> }
        )
    }
}


@Composable
private fun ScanQrTabContent(
    onHandleScanContact: (String, String, String, String?, String?, String?, List<String>?) -> Unit,
    onRoomScanned: (String) -> Unit,
    isPro: Boolean,
    onNavigateToPaywall: () -> Unit
) {
    var captureTrigger by remember { mutableStateOf(0L) }
    var isExtracting by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val context = LocalContext.current
    var hasScanned by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Mode indicator banner
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 12.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
                .padding(horizontal = 12.dp, vertical = 8.dp)
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.QrCodeScanner,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.size(18.dp)
                )
                Text(
                    text = "Live Scanner: Point at Room QR or Profile QR to connect instantly.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .clip(RoundedCornerShape(24.dp))
                .background(Color.Black)
        ) {
            CameraQrScanner(
                onQrCodeScanned = { qr ->
                    val isRoomQr = qr.startsWith("netero://room/") || qr.startsWith("NETERO_ROOM:") || qr.startsWith("https://netero.in/room/") || qr.startsWith("https://netero.app/room/")
                    val isNeteroProfileQr = qr.startsWith("https://netero.in/profile/") || 
                        qr.startsWith("https://netero.app/p/") || 
                        qr.startsWith("netero://profile/") || 
                        qr.startsWith("NETERO_ID:") ||
                        (qr.startsWith("BEGIN:VCARD") && (qr.contains("NETERO", ignoreCase = true) || qr.contains("X-NETERO", ignoreCase = true)))

                    // Ignore any non-Netero QR completely (including PhonePe, UPI, Paytm, GPay, or unrelated barcodes)
                    if (!isRoomQr && !isNeteroProfileQr) {
                        return@CameraQrScanner
                    }

                    if (!hasScanned) {
                        hasScanned = true
                        haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                        if (isRoomQr) {
                            val cleanRoomId = qr.removePrefix("netero://room/").removePrefix("NETERO_ROOM:").removePrefix("https://netero.in/room/").removePrefix("https://netero.app/room/").trim()
                            onRoomScanned(cleanRoomId)
                        } else {
                            var name = "Scanned Contact"
                            var role = "Professional"
                            var company = "Network"
                            var email: String? = null
                            var phone: String? = null
                            var linkedin: String? = null
                            var neteroUid: String? = null
                            var industry: String? = null
                            var username: String? = null
                            if (qr.startsWith("BEGIN:VCARD")) {
                                val lines = qr.lines()
                                lines.forEach { line ->
                                    val trimmed = line.trim()
                                    if (trimmed.startsWith("FN:", ignoreCase = true) || trimmed.startsWith("FN;", ignoreCase = true)) name = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("TITLE:", ignoreCase = true) || trimmed.startsWith("TITLE;", ignoreCase = true)) role = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("ORG:", ignoreCase = true) || trimmed.startsWith("ORG;", ignoreCase = true)) company = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("EMAIL:", ignoreCase = true) || trimmed.startsWith("EMAIL;", ignoreCase = true)) email = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("TEL:", ignoreCase = true) || trimmed.startsWith("TEL;", ignoreCase = true)) phone = trimmed.substringAfter(":").trim()
                                    else if ((trimmed.startsWith("URL:", ignoreCase = true) || trimmed.startsWith("URL;", ignoreCase = true)) && trimmed.contains("linkedin", ignoreCase = true)) linkedin = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("X-NETERO-USER:", ignoreCase = true) || trimmed.startsWith("X-NETERO-USER;", ignoreCase = true)) username = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("X-NETERO-INDUSTRY:", ignoreCase = true) || trimmed.startsWith("X-NETERO-INDUSTRY;", ignoreCase = true)) industry = trimmed.substringAfter(":").trim()
                                    else if (trimmed.startsWith("NOTE", ignoreCase = true) && trimmed.contains("NETERO_UID:")) {
                                        val note = trimmed.substringAfter(":").trim()
                                        val uMatch = Regex("NETERO_UID:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                                        if (!uMatch.isNullOrBlank()) neteroUid = uMatch
                                        val indMatch = Regex("INDUSTRY:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                                        if (!indMatch.isNullOrBlank()) industry = indMatch
                                        val userMatch = Regex("USER:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                                        if (!userMatch.isNullOrBlank()) username = userMatch
                                    }
                                }
                                val tagsList = mutableListOf<String>()
                                if (!industry.isNullOrBlank()) tagsList.add(industry!!)
                                if (!neteroUid.isNullOrBlank()) tagsList.add("UID:$neteroUid")
                                if (!username.isNullOrBlank()) tagsList.add("USER:$username")
                                onHandleScanContact(name, role, company, email, linkedin, phone, if (tagsList.isEmpty()) null else tagsList)
                            } else if (qr.startsWith("https://netero.in/profile/") || qr.startsWith("https://netero.app/p/")) {
                                try {
                                    val uri = android.net.Uri.parse(qr)
                                    name = uri.getQueryParameter("name") ?: uri.lastPathSegment ?: "Scanned Contact"
                                    role = uri.getQueryParameter("role") ?: "Professional"
                                    company = uri.getQueryParameter("company") ?: "Network"
                                } catch(e: Exception) {}
                                onHandleScanContact(name, role, company, email, linkedin, phone, null)
                            }
                        }
                    }
                },
                captureTrigger = captureTrigger,
                onImageCaptured = { imageBytes ->
                    isExtracting = true
                    scope.launch(Dispatchers.IO) {
                        try {
                            var ocrText = ""
                            try {
                                val bitmap = android.graphics.BitmapFactory.decodeByteArray(imageBytes, 0, imageBytes.size)
                                if (bitmap != null) {
                                    val inputImage = com.google.mlkit.vision.common.InputImage.fromBitmap(bitmap, 0)
                                    val recognizer = com.google.mlkit.vision.text.TextRecognition.getClient(
                                        com.google.mlkit.vision.text.latin.TextRecognizerOptions.DEFAULT_OPTIONS
                                    )
                                    val result = recognizer.process(inputImage).await()
                                    ocrText = result.text
                                }
                            } catch (e: Exception) {
                                android.util.Log.w("QrScreen", "On-device OCR exception: ${e.message}")
                            }

                            val data = com.example.data.api.GeminiAiHelper.extractBusinessCardData(imageBytes, ocrText)
                            withContext(Dispatchers.Main) {
                                isExtracting = false
                                if (data != null) {
                                    if (data.optBoolean("isSensitivePaymentCard", false)) {
                                        android.widget.Toast.makeText(context, "⚠️ Payment/Credit card detected. NETERO only scans professional business cards.", android.widget.Toast.LENGTH_LONG).show()
                                        return@withContext
                                    }
                                    if (data.optBoolean("isCodeSnippet", false) || !data.optBoolean("isBusinessCard", false)) {
                                        android.widget.Toast.makeText(context, "Not a business card. Please point the camera at a physical visiting card.", android.widget.Toast.LENGTH_LONG).show()
                                        return@withContext
                                    }
                                    val rawName = data.optString("name", "").takeIf { it.isNotBlank() && it != "null" }
                                    val rawCompany = data.optString("company", "").takeIf { it.isNotBlank() && it != "null" }
                                    if (rawName == null && rawCompany == null) {
                                        android.widget.Toast.makeText(context, "Could not detect business contact details on this card.", android.widget.Toast.LENGTH_LONG).show()
                                        return@withContext
                                    }
                                    val name = rawName ?: rawCompany ?: "Business Contact"
                                    val role = data.optString("jobTitle", "Professional").takeIf { it.isNotBlank() && it != "null" } ?: "Professional"
                                    val company = rawCompany ?: "Visiting Card"
                                    val phone = data.optString("phone", "").takeIf { it.isNotBlank() && it != "null" }
                                    val email = data.optString("email", "").takeIf { it.isNotBlank() && it != "null" }
                                    val linkedin = data.optString("linkedin", "").takeIf { it.isNotBlank() && it != "null" }
                                    val tagsArray = data.optJSONArray("tags")
                                    val tagsList = if (tagsArray != null) {
                                        List(tagsArray.length()) { tagsArray.getString(it) }
                                    } else listOf("Visiting Card")
                                    onHandleScanContact(name, role, company, email, linkedin, phone, tagsList)
                                    android.widget.Toast.makeText(context, "✓ Scanned card! Added $name to Connections.", android.widget.Toast.LENGTH_SHORT).show()
                                } else {
                                    android.widget.Toast.makeText(context, "Could not read business card details clearly. Please ensure good lighting and hold the card steady.", android.widget.Toast.LENGTH_LONG).show()
                                }
                            }
                        } catch (e: Exception) {
                            withContext(Dispatchers.Main) {
                                isExtracting = false
                                android.widget.Toast.makeText(context, "Error reading card.", android.widget.Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            )
            if (isExtracting) {
                Box(
                    modifier = Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.6f)),
                    contentAlignment = Alignment.Center
                ) {
                    androidx.compose.material3.CircularProgressIndicator(color = MaterialTheme.colorScheme.primary)
                }
            }
        }
        
        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = "Have a physical paper visiting card? Tap below to scan card text:",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        
        Spacer(modifier = Modifier.height(8.dp))
        
        Button(
            onClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                captureTrigger = System.currentTimeMillis()
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
                .testTag("paper_scan_button"),
            colors = ButtonDefaults.buttonColors(
                containerColor = MaterialTheme.colorScheme.secondary,
                contentColor = MaterialTheme.colorScheme.onSurface
            ),
            shape = RoundedCornerShape(14.dp)
        ) {
            Icon(imageVector = Icons.Default.CameraAlt, contentDescription = null, modifier = Modifier.size(16.dp))
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "Scan Paper Business Card (OCR)",
                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
            )
        }
    }
}
