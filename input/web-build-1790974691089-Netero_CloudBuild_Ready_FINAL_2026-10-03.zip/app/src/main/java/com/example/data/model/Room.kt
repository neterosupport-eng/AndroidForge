package com.example.data.model

enum class RoomType(val label: String) {
    PUBLIC("Public Room"),
    PRIVATE("Private Room"),
    EVENT("Event Room"),
    TEMPORARY("Temporary Room")
}

data class RoomSpeaker(
    val id: String,
    val name: String,
    val jobTitle: String,
    val company: String,
    val isConnected: Boolean = false,
    val avatarInitial: String,
    val avatarBgHex: Long,
    val isAdmin: Boolean = false
)

data class RoomDiscussion(
    val id: String,
    val authorName: String,
    val authorTitle: String,
    val content: String,
    val timeAgo: String,
    val likesCount: Int = 0,
    val authorId: String = "",
    val isEdited: Boolean = false,
    val isDeleted: Boolean = false,
    val attachmentUrl: String? = null,
    val attachmentType: String? = null,
    val attachmentName: String? = null,
    val attachmentMimeType: String? = null
)

data class RoomOpportunity(
    val id: String,
    val title: String,
    val type: String, // e.g. "Hiring", "Partnership", "Investment"
    val companyOrAuthor: String,
    val description: String,
    val applicationLink: String? = null
)

data class RoomMember(
    val id: String,
    val name: String,
    val jobTitle: String,
    val company: String,
    val category: String, // Founder, Investor, Creator, etc.
    val isConnected: Boolean = false,
    val avatarInitial: String,
    val avatarBgHex: Long,
    val isAdmin: Boolean = false,
    val isSpeaker: Boolean = false
)

data class RoomJoinRequest(
    val id: String,
    val name: String,
    val jobTitle: String,
    val avatarInitial: String,
    val avatarBgHex: Long
)

data class Room(
    val id: String,
    val name: String,
    val description: String,
    val type: RoomType,
    val memberCount: Int,
    val tags: List<String>,
    val location: String = "Bengaluru",
    val activeTimeRange: String = "Active Now",
    val isJoined: Boolean = false,
    val isJoinRequested: Boolean = false,
    val onlyAdminsCanChat: Boolean = false,
    val joinRequests: List<RoomJoinRequest> = emptyList(),
    val speakers: List<RoomSpeaker> = emptyList(),
    val discussions: List<RoomDiscussion> = emptyList(),
    val opportunities: List<RoomOpportunity> = emptyList(),
    val members: List<RoomMember> = emptyList(),
    val isCreatedByMe: Boolean = false,
    val adminId: String = "",
    val password: String = "",
    val startDate: String = "",
    val startTime: String = "",
    val endDate: String = "",
    val endTime: String = "",
    val isArchived: Boolean = false
)
