package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import coil.compose.AsyncImage
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import kotlinx.coroutines.delay
import androidx.compose.runtime.rememberCoroutineScope

import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.*
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Work
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Business
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.VpnKey
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Link
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Analytics
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.DeleteForever
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import android.content.Intent
import android.net.Uri
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Description
import androidx.compose.material.icons.filled.Policy
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PrivacyLevel
import com.example.data.model.UserProfile
import com.example.data.model.NeteroLockSettings
import com.example.ui.theme.AccentBlue

@OptIn(ExperimentalMaterial3Api::class, ExperimentalLayoutApi::class)
@Composable
fun ProfileScreen(
    userProfile: UserProfile,
    isDarkTheme: Boolean,
    onToggleDarkTheme: () -> Unit,
    onNavigateToEditProfile: () -> Unit,
    onNavigateToLockSettings: () -> Unit,
    onNavigateToAnalytics: () -> Unit = {},
    onUploadProfileImage: (android.net.Uri, (Boolean) -> Unit) -> Unit = { _, _ -> },
    onRemoveProfilePhoto: () -> Unit = {},
    onUpdateNeteroLock: (
        phone: PrivacyLevel,
        email: PrivacyLevel,
        social: PrivacyLevel,
        discovery: PrivacyLevel,
        portfolio: PrivacyLevel,
        room: Boolean
    ) -> Unit,
    onLogout: () -> Unit,
    onDeleteAccount: () -> Unit,
    onEnhanceBioWithAi: ((String) -> Unit) -> Unit = {},
    isPro: Boolean = false,
    onNavigateToPaywall: () -> Unit = {},
    onNavigateToHelpDesk: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    var phoneVis by remember { mutableStateOf(userProfile.neteroLock.phoneVisibility) }
    var emailVis by remember { mutableStateOf(userProfile.neteroLock.emailVisibility) }
    var socialVis by remember { mutableStateOf(userProfile.neteroLock.socialVisibility) }
    var discoveryVis by remember { mutableStateOf(userProfile.neteroLock.profileDiscovery) }
    var portfolioVis by remember { mutableStateOf(userProfile.neteroLock.portfolioVisibility) }
    var roomVis by remember { mutableStateOf(userProfile.neteroLock.roomVisibility) }
    var isEnhancingBio by remember { mutableStateOf(false) }
    var showProfileMenu by remember { mutableStateOf(false) }
    var showLogoutConfirm1 by remember { mutableStateOf(false) }
    var showLogoutConfirm2 by remember { mutableStateOf(false) }
    var showDeleteAccountConfirm by remember { mutableStateOf(false) }
    var showSecurityDialog by remember { mutableStateOf(false) }
    var showPrivacySheet by remember { mutableStateOf(false) }
    var showPhotoOptionsDialog by remember { mutableStateOf(false) }
    var showPresetAvatarsSheet by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val uriHandler = androidx.compose.ui.platform.LocalUriHandler.current
    var isUploadingPhoto by remember { mutableStateOf(false) }

    val getContentLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.GetContent(),
        onResult = { uri ->
            if (uri != null) {
                isUploadingPhoto = true
                try {
                    onUploadProfileImage(uri) { success ->
                        isUploadingPhoto = false
                        val message = if (success) "Profile photo updated!" else "Could not upload profile photo"
                        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    isUploadingPhoto = false
                    android.widget.Toast.makeText(context, "Could not load photo: ${e.message}", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    val photoPickerLauncher = androidx.activity.compose.rememberLauncherForActivityResult(
        contract = androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                isUploadingPhoto = true
                try {
                    onUploadProfileImage(uri) { success ->
                        isUploadingPhoto = false
                        val message = if (success) "Profile photo updated in cloud!" else "Could not upload profile photo"
                        android.widget.Toast.makeText(context, message, android.widget.Toast.LENGTH_SHORT).show()
                    }
                } catch (e: Exception) {
                    isUploadingPhoto = false
                    android.widget.Toast.makeText(context, "Could not load photo", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }
    )

    Scaffold(
        modifier = modifier.fillMaxSize(),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = "My NETERO Identity",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                        color = MaterialTheme.colorScheme.onBackground
                    )
                },
                actions = {
                    IconButton(onClick = onToggleDarkTheme, modifier = Modifier.testTag("theme_toggle")) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Default.LightMode else Icons.Default.DarkMode,
                            contentDescription = "Theme",
                            tint = MaterialTheme.colorScheme.onBackground
                        )
                    }
                    Box {
                        IconButton(onClick = { showProfileMenu = true }, modifier = Modifier.testTag("profile_menu")) {
                            Icon(imageVector = Icons.Default.MoreVert, contentDescription = "More Options", tint = MaterialTheme.colorScheme.onBackground)
                        }
                        DropdownMenu(
                            expanded = showProfileMenu,
                            onDismissRequest = { showProfileMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("Edit Profile") },
                                onClick = {
                                    showProfileMenu = false
                                    onNavigateToEditProfile()
                                },
                                leadingIcon = { Icon(Icons.Default.Edit, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Account Security") },
                                onClick = {
                                    showProfileMenu = false
                                    showSecurityDialog = true
                                },
                                leadingIcon = { Icon(Icons.Default.Security, null) }
                            )
                            DropdownMenuItem(
                                text = { Text("Logout", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showProfileMenu = false
                                    showLogoutConfirm1 = true
                                },
                                leadingIcon = { Icon(Icons.AutoMirrored.Filled.Logout, null, tint = MaterialTheme.colorScheme.error) }
                            )
                            DropdownMenuItem(
                                text = { Text("Delete Account", color = MaterialTheme.colorScheme.error) },
                                onClick = {
                                    showProfileMenu = false
                                    showDeleteAccountConfirm = true
                                },
                                leadingIcon = { Icon(Icons.Default.DeleteForever, null, tint = MaterialTheme.colorScheme.error) }
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .verticalScroll(rememberScrollState())
                .padding(horizontal = 20.dp)
                .padding(bottom = 24.dp),
            verticalArrangement = Arrangement.spacedBy(20.dp)
        ) {
            // Hero Profile Header Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Brush.linearGradient(colors = listOf(AccentBlue, Color(0xFF651FFF))))
                                .clickable {
                                    showPhotoOptionsDialog = true
                                },
                            contentAlignment = Alignment.Center
                        ) {
                            if (isUploadingPhoto) {
                                androidx.compose.material3.CircularProgressIndicator(
                                    modifier = Modifier.size(24.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else
                            if (userProfile.profileImageUrl.isNotBlank()) {
                                coil.compose.AsyncImage(
                                    model = com.example.utils.AttachmentHelper.getDisplayableImageModel(userProfile.profileImageUrl),
                                    contentDescription = "Profile Picture",
                                    modifier = Modifier.fillMaxSize(),
                                    contentScale = androidx.compose.ui.layout.ContentScale.Crop
                                )
                            } else {
                                val initials = userProfile.fullName.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }.mapNotNull { it.firstOrNull()?.uppercase() }.take(2).joinToString("").ifBlank { userProfile.fullName.take(2).uppercase().ifBlank { "ME" } }
                                Text(text = initials, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = userProfile.fullName, style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                            Text(text = "@${userProfile.username}", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                            androidx.compose.foundation.layout.Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                                androidx.compose.material3.Icon(
                                    imageVector = if (userProfile.isStudent) Icons.Default.School else Icons.Default.Work,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(text = "${userProfile.jobTitle} @ ${userProfile.company}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Text(text = userProfile.bio, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground.copy(alpha = 0.9f))

                    // AI Bio Polish Button
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .background(AccentBlue.copy(alpha = 0.12f))
                            .clickable {
                                if (!isEnhancingBio) {
                                    isEnhancingBio = true
                                    if (!isPro) { onNavigateToPaywall(); isEnhancingBio = false } else { onEnhanceBioWithAi {
                                        isEnhancingBio = false
                                    }
                                }
                                }
                            }
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = if (isEnhancingBio) "✨ Asteron AI is refining your pitch..." else "✨ Enhance Pitch Bio with Asteron AI",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                        Icon(imageVector = Icons.Default.AutoAwesome, contentDescription = "AI Enhance", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(16.dp))
                    }

                    // Phone Protection Badge (NETERO Lock Status)
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (phoneVis == PrivacyLevel.PRIVATE) Color(0xFFFFF3E0) else MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Lock,
                                contentDescription = "Phone Lock Status",
                                tint = if (phoneVis == PrivacyLevel.PRIVATE) Color(0xFFE65100) else AccentBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Column {
                                Text(
                                    text = "PHONE NUMBER PRIVACY",
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                                    color = if (phoneVis == PrivacyLevel.PRIVATE) Color(0xFFE65100) else AccentBlue
                                )
                                Text(
                                    text = when (phoneVis) {
                                        PrivacyLevel.PRIVATE -> "Private (${userProfile.phone.take(4)} •••• ${userProfile.phone.takeLast(2)}) — Hidden from everyone"
                                        PrivacyLevel.CONNECTIONS_ONLY -> "Connections Only (${userProfile.phone})"
                                        else -> "Public (${userProfile.phone})"
                                    },
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (phoneVis == PrivacyLevel.PRIVATE) Color(0xFF3E2723) else MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }

                    // Networking Goals
                    if (userProfile.networkingGoals.isNotBlank()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(12.dp)
                        ) {
                            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(text = "NETWORKING GOALS", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                Text(text = userProfile.networkingGoals, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground)
                            }
                        }
                    }

                    // Skills Flow
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(text = "SKILLS & EXPERTISE", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            userProfile.skills.forEach { skill ->
                                Box(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .padding(horizontal = 10.dp, vertical = 4.dp)
                                ) {
                                    Text(text = skill, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onBackground)
                                }
                            }
                        }
                    }

                    // PORTFOLIO & BUSINESS LINKS
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "PORTFOLIO & BUSINESS LINKS",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )

                        // Business Link Column
                        if (userProfile.businessUrl.isNotBlank()) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(AccentBlue.copy(alpha = 0.12f))
                                    .border(1.dp, AccentBlue.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                                    .clickable {
                                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(if (userProfile.businessUrl.startsWith("http")) userProfile.businessUrl else "https://${userProfile.businessUrl}"))
                                        try { context.startActivity(intent) } catch (e: Exception) {}
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Business, contentDescription = "Business Link", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                        Column {
                                            Text(text = "BUSINESS / STORE LINK", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                            Text(text = userProfile.businessUrl, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.onBackground)
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Website Link (Only display if user configured a real external website)
                        val cleanWebsite = userProfile.website.trim()
                        val hasValidWebsite = cleanWebsite.isNotBlank() && cleanWebsite.contains(".") && 
                            !cleanWebsite.equals("https://", ignoreCase = true) && 
                            !cleanWebsite.equals("http://", ignoreCase = true) && 
                            !cleanWebsite.contains("netero", ignoreCase = true)

                        if (hasValidWebsite) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable {
                                        val validUrl = if (cleanWebsite.startsWith("http://") || cleanWebsite.startsWith("https://")) cleanWebsite else "https://$cleanWebsite"
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try {
                                                uriHandler.openUri(validUrl)
                                            } catch (_: Exception) {
                                                Toast.makeText(context, "Could not open website: $validUrl", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Link, contentDescription = "Website", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                        Column {
                                            Text(text = "WEBSITE", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                                            Text(text = cleanWebsite, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onBackground)
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Portfolio Link
                        val cleanPortfolio = userProfile.portfolioUrl.trim()
                        val hasValidPortfolio = cleanPortfolio.isNotBlank() && cleanPortfolio.contains(".") && 
                            !cleanPortfolio.equals("https://", ignoreCase = true) && 
                            !cleanPortfolio.equals("http://", ignoreCase = true)

                        if (hasValidPortfolio) {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable {
                                        val validUrl = if (cleanPortfolio.startsWith("http://") || cleanPortfolio.startsWith("https://")) cleanPortfolio else "https://$cleanPortfolio"
                                        try {
                                            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(validUrl)).apply {
                                                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            }
                                            context.startActivity(intent)
                                        } catch (_: Exception) {
                                            try {
                                                uriHandler.openUri(validUrl)
                                            } catch (_: Exception) {
                                                Toast.makeText(context, "Could not open portfolio: $validUrl", Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                    }
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Icon(imageVector = Icons.Default.Link, contentDescription = "Portfolio", tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                        Column {
                                            Text(text = "PORTFOLIO / FEATURED WORK", style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.primary)
                                            Text(text = cleanPortfolio, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold), color = MaterialTheme.colorScheme.onBackground)
                                        }
                                    }
                                    Icon(imageVector = Icons.Default.ChevronRight, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                                }
                            }
                        }

                        // Public Card Link
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(12.dp))
                                .background(MaterialTheme.colorScheme.surfaceVariant)
                                .padding(horizontal = 12.dp, vertical = 8.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(text = "NETERO Username: @${userProfile.username}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
            
            Button(
                onClick = onNavigateToAnalytics,
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.Analytics, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("NETWORKING INSIGHTS", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.sp))
            }

            Button(
                onClick = { showPrivacySheet = true },
                modifier = Modifier.fillMaxWidth().height(48.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.1f)),
                shape = RoundedCornerShape(14.dp)
            ) {
                Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("NETERO LOCK PRIVACY", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium.copy(letterSpacing = 1.sp))
            }

            // App Actions
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Button(
                    onClick = {
                        val playStoreUrl = "https://play.google.com/store/apps/details?id=com.aistudio.netero.network.xpkq"
                        val intent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, "Connect with me on Netero! Download the app: $playStoreUrl\n\n${userProfile.fullName}\n${userProfile.jobTitle} at ${userProfile.company}")
                        }
                        context.startActivity(Intent.createChooser(intent, "Share Profile"))
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Share, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Share Profile", color = MaterialTheme.colorScheme.onBackground)
                }
                
                Button(
                    onClick = onNavigateToHelpDesk,
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.SupportAgent, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Help Desk & Inquiries", color = MaterialTheme.colorScheme.onBackground)
                }

                Button(
                    onClick = {
                        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://docs.google.com/document/d/e/2PACX-1vRyfV5Wofoe-3rK2-Bqsst4LiYiKwySHAonug3m1W5leyf8m9JSa_zpOOHByOezxlMqeVTiYU4JZ8Y1/pub"))
                        try {
                            context.startActivity(intent)
                        } catch (e: Exception) {}
                    },
                    modifier = Modifier.fillMaxWidth().height(48.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp)
                ) {
                    Icon(imageVector = Icons.Default.Policy, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Terms & Privacy Policy", color = MaterialTheme.colorScheme.onBackground)
                }
            }
        }
    }

    if (showLogoutConfirm1) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm1 = false },
            title = { Text("Log Out") },
            text = { Text("Are you sure you want to log out from this account?") },
            confirmButton = {
                Button(onClick = { showLogoutConfirm1 = false; showLogoutConfirm2 = true }) { Text("Log Out") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showLogoutConfirm1 = false }) { Text("Cancel") }
            }
        )
    }

    if (showLogoutConfirm2) {
        AlertDialog(
            onDismissRequest = { showLogoutConfirm2 = false },
            title = { Text("Are you absolutely sure?") },
            text = { Text("You will need to re-enter your credentials to access your account again. Do you want to proceed?") },
            confirmButton = {
                Button(onClick = { showLogoutConfirm2 = false; onLogout() }) { Text("Yes, Log Out") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showLogoutConfirm2 = false }) { Text("Cancel") }
            }
        )
    }

    if (showDeleteAccountConfirm) {
        AlertDialog(
            onDismissRequest = { showDeleteAccountConfirm = false },
            title = { Text("Delete Account") },
            text = { Text("Are you absolutely sure you want to delete your account? This action is permanent and cannot be undone. All your connections and profile data will be erased.") },
            confirmButton = {
                Button(
                    onClick = { 
                        showDeleteAccountConfirm = false
                        onDeleteAccount() 
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                ) { Text("Delete Account") }
            },
            dismissButton = {
                OutlinedButton(onClick = { showDeleteAccountConfirm = false }) { Text("Cancel") }
            }
        )
    }

    if (showPhotoOptionsDialog) {
        AlertDialog(
            onDismissRequest = { showPhotoOptionsDialog = false },
            title = { Text("Profile Photo", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Select how you want to update your profile photo:", style = MaterialTheme.typography.bodyMedium)
                    
                    Button(
                        onClick = {
                            showPhotoOptionsDialog = false
                            try {
                                photoPickerLauncher.launch(
                                    androidx.activity.result.PickVisualMediaRequest(
                                        androidx.activity.result.contract.ActivityResultContracts.PickVisualMedia.ImageOnly
                                    )
                                )
                            } catch (e: Exception) {
                                try {
                                    getContentLauncher.launch("image/*")
                                } catch (e2: Exception) {
                                    Toast.makeText(context, "Could not open photo picker", Toast.LENGTH_SHORT).show()
                                }
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Person, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("Upload from Device Gallery")
                    }

                    OutlinedButton(
                        onClick = {
                            showPhotoOptionsDialog = false
                            showPresetAvatarsSheet = true
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = AccentBlue)
                        Spacer(Modifier.width(8.dp))
                        Text("Choose Preset Professional Avatar")
                    }

                    if (userProfile.profileImageUrl.isNotBlank()) {
                        Button(
                            onClick = {
                                showPhotoOptionsDialog = false
                                onRemoveProfilePhoto()
                                android.widget.Toast.makeText(context, "Profile photo removed", android.widget.Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                        ) {
                            Icon(Icons.Default.DeleteForever, contentDescription = null)
                            Spacer(Modifier.width(8.dp))
                            Text("Delete Current Photo")
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                OutlinedButton(onClick = { showPhotoOptionsDialog = false }) { Text("Cancel") }
            }
        )
    }

    if (showPresetAvatarsSheet) {
        val presetAvatars = remember {
            listOf(
                "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=300&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=300&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=300&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=300&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1580489944761-15a19d654956?w=300&auto=format&fit=crop&q=80",
                "https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=300&auto=format&fit=crop&q=80"
            )
        }
        val scope = rememberCoroutineScope()
        ModalBottomSheet(
            onDismissRequest = { showPresetAvatarsSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp, vertical = 16.dp)
                    .padding(bottom = 32.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Text(
                    text = "Choose a Professional Avatar",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
                    color = MaterialTheme.colorScheme.onBackground
                )
                Text(
                    text = "Tap any curated executive portrait to instantly set as your profile photo:",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    presetAvatars.take(3).forEach { avatarUrl ->
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .border(2.dp, AccentBlue, CircleShape)
                                .clickable {
                                    showPresetAvatarsSheet = false
                                    isUploadingPhoto = true
                                    scope.launch(kotlinx.coroutines.Dispatchers.IO) {

                                        try {

                                            val localUri = com.example.utils.AttachmentHelper.downloadRemoteImageToCache(context, avatarUrl)

                                                ?: throw java.io.IOException("Avatar download failed")

                                            withContext(kotlinx.coroutines.Dispatchers.Main) {

                                                onUploadProfileImage(localUri) { success ->

                                                    isUploadingPhoto = false

                                                    val message = if (success) "Avatar updated!" else "Could not upload avatar"

                                                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

                                                }

                                            }

                                        } catch (e: Exception) {

                                            withContext(kotlinx.coroutines.Dispatchers.Main) {

                                                isUploadingPhoto = false

                                                Toast.makeText(context, "Could not set avatar", Toast.LENGTH_SHORT).show()

                                            }

                                        }

                                    }
                                }
                        ) {
                            coil.compose.AsyncImage(
                                model = avatarUrl,
                                contentDescription = "Preset Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    presetAvatars.drop(3).take(3).forEach { avatarUrl ->
                        Box(
                            modifier = Modifier
                                .size(88.dp)
                                .clip(CircleShape)
                                .border(2.dp, AccentBlue, CircleShape)
                                .clickable {
                                    showPresetAvatarsSheet = false
                                    isUploadingPhoto = true
                                    scope.launch(kotlinx.coroutines.Dispatchers.IO) {

                                        try {

                                            val localUri = com.example.utils.AttachmentHelper.downloadRemoteImageToCache(context, avatarUrl)

                                                ?: throw java.io.IOException("Avatar download failed")

                                            withContext(kotlinx.coroutines.Dispatchers.Main) {

                                                onUploadProfileImage(localUri) { success ->

                                                    isUploadingPhoto = false

                                                    val message = if (success) "Avatar updated!" else "Could not upload avatar"

                                                    Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

                                                }

                                            }

                                        } catch (e: Exception) {

                                            withContext(kotlinx.coroutines.Dispatchers.Main) {

                                                isUploadingPhoto = false

                                                Toast.makeText(context, "Could not set avatar", Toast.LENGTH_SHORT).show()

                                            }

                                        }

                                    }
                                }
                        ) {
                            coil.compose.AsyncImage(
                                model = avatarUrl,
                                contentDescription = "Preset Avatar",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = androidx.compose.ui.layout.ContentScale.Crop
                            )
                        }
                    }
                }
            }
        }
    }

    if (showSecurityDialog) {
        val userEmail = userProfile.email.ifBlank {
            context.getSharedPreferences("NeteroPrefs", android.content.Context.MODE_PRIVATE)
                .getString("user_email", "") ?: ""
        }

        AlertDialog(
            onDismissRequest = { showSecurityDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Security, contentDescription = null, tint = AccentBlue)
                    Spacer(Modifier.width(8.dp))
                    Text("Account Security")
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        "Your Netero account is secured with passwordless single-use OTP verification directly to your verified address.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
                            .border(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), RoundedCornerShape(12.dp))
                            .padding(12.dp)
                    ) {
                        Column(modifier = Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text("Verified Account Identifier", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            Text(
                                text = if (userEmail.isNotBlank()) userEmail else userProfile.phone.ifBlank { "Active Account" },
                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold),
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(Modifier.height(2.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Shield, null, tint = Color(0xFF10B981), modifier = Modifier.size(16.dp))
                                Spacer(Modifier.width(4.dp))
                                Text("Secured with Gmail SMTP OTP Verification", style = MaterialTheme.typography.labelSmall, color = Color(0xFF10B981))
                            }
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = { showSecurityDialog = false },
                    colors = ButtonDefaults.buttonColors(containerColor = AccentBlue)
                ) {
                    Text("Done")
                }
            }
        )
    }

    if (showPrivacySheet) {
        ModalBottomSheet(
            onDismissRequest = { showPrivacySheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 24.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(24.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Icon(imageVector = Icons.Default.Shield, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(24.dp))
                        Text(
                            text = "NETERO LOCK PRIVACY",
                            style = MaterialTheme.typography.titleMedium.copy(letterSpacing = 1.5.sp, fontWeight = FontWeight.Bold),
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }

                PrivacySettingSelector(
                    title = "Phone Visibility",
                    subtitle = "Who can view your contact phone number",
                    currentLevel = phoneVis,
                    onLevelSelected = {
                        phoneVis = it
                        onUpdateNeteroLock(phoneVis, emailVis, socialVis, discoveryVis, portfolioVis, roomVis)
                    }
                )

                PrivacySettingSelector(
                    title = "Email Visibility",
                    subtitle = "Who can view your professional email address",
                    currentLevel = emailVis,
                    onLevelSelected = {
                        emailVis = it
                        onUpdateNeteroLock(phoneVis, emailVis, socialVis, discoveryVis, portfolioVis, roomVis)
                    }
                )

                PrivacySettingSelector(
                    title = "Social Profiles Visibility",
                    subtitle = "LinkedIn, Website, Instagram links",
                    currentLevel = socialVis,
                    onLevelSelected = {
                        socialVis = it
                        onUpdateNeteroLock(phoneVis, emailVis, socialVis, discoveryVis, portfolioVis, roomVis)
                    }
                )

                PrivacySettingSelector(
                    title = "Portfolio / Featured Work Visibility",
                    subtitle = "Who can view your portfolio link",
                    currentLevel = portfolioVis,
                    onLevelSelected = {
                        portfolioVis = it
                        onUpdateNeteroLock(phoneVis, emailVis, socialVis, discoveryVis, portfolioVis, roomVis)
                    }
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = "Show Profile in Joined Rooms", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
                        Text(text = "Allow room members to view your card in participant feeds", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }

                    androidx.compose.material3.Switch(
                        checked = roomVis,
                        onCheckedChange = {
                            roomVis = it
                            onUpdateNeteroLock(phoneVis, emailVis, socialVis, discoveryVis, portfolioVis, roomVis)
                        },
                        colors = androidx.compose.material3.SwitchDefaults.colors(
                            checkedThumbColor = MaterialTheme.colorScheme.onBackground,
                            checkedTrackColor = AccentBlue,
                            uncheckedThumbColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            uncheckedTrackColor = MaterialTheme.colorScheme.surfaceVariant
                        )
                    )
                }
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }
}

@Composable
private fun PrivacySettingSelector(
    title: String,
    subtitle: String,
    currentLevel: PrivacyLevel,
    onLevelSelected: (PrivacyLevel) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold), color = MaterialTheme.colorScheme.onBackground)
        Text(text = subtitle, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf(PrivacyLevel.PUBLIC, PrivacyLevel.CONNECTIONS_ONLY, PrivacyLevel.PRIVATE).forEach { level ->
                val isSelected = (currentLevel == level)
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(10.dp))
                        .background(if (isSelected) AccentBlue else MaterialTheme.colorScheme.surfaceVariant)
                        .clickable { onLevelSelected(level) }
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = level.label,
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal),
                        color = if (isSelected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
