package com.example.utils

import android.app.Activity
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.IntentSenderRequest
import com.google.android.play.core.appupdate.AppUpdateInfo
import com.google.android.play.core.appupdate.AppUpdateManager
import com.google.android.play.core.appupdate.AppUpdateManagerFactory
import com.google.android.play.core.appupdate.AppUpdateOptions
import com.google.android.play.core.install.InstallStateUpdatedListener
import com.google.android.play.core.install.model.AppUpdateType
import com.google.android.play.core.install.model.InstallStatus
import com.google.android.play.core.install.model.UpdateAvailability

object InAppUpdateHelper {
    private const val TAG = "InAppUpdateHelper"
    private var appUpdateManager: AppUpdateManager? = null
    private var installListener: InstallStateUpdatedListener? = null

    /**
     * Checks Google Play Store for an updated version of the app.
     * If an update is available (via Google Play Console), prompts the user immediately
     * with Google Play's in-app update dialog (Flexible or Immediate, like Zomato).
     */
    fun checkForAppUpdate(
        activity: Activity,
        updateLauncher: ActivityResultLauncher<IntentSenderRequest>,
        onUpdateDownloaded: (() -> Unit)? = null
    ) {
        try {
            val manager = AppUpdateManagerFactory.create(activity)
            appUpdateManager = manager

            // Register listener for download progress & completion
            installListener = InstallStateUpdatedListener { state ->
                if (state.installStatus() == InstallStatus.DOWNLOADED) {
                    Log.d(TAG, "In-app update download completed. Ready to install.")
                    onUpdateDownloaded?.invoke()
                }
            }
            installListener?.let { manager.registerListener(it) }

            val appUpdateInfoTask = manager.appUpdateInfo
            appUpdateInfoTask.addOnSuccessListener { appUpdateInfo ->
                val availability = appUpdateInfo.updateAvailability()
                Log.d(TAG, "Update availability status: $availability")

                if (availability == UpdateAvailability.UPDATE_AVAILABLE) {
                    // Try Flexible update first (like Zomato), falling back to Immediate
                    val isFlexibleAllowed = appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.FLEXIBLE)
                    val isImmediateAllowed = appUpdateInfo.isUpdateTypeAllowed(AppUpdateType.IMMEDIATE)

                    val updateType = when {
                        isFlexibleAllowed -> AppUpdateType.FLEXIBLE
                        isImmediateAllowed -> AppUpdateType.IMMEDIATE
                        else -> null
                    }

                    if (updateType != null) {
                        try {
                            manager.startUpdateFlowForResult(
                                appUpdateInfo,
                                updateLauncher,
                                AppUpdateOptions.newBuilder(updateType).build()
                            )
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to start in-app update flow: ${e.message}")
                        }
                    }
                }
            }.addOnFailureListener { error ->
                Log.w(TAG, "Check for in-app update failed (normal outside Play Store/test builds): ${error.message}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "InAppUpdateHelper init error: ${e.message}")
        }
    }

    /**
     * Checks if a flexible update has already completed downloading in the background
     * and prompts the user to complete the installation.
     */
    fun resumeUpdateIfDownloaded(activity: Activity, onReadyToInstall: () -> Unit) {
        try {
            val manager = appUpdateManager ?: AppUpdateManagerFactory.create(activity)
            manager.appUpdateInfo.addOnSuccessListener { appUpdateInfo ->
                if (appUpdateInfo.installStatus() == InstallStatus.DOWNLOADED) {
                    onReadyToInstall()
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed checking downloaded state: ${e.message}")
        }
    }

    /**
     * Completes the update and restarts the app with the new version.
     */
    fun completeUpdate() {
        try {
            appUpdateManager?.completeUpdate()
        } catch (e: Exception) {
            Log.w(TAG, "Failed executing completeUpdate: ${e.message}")
        }
    }

    fun onDestroy() {
        try {
            installListener?.let { appUpdateManager?.unregisterListener(it) }
        } catch (_: Exception) {}
        installListener = null
        appUpdateManager = null
    }
}
