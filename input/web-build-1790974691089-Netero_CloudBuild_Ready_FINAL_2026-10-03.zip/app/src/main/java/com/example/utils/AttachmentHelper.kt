package com.example.utils

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.util.Base64
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream

object AttachmentHelper {

    /**
     * Converts image URLs, Base64 data URIs, or local file URIs into a format Coil can render natively.
     */
    fun getDisplayableImageModel(urlOrData: String?): Any? {
        if (urlOrData.isNullOrBlank()) return null
        val trimmed = urlOrData.trim()
        return if (trimmed.startsWith("data:image")) {
            try {
                val commaIndex = trimmed.indexOf(",")
                if (commaIndex != -1) {
                    val base64 = trimmed.substring(commaIndex + 1).replace("\n", "").replace("\r", "").trim()
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    bytes
                } else {
                    trimmed
                }
            } catch (e: Exception) {
                trimmed
            }
        } else if (trimmed.startsWith("file:")) {
            try {
                val path = Uri.parse(trimmed).path
                if (path != null) {
                    val file = File(path)
                    if (file.exists()) file else Uri.parse(trimmed)
                } else {
                    Uri.parse(trimmed)
                }
            } catch (e: Exception) {
                trimmed
            }
        } else if (trimmed.startsWith("/") && File(trimmed).exists()) {
            File(trimmed)
        } else {
            trimmed
        }
    }

    /**
     * Downscales and compresses image bytes to JPEG with max dimensions and target quality.
     * Guarantees image size is kept under ~50KB so it never breaches Firestore limits or causes OOM.
     */
    fun compressImage(bytes: ByteArray, maxDimension: Int = 600, quality: Int = 75): ByteArray {
        return try {
            val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeByteArray(bytes, 0, bytes.size, options)
            
            val origWidth = options.outWidth
            val origHeight = options.outHeight
            if (origWidth <= 0 || origHeight <= 0) return bytes

            var sampleSize = 1
            while ((origWidth / sampleSize) > (maxDimension * 1.5) || (origHeight / sampleSize) > (maxDimension * 1.5)) {
                sampleSize *= 2
            }

            val decodeOptions = BitmapFactory.Options().apply {
                inSampleSize = sampleSize
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, decodeOptions) ?: return bytes

            val rotatedBitmap = try {
                val exif = androidx.exifinterface.media.ExifInterface(java.io.ByteArrayInputStream(bytes))
                val orientation = exif.getAttributeInt(
                    androidx.exifinterface.media.ExifInterface.TAG_ORIENTATION,
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_NORMAL
                )
                val matrix = android.graphics.Matrix()
                when (orientation) {
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_90 -> matrix.postRotate(90f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_180 -> matrix.postRotate(180f)
                    androidx.exifinterface.media.ExifInterface.ORIENTATION_ROTATE_270 -> matrix.postRotate(270f)
                    else -> null
                }
                if (matrix.isIdentity) bitmap else Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
            } catch (_: Exception) {
                bitmap
            }

            val currentWidth = rotatedBitmap.width
            val currentHeight = rotatedBitmap.height
            val scale = (maxDimension.toFloat() / maxOf(currentWidth, currentHeight)).coerceAtMost(1.0f)
            val finalWidth = (currentWidth * scale).toInt().coerceAtLeast(1)
            val finalHeight = (currentHeight * scale).toInt().coerceAtLeast(1)

            val scaledBitmap = if (scale < 1.0f) {
                Bitmap.createScaledBitmap(rotatedBitmap, finalWidth, finalHeight, true)
            } else {
                rotatedBitmap
            }

            val out = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, quality, out)
            val compressed = out.toByteArray()
            if (compressed.isNotEmpty()) compressed else bytes
        } catch (e: Exception) {
            bytes
        }
    }


    /**
     * Creates a small, upload-friendly JPEG from a gallery/content URI without
     * reading the original file into a ByteArray. Used for profile photos so
     * large camera images upload quickly and predictably.
     */
    fun prepareImageForUpload(context: Context, uri: Uri, maxDimension: Int = 1280, quality: Int = 82): Uri? {
        return try {
            val resolver = context.contentResolver
            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
            if (bounds.outWidth <= 0 || bounds.outHeight <= 0) return null

            var sample = 1
            while ((bounds.outWidth / sample) > maxDimension * 2 || (bounds.outHeight / sample) > maxDimension * 2) {
                sample *= 2
            }
            val options = BitmapFactory.Options().apply {
                inSampleSize = sample
                inPreferredConfig = Bitmap.Config.ARGB_8888
            }
            val bitmap = resolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) } ?: return null
            val scale = (maxDimension.toFloat() / maxOf(bitmap.width, bitmap.height)).coerceAtMost(1f)
            val width = (bitmap.width * scale).toInt().coerceAtLeast(1)
            val height = (bitmap.height * scale).toInt().coerceAtLeast(1)
            val scaled = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, width, height, true) else bitmap

            val outFile = File(context.cacheDir, "netero_profile_${System.currentTimeMillis()}.jpg")
            FileOutputStream(outFile).use { output ->
                scaled.compress(Bitmap.CompressFormat.JPEG, quality, output)
            }
            if (scaled !== bitmap) scaled.recycle()
            bitmap.recycle()
            Uri.fromFile(outFile)
        } catch (e: Exception) {
            null
        }
    }

    /**
     * Streams a remote image into the app cache so profile upload never materializes
     * the full network response as a ByteArray.
     */
    fun downloadRemoteImageToCache(context: Context, url: String): Uri? {
        return try {
            val connection = (java.net.URL(url).openConnection() as java.net.HttpURLConnection).apply {
                connectTimeout = 10_000
                readTimeout = 15_000
                instanceFollowRedirects = true
                requestMethod = "GET"
                connect()
            }
            if (connection.responseCode !in 200..299) {
                connection.disconnect()
                return null
            }
            val target = File(context.cacheDir, "netero_avatar_${System.currentTimeMillis()}.jpg")
            connection.inputStream.use { input ->
                FileOutputStream(target).use { output ->
                    input.copyTo(output, 64 * 1024)
                }
            }
            connection.disconnect()
            Uri.fromFile(target)
        } catch (_: Exception) {
            null
        }
    }

    /**
     * Opens or downloads a document attachment cleanly.
     * Decodes Base64 data URIs into a temporary cached file and launches an Intent
     * with FileProvider content:// URI so PDF readers, Word, and Google Drive can open it.
     */
    fun openDocument(context: Context, attachmentUrl: String, mimeTypeOverride: String? = null, filename: String = "document") {
        try {
            if (attachmentUrl.startsWith("data:")) {
                // Parse MIME type and Base64 content
                val commaIndex = attachmentUrl.indexOf(",")
                if (commaIndex == -1) {
                    Toast.makeText(context, "Invalid document data", Toast.LENGTH_SHORT).show()
                    return
                }
                val header = attachmentUrl.substring(0, commaIndex)
                val base64Data = attachmentUrl.substring(commaIndex + 1)
                val mimeType = mimeTypeOverride?.takeIf { it.isNotBlank() } ?: if (header.contains(";")) {
                    header.substringAfter("data:").substringBefore(";")
                } else {
                    "application/octet-stream"
                }
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeType) ?: "bin"
                val docsDir = File(context.cacheDir, "documents").apply { if (!exists()) mkdirs() }
                val targetFile = File(docsDir, "${filename.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)}_${System.currentTimeMillis()}.$ext")

                val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
                FileOutputStream(targetFile).use { it.write(decodedBytes) }

                launchViewIntent(context, targetFile, mimeType)
            } else if (attachmentUrl.startsWith("file:")) {
                val path = Uri.parse(attachmentUrl).path
                if (path != null) {
                    val file = File(path)
                    if (file.exists()) {
                        val ext = file.extension.ifBlank { "pdf" }
                        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext) ?: "application/pdf"
                        launchViewIntent(context, file, mime)
                        return
                    }
                }
                Toast.makeText(context, "Local file not found", Toast.LENGTH_SHORT).show()
            } else if (attachmentUrl.startsWith("http://") || attachmentUrl.startsWith("https://")) {
                try {
                    val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mimeTypeOverride ?: "")
                        ?: MimeTypeMap.getFileExtensionFromUrl(attachmentUrl).ifBlank { "bin" }
                    val safeBase = filename.replace(Regex("[^A-Za-z0-9._-]"), "_").take(120)
                    val target = File(context.cacheDir, "netero_docs").apply { if (!exists()) mkdirs() }
                    val targetFile = File(target, "${safeBase}_${System.currentTimeMillis()}.$ext")
                    val storageRef = com.google.firebase.storage.FirebaseStorage.getInstance().getReferenceFromUrl(attachmentUrl)
                    storageRef.getFile(targetFile)
                        .addOnSuccessListener {
                            val mime = mimeTypeOverride?.takeIf { it.isNotBlank() }
                                ?: MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext)
                                ?: "application/octet-stream"
                            launchViewIntent(context, targetFile, mime)
                        }
                        .addOnFailureListener { error ->
                            Toast.makeText(context, "Download failed: ${error.message ?: "unknown error"}", Toast.LENGTH_LONG).show()
                        }
                    Toast.makeText(context, "Downloading document...", Toast.LENGTH_SHORT).show()
                } catch (e: Exception) {
                    Toast.makeText(context, "Could not download document: ${e.message}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(context, "Cannot open attachment format", Toast.LENGTH_SHORT).show()
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Document handler error: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Saves photo to device's public Downloads / Gallery.
     */
    fun saveImageToGallery(context: Context, urlOrData: String) {
        try {
            if (urlOrData.startsWith("data:image")) {
                val commaIndex = urlOrData.indexOf(",")
                if (commaIndex != -1) {
                    val base64 = urlOrData.substring(commaIndex + 1).replace("\n", "").trim()
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) downloadsDir.mkdirs()
                    val file = File(downloadsDir, "netero_photo_${System.currentTimeMillis()}.jpg")
                    FileOutputStream(file).use { it.write(bytes) }
                    val mediaScanIntent = Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE)
                    mediaScanIntent.data = Uri.fromFile(file)
                    context.sendBroadcast(mediaScanIntent)
                    Toast.makeText(context, "Photo saved to Downloads / Gallery!", Toast.LENGTH_SHORT).show()
                }
            } else if (urlOrData.startsWith("http://") || urlOrData.startsWith("https://")) {
                val dm = context.getSystemService(Context.DOWNLOAD_SERVICE) as? android.app.DownloadManager
                val uri = Uri.parse(urlOrData)
                val cleanFilename = "netero_photo_${System.currentTimeMillis()}.jpg"
                if (dm != null) {
                    val request = android.app.DownloadManager.Request(uri).apply {
                        setTitle(cleanFilename)
                        setDescription("Saving image to device...")
                        setNotificationVisibility(android.app.DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        setDestinationInExternalPublicDir(android.os.Environment.DIRECTORY_DOWNLOADS, cleanFilename)
                    }
                    dm.enqueue(request)
                    Toast.makeText(context, "Saving photo to Downloads...", Toast.LENGTH_SHORT).show()
                }
            } else if (urlOrData.startsWith("file:")) {
                val srcFile = File(Uri.parse(urlOrData).path ?: "")
                if (srcFile.exists()) {
                    val downloadsDir = android.os.Environment.getExternalStoragePublicDirectory(android.os.Environment.DIRECTORY_DOWNLOADS)
                    if (!downloadsDir.exists()) downloadsDir.mkdirs()
                    val target = File(downloadsDir, "netero_photo_${System.currentTimeMillis()}.jpg")
                    srcFile.copyTo(target, overwrite = true)
                    Toast.makeText(context, "Photo saved to Downloads / Gallery!", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) {
            Toast.makeText(context, "Could not save photo: ${e.message}", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchViewIntent(context: Context, file: File, mimeType: String) {
        val authority = "${context.packageName}.fileprovider"
        val contentUri = FileProvider.getUriForFile(context, authority, file)

        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(contentUri, mimeType)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        try {
            context.startActivity(intent)
        } catch (e: Exception) {
            // Fallback: offer to share the file so user can pick any app
            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, contentUri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            }
            try {
                context.startActivity(Intent.createChooser(shareIntent, "Open with...").apply {
                    addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                })
            } catch (ex: Exception) {
                Toast.makeText(context, "No app installed to view $mimeType files", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
