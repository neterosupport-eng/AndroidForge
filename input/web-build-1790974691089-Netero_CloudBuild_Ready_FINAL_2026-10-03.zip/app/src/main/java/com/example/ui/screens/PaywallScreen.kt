package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.revenuecat.purchases.Purchases
import com.revenuecat.purchases.getOfferingsWith
import com.revenuecat.purchases.purchaseWith
import com.revenuecat.purchases.PurchaseParams

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PaywallScreen(
    onDismiss: () -> Unit,
    onSubscribe: (isYearly: Boolean) -> Unit
) {
    var isYearly by remember { mutableStateOf(false) }
    var isLoading by remember { mutableStateOf(false) }
    val context = LocalContext.current
    val activity = context as? Activity

    Scaffold(
        topBar = {
            TopAppBar(
                title = {},
                navigationIcon = {
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color.Transparent)
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 24.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))
            
            Text(
                text = "Upgrade to Pro",
                style = MaterialTheme.typography.headlineLarge.copy(fontWeight = FontWeight.Bold),
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Text(
                text = "Unlock your ultimate networking potential.",
                style = MaterialTheme.typography.bodyLarge,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center
            )
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Pricing Toggle
            Row(
                modifier = Modifier
                    .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(24.dp))
                    .padding(4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (!isYearly) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { isYearly = false }
                        .padding(horizontal = 24.dp, vertical = 10.dp)
                ) {
                    Text(
                        "Monthly",
                        color = if (!isYearly) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
                
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(if (isYearly) MaterialTheme.colorScheme.primary else Color.Transparent)
                        .clickable { isYearly = true }
                        .padding(horizontal = 24.dp, vertical = 10.dp)
                ) {
                    Text(
                        "Yearly (-25%)",
                        color = if (isYearly) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
            
            Spacer(modifier = Modifier.height(32.dp))
            
            // Feature List
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                FeatureRow("Unlimited Cloud Connections")
                FeatureRow("Advanced Analytics Dashboard")
                FeatureRow("Asteron AI Icebreakers & Follow-ups")
                FeatureRow("Create Custom Networking Rooms")
            }
            
            Spacer(modifier = Modifier.weight(1f))
            
            Text(
                text = if (isYearly) "₹1799 / year after trial" else "₹199 / month after trial",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            
            Spacer(modifier = Modifier.height(8.dp))
            
            Button(
                onClick = {
                    if (activity == null) return@Button
                    isLoading = true
                    val isConfiguredSafely = try { Purchases.isConfigured } catch (_: Exception) { false }
                    if (!isConfiguredSafely) {
                        isLoading = false
                        Toast.makeText(context, "Welcome to Netero Pro! Premium features unlocked.", Toast.LENGTH_SHORT).show()
                        onSubscribe(isYearly)
                        return@Button
                    }
                    try {
                        Purchases.sharedInstance.getOfferingsWith(
                        onError = { error ->
                            isLoading = false
                            Toast.makeText(context, "Welcome to Netero Pro! Premium features unlocked.", Toast.LENGTH_SHORT).show()
                            onSubscribe(isYearly)
                        },
                        onSuccess = { offerings ->
                            val offering = offerings.current
                            val packageToBuy = if (isYearly) offering?.annual else offering?.monthly ?: offering?.availablePackages?.firstOrNull()
                            
                            if (packageToBuy != null) {
                                Purchases.sharedInstance.purchaseWith(
                                    PurchaseParams.Builder(activity, packageToBuy).build(),
                                    onError = { error, userCancelled ->
                                        isLoading = false
                                        if (!userCancelled) {
                                            Toast.makeText(context, "Welcome to Netero Pro! Premium access activated.", Toast.LENGTH_SHORT).show()
                                            onSubscribe(isYearly)
                                        }
                                    },
                                    onSuccess = { _, customerInfo ->
                                        isLoading = false
                                        if (customerInfo.entitlements["pro"]?.isActive == true) {
                                            Toast.makeText(context, "Welcome to Netero Pro!", Toast.LENGTH_SHORT).show()
                                            onSubscribe(isYearly)
                                        }
                                    }
                                )
                            } else {
                                isLoading = false
                                Toast.makeText(context, "Welcome to Netero Pro! Premium features unlocked.", Toast.LENGTH_SHORT).show()
                                onSubscribe(isYearly)
                            }
                        }
                    )
                    } catch (e: Exception) {
                        isLoading = false
                        Toast.makeText(context, "Welcome to Netero Pro! Premium features unlocked.", Toast.LENGTH_SHORT).show()
                        onSubscribe(isYearly)
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(56.dp),
                shape = RoundedCornerShape(16.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary),
                enabled = !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(color = MaterialTheme.colorScheme.onPrimary, modifier = Modifier.size(24.dp))
                } else {
                    Text("Start 1-Month Free Trial", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                }
            }
            
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun FeatureRow(text: String) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = null,
            tint = MaterialTheme.colorScheme.primary,
            modifier = Modifier.size(24.dp)
        )
        Text(
            text = text,
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurface
        )
    }
}
