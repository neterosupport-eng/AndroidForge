package com.example

import com.example.data.model.RecommendedPerson
import com.example.data.model.UserProfile
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class NeteroAiAndSyncTest {

    @Test
    fun testCorruptProfileFiltering() {
        val testProfiles = listOf(
            RecommendedPerson(id = "1", name = ".", jobTitle = "Engineer", company = "Tech"),
            RecommendedPerson(id = "2", name = "..", jobTitle = "Designer", company = "DesignCo"),
            RecommendedPerson(id = "3", name = "", jobTitle = "VP", company = "Corp"),
            RecommendedPerson(id = "4", name = "123", jobTitle = "Lead", company = "SAS"),
            RecommendedPerson(id = "5", name = "Sarah Jenkins", jobTitle = "VP Product", company = "SAS Institute"),
            RecommendedPerson(id = "6", name = "David Kim", jobTitle = ".", company = "."),
            RecommendedPerson(id = "7", name = "Elena Rostova", jobTitle = "Senior Engineer", company = "Enterprise SaaS")
        )

        val validList = testProfiles.filter { p ->
            p.name.isNotBlank() &&
            p.name.trim() != "." &&
            p.name.trim() != ".." &&
            p.name.length >= 2 &&
            p.name.any { it.isLetter() } &&
            (p.jobTitle.isNotBlank() || p.company.isNotBlank()) &&
            (p.jobTitle != "." && p.company != ".")
        }

        assertEquals(2, validList.size)
        assertTrue(validList.any { it.name == "Sarah Jenkins" })
        assertTrue(validList.any { it.name == "Elena Rostova" })
        assertFalse(validList.any { it.name == "." })
        assertFalse(validList.any { it.name == ".." })
    }

    @Test
    fun testPersonalizedSearchDifferentiatesForDifferentUsers() {
        // Two users with different roles, industries, and networks searching the exact same query "SAS"
        val userFounder = UserProfile(
            username = "founder_alice",
            fullName = "Alice Founder",
            jobTitle = "CEO & Founder",
            company = "Apex AI",
            industry = "Artificial Intelligence",
            connectionIds = listOf("conn_investor_1", "conn_investor_2"),
            interests = listOf("Venture Capital", "Scaling", "AI")
        )

        val userEngineer = UserProfile(
            username = "eng_bob",
            fullName = "Bob Engineer",
            jobTitle = "Staff Software Engineer",
            company = "DevCorp",
            industry = "Software",
            connectionIds = listOf("conn_eng_1", "conn_eng_2", "conn_eng_3"),
            interests = listOf("Kotlin", "Cloud Architecture", "Distributed Systems")
        )

        val candidates = listOf(
            RecommendedPerson(
                id = "cand_1",
                name = "Marcus Vance",
                jobTitle = "General Partner & SaaS Investor",
                company = "SAS Ventures",
                industry = "Venture Capital",
                connectionIds = listOf("conn_investor_1"), // Mutual with Alice
                sharedInterests = listOf("Venture Capital", "Scaling")
            ),
            RecommendedPerson(
                id = "cand_2",
                name = "Liam Chen",
                jobTitle = "Lead Cloud Architect",
                company = "SAS Cloud Solutions",
                industry = "Software",
                connectionIds = listOf("conn_eng_1", "conn_eng_2"), // Mutual with Bob
                sharedInterests = listOf("Cloud Architecture", "Distributed Systems")
            )
        )

        fun scoreCandidate(user: UserProfile, person: RecommendedPerson): Int {
            val myIds = user.connectionIds.toSet()
            val mutualCount = person.connectionIds.intersect(myIds).size
            var score = mutualCount * 25

            val userRole = user.jobTitle.lowercase()
            val candidateRole = person.jobTitle.lowercase()
            val sharedInterests = user.interests.map { it.lowercase() }.intersect(person.sharedInterests.map { it.lowercase() }.toSet())
            score += sharedInterests.size * 12

            if (user.industry.isNotBlank() && person.industry.equals(user.industry, ignoreCase = true)) {
                score += 15
            }

            if ((userRole.contains("founder") || userRole.contains("ceo")) && (candidateRole.contains("investor") || candidateRole.contains("partner"))) {
                score += 30
            }
            if ((userRole.contains("engineer") || userRole.contains("developer")) && (candidateRole.contains("architect") || candidateRole.contains("lead"))) {
                score += 25
            }

            val userSeed = kotlin.math.abs((user.username.hashCode() xor person.id.hashCode())) % 20
            score += userSeed

            return score
        }

        val aliceCandidate1Score = scoreCandidate(userFounder, candidates[0])
        val aliceCandidate2Score = scoreCandidate(userFounder, candidates[1])
        val aliceTop = if (aliceCandidate1Score > aliceCandidate2Score) candidates[0] else candidates[1]

        val bobCandidate1Score = scoreCandidate(userEngineer, candidates[0])
        val bobCandidate2Score = scoreCandidate(userEngineer, candidates[1])
        val bobTop = if (bobCandidate1Score > bobCandidate2Score) candidates[0] else candidates[1]

        // Alice (CEO) should get Marcus (SaaS Investor) as top match
        assertEquals("Marcus Vance", aliceTop.name)
        // Bob (Engineer) should get Liam (Lead Cloud Architect) as top match
        assertEquals("Liam Chen", bobTop.name)

        // Verifies the two users do NOT get identical recommendations for the query "SAS"
        assertNotEquals(aliceTop.id, bobTop.id)
    }

    @Test
    fun testMutualConnectionsCalculation() {
        val myConnectionIds = setOf("id_alex", "id_clara", "id_dan")
        val candidateConnectionIds = listOf("id_alex", "id_dan", "id_eva", "id_felix")

        val mutualCount = candidateConnectionIds.intersect(myConnectionIds).size
        assertEquals(2, mutualCount)
    }

    @Test
    fun testStrictQrFilteringRejectsPaymentAndRandomQrs() {
        fun isValidNeteroQr(qr: String): Boolean {
            val isRoomQr = qr.startsWith("netero://room/") || qr.startsWith("NETERO_ROOM:") || qr.startsWith("https://netero.in/room/") || qr.startsWith("https://netero.app/room/")
            val isNeteroProfileQr = qr.startsWith("https://netero.in/profile/") || 
                qr.startsWith("https://netero.app/p/") || 
                qr.startsWith("netero://profile/") || 
                qr.startsWith("NETERO_ID:") ||
                (qr.startsWith("BEGIN:VCARD") && (qr.contains("NETERO", ignoreCase = true) || qr.contains("X-NETERO", ignoreCase = true)))
            return isRoomQr || isNeteroProfileQr
        }

        // PhonePe, Paytm, Google Pay, UPI tests MUST be rejected (return false)
        val phonePeQr1 = "upi://pay?pa=merchant9876@ybl&pn=Store&mc=5411"
        val phonePeQr2 = "https://phon.pe/ru?id=P998877"
        val paytmQr = "upi://pay?pa=paytmqr2810@paytm&pn=TeaStall"
        val gpayQr = "upi://pay?pa=john@okaxis&pn=John"
        val randomUrl = "https://example.com/menu.pdf"
        val genericVCard = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Random Person\r\nTEL:1234567890\r\nEND:VCARD"

        assertFalse("PhonePe UPI QR must be rejected", isValidNeteroQr(phonePeQr1))
        assertFalse("PhonePe short URL QR must be rejected", isValidNeteroQr(phonePeQr2))
        assertFalse("Paytm UPI QR must be rejected", isValidNeteroQr(paytmQr))
        assertFalse("GPay UPI QR must be rejected", isValidNeteroQr(gpayQr))
        assertFalse("Random Web URL must be rejected", isValidNeteroQr(randomUrl))
        assertFalse("Generic non-Netero vCard must be rejected", isValidNeteroQr(genericVCard))

        // Valid Netero QRs MUST be accepted (return true)
        val neteroRoom1 = "netero://room/tech_builders_bangalore"
        val neteroRoom2 = "NETERO_ROOM:room_123"
        val neteroProfileUrl = "https://netero.in/profile/rahulreddy"
        val neteroId = "NETERO_ID:user_999"
        val neteroVCard = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN:Rahul\r\nX-NETERO-USER:rahulreddy\r\nNOTE:NETERO_UID:u123\r\nEND:VCARD"

        assertTrue("Netero deep link room QR must be accepted", isValidNeteroQr(neteroRoom1))
        assertTrue("Netero prefix room QR must be accepted", isValidNeteroQr(neteroRoom2))
        assertTrue("Netero web profile URL must be accepted", isValidNeteroQr(neteroProfileUrl))
        assertTrue("Netero ID must be accepted", isValidNeteroQr(neteroId))
        assertTrue("Netero vCard with user metadata must be accepted", isValidNeteroQr(neteroVCard))
    }

    @Test
    fun testLiveSyncUpdatesConnectionNameWhenOppositeUserChangesName() {
        // User A originally connected with User B ("Rahul")
        val existingConnection = com.example.data.model.ConnectionContact(
            id = "user_b_uid",
            name = "Rahul",
            jobTitle = "Software Developer",
            company = "OldCo",
            dateConnected = "Today",
            avatarInitial = "R",
            notes = "Met at event. UID:user_b_uid|USER:rahulreddy"
        )

        // User B changes their name to "Rahul Reddy" and company to "TechCorp" in Cloud Firestore
        val cloudProfile = UserProfile(
            id = "user_b_uid",
            username = "rahulreddy",
            fullName = "Rahul Reddy",
            jobTitle = "Lead Architect",
            company = "TechCorp"
        )

        val allProfiles = listOf(cloudProfile)
        val profilesById = allProfiles.filter { it.id.isNotBlank() }.associateBy { it.id.lowercase() }
        val profilesByUsername = allProfiles.filter { it.username.isNotBlank() }.associateBy { it.username.lowercase() }

        val cleanContactId = existingConnection.id.removePrefix("c_").removePrefix("req_").lowercase()
        val noteUid = Regex("UID:([a-zA-Z0-9_.-]+)").find(existingConnection.notes)?.groupValues?.get(1)?.lowercase()
        val noteUser = Regex("USER:([a-zA-Z0-9_.-]+)").find(existingConnection.notes)?.groupValues?.get(1)?.lowercase()

        val matchingProfile = profilesById[cleanContactId]
            ?: profilesByUsername[cleanContactId]
            ?: (if (noteUid != null) profilesById[noteUid] ?: profilesByUsername[noteUid] else null)
            ?: (if (noteUser != null) profilesByUsername[noteUser] ?: profilesById[noteUser] else null)

        assertTrue("Should find matching cloud profile by ID or note metadata", matchingProfile != null)
        assertEquals("Rahul Reddy", matchingProfile!!.fullName)
        assertEquals("TechCorp", matchingProfile.company)
        assertEquals("Lead Architect", matchingProfile.jobTitle)

        // Simulate updated connection contact
        val updatedContact = existingConnection.copy(
            name = matchingProfile.fullName,
            jobTitle = matchingProfile.jobTitle,
            company = matchingProfile.company
        )
        assertEquals("Rahul Reddy", updatedContact.name)
        assertNotEquals(existingConnection.name, updatedContact.name)
    }

    @Test
    fun testAppUpdatePersistenceKeepsUserLoggedIn() {
        // Simulate scenario where app is updated from an older version that stored username in legacy NeteroPrefs
        val legacyName = "Rahul Reddy"
        val legacyUsername = "rahulreddy262006"
        val neteroPrefsHasLoggedIn = false
        val legacyPrefsHasLoggedIn = true

        val hasProfile = legacyName.isNotBlank() || legacyUsername.isNotBlank()
        val hasAuth = false
        val isLoggedIn = neteroPrefsHasLoggedIn || legacyPrefsHasLoggedIn || hasProfile || hasAuth

        assertTrue("User must remain logged in after update if profile or legacy flag exists", isLoggedIn)
    }

    @Test
    fun testVCardExtractionWithParameters() {
        val rawVCard = "BEGIN:VCARD\r\nVERSION:3.0\r\nFN;CHARSET=UTF-8:Rahul Reddy\r\nTITLE;CHARSET=UTF-8:Founder & CEO\r\nORG:Netero Inc\r\nEMAIL;TYPE=INTERNET:rahul@netero.app\r\nTEL;TYPE=CELL:+919876543210\r\nURL:https://linkedin.com/in/rahulreddy\r\nX-NETERO-USER:rahulreddy\r\nNOTE;CHARSET=UTF-8:NETERO_UID:uid_998877|USER:rahulreddy|INDUSTRY:Artificial Intelligence\r\nEND:VCARD"

        var name = ""
        var role = ""
        var company = ""
        var email = ""
        var phone = ""
        var linkedin = ""
        var username = ""
        var neteroUid = ""
        var industry = ""

        rawVCard.lines().forEach { line ->
            val trimmed = line.trim()
            if (trimmed.startsWith("FN:", ignoreCase = true) || trimmed.startsWith("FN;", ignoreCase = true)) name = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("TITLE:", ignoreCase = true) || trimmed.startsWith("TITLE;", ignoreCase = true)) role = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("ORG:", ignoreCase = true) || trimmed.startsWith("ORG;", ignoreCase = true)) company = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("EMAIL:", ignoreCase = true) || trimmed.startsWith("EMAIL;", ignoreCase = true)) email = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("TEL:", ignoreCase = true) || trimmed.startsWith("TEL;", ignoreCase = true)) phone = trimmed.substringAfter(":").trim()
            else if ((trimmed.startsWith("URL:", ignoreCase = true) || trimmed.startsWith("URL;", ignoreCase = true)) && trimmed.contains("linkedin", ignoreCase = true)) linkedin = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("X-NETERO-USER:", ignoreCase = true) || trimmed.startsWith("X-NETERO-USER;", ignoreCase = true)) username = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("X-NETERO-INDUSTRY:", ignoreCase = true) || trimmed.startsWith("X-NETERO-INDUSTRY;", ignoreCase = true)) industry = trimmed.substringAfter(":").trim()
            else if (trimmed.startsWith("NOTE", ignoreCase = true) && trimmed.contains("NETERO_UID:")) {
                val note = trimmed.substringAfter(":").trim()
                val uMatch = Regex("NETERO_UID:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                if (!uMatch.isNullOrBlank()) neteroUid = uMatch
                val indMatch = Regex("INDUSTRY:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                if (!indMatch.isNullOrBlank()) industry = indMatch
                val userMatch = Regex("USER:([^|]+)").find(note)?.groupValues?.get(1)?.trim()
                if (!userMatch.isNullOrBlank()) username = userMatch
            }
        }

        assertEquals("Rahul Reddy", name)
        assertEquals("Founder & CEO", role)
        assertEquals("Netero Inc", company)
        assertEquals("rahul@netero.app", email)
        assertEquals("+919876543210", phone)
        assertEquals("https://linkedin.com/in/rahulreddy", linkedin)
        assertEquals("rahulreddy", username)
        assertEquals("uid_998877", neteroUid)
        assertEquals("Artificial Intelligence", industry)
    }

    @Test
    fun testAskAiAnswersCasualQuestionsMultipleTimes() = kotlinx.coroutines.runBlocking {
        // Test 1: Casual humor query
        val jokeResponse = com.example.data.api.GeminiAiHelper.generateText("Tell me a funny programming joke")
        assertTrue("Joke response should not be blank", jokeResponse.isNotBlank())
        assertTrue("Should contain humorous or conversational content", jokeResponse.length > 10)

        // Test 2: Casual greeting query
        val greetingResponse = com.example.data.api.GeminiAiHelper.generateText("How are you doing today?")
        assertTrue("Greeting response should not be blank", greetingResponse.isNotBlank())
        assertTrue("Greeting response should be warm and conversational", greetingResponse.contains("great", ignoreCase = true) || greetingResponse.contains("doing", ignoreCase = true) || greetingResponse.length > 15)

        // Test 3: Daily routine query
        val morningResponse = com.example.data.api.GeminiAiHelper.generateText("Good morning! Give me a quick thought for the day")
        assertTrue("Morning response should not be blank", morningResponse.isNotBlank())
        assertTrue("Morning response should be inspiring", morningResponse.length > 15)

        // Test 4: Networking & career question
        val networkingResponse = com.example.data.api.GeminiAiHelper.generateText("How should I follow up with a founder after a conference?")
        assertTrue("Networking response should not be blank", networkingResponse.isNotBlank())
        assertTrue("Should contain actionable networking advice", networkingResponse.contains("follow", ignoreCase = true) || networkingResponse.contains("meeting", ignoreCase = true) || networkingResponse.length > 20)
    }

    @Test
    fun testIndustrySpecificFollowUpDraftsAreDistinct() = kotlinx.coroutines.runBlocking {
        // Tech Contact
        val techDraft = com.example.data.api.GeminiAiHelper.generateFollowUpDraft(
            contactName = "Alex Rivera",
            contactRole = "Senior Architect",
            contactCompany = "CloudScale AI",
            meetingContext = "Met at DevCon 2026",
            userGoals = "Collaborate on distributed AI systems",
            contactIndustry = "Software / AI"
        )
        assertTrue("Tech draft should be populated", techDraft.isNotBlank())
        assertTrue("Tech draft should contain name", techDraft.contains("Alex", ignoreCase = true))

        // Finance Contact
        val financeDraft = com.example.data.api.GeminiAiHelper.generateFollowUpDraft(
            contactName = "Victoria Sterling",
            contactRole = "Managing Partner",
            contactCompany = "Apex Capital Ventures",
            meetingContext = "Met at FinTech Summit",
            userGoals = "Discuss Seed round and market expansion",
            contactIndustry = "Venture Capital / Finance"
        )
        assertTrue("Finance draft should be populated", financeDraft.isNotBlank())
        assertTrue("Finance draft should contain name", financeDraft.contains("Victoria", ignoreCase = true))

        // Healthcare Contact
        val healthDraft = com.example.data.api.GeminiAiHelper.generateFollowUpDraft(
            contactName = "Dr. Marcus Chen",
            contactRole = "Head of Clinical Research",
            contactCompany = "BioGen Therapeutics",
            meetingContext = "Met at HealthTech Expo",
            userGoals = "Discuss digital biomarkers integration",
            contactIndustry = "Healthcare / Biotech"
        )
        assertTrue("Health draft should be populated", healthDraft.isNotBlank())
        assertTrue("Health draft should contain name", healthDraft.contains("Marcus", ignoreCase = true))

        // Ensure each draft is distinctly customized and not identical
        assertNotEquals("Tech and Finance drafts must be distinct", techDraft, financeDraft)
        assertNotEquals("Finance and Healthcare drafts must be distinct", financeDraft, healthDraft)
        assertNotEquals("Tech and Healthcare drafts must be distinct", techDraft, healthDraft)
    }

    @Test
    fun testMutualConnectionsSuggestedDifferentlyPerUser() {
        // Candidate pool
        val candidate1 = RecommendedPerson(
            id = "c1",
            name = "Alice Tech",
            jobTitle = "CTO",
            company = "NexGen",
            connectionIds = listOf("user_x", "user_y", "user_z"),
            industry = "Technology"
        )
        val candidate2 = RecommendedPerson(
            id = "c2",
            name = "Bob Finance",
            jobTitle = "Partner",
            company = "Venture Capital",
            connectionIds = listOf("user_m", "user_n"),
            industry = "Finance"
        )
        val candidate3 = RecommendedPerson(
            id = "c3",
            name = "Carol Bio",
            jobTitle = "Scientist",
            company = "HealthBio",
            connectionIds = listOf("user_x", "user_m"),
            industry = "Healthcare"
        )
        val pool = listOf(candidate1, candidate2, candidate3)

        // User A network
        val userAConnectionIds = setOf("user_x", "user_y")
        val userASuggestions = pool.map { p ->
            val mutual = p.connectionIds.intersect(userAConnectionIds).size
            p.copy(
                mutualConnectionsCount = mutual,
                matchReason = if (mutual > 0) "🤝 $mutual Mutual Connections" else "Industry Match"
            )
        }.sortedByDescending { it.mutualConnectionsCount }

        // For User A, candidate1 has 2 mutuals, candidate3 has 1, candidate2 has 0
        assertEquals("c1", userASuggestions[0].id)
        assertEquals(2, userASuggestions[0].mutualConnectionsCount)

        // User B network (completely different connections)
        val userBConnectionIds = setOf("user_m", "user_n")
        val userBSuggestions = pool.map { p ->
            val mutual = p.connectionIds.intersect(userBConnectionIds).size
            p.copy(
                mutualConnectionsCount = mutual,
                matchReason = if (mutual > 0) "🤝 $mutual Mutual Connections" else "Industry Match"
            )
        }.sortedByDescending { it.mutualConnectionsCount }

        // For User B, candidate2 has 2 mutuals, candidate3 has 1, candidate1 has 0
        assertEquals("c2", userBSuggestions[0].id)
        assertEquals(2, userBSuggestions[0].mutualConnectionsCount)

        // Verifies suggestions are different per user based on real mutual graphs
        assertNotEquals("Suggestions order must differ for different users", userASuggestions[0].id, userBSuggestions[0].id)
    }

    @Test
    fun testDeepStressTestLoop50Times() {
        // Run core matchmaking and profile ranking 50 times continuously to verify performance and stability
        for (i in 1..50) {
            val dynamicUser = UserProfile(
                id = "user_$i",
                username = "tester_$i",
                fullName = "Tester $i",
                jobTitle = if (i % 2 == 0) "Software Engineer" else "Product Manager",
                company = "ScaleCo $i",
                industry = if (i % 3 == 0) "FinTech" else "SaaS",
                connectionIds = (1..5).map { "conn_${i}_$it" }
            )

            val testCandidates = (1..10).map { cIdx ->
                RecommendedPerson(
                    id = "cand_${i}_$cIdx",
                    name = "Candidate $cIdx",
                    jobTitle = "Role $cIdx",
                    company = "Company $cIdx",
                    connectionIds = listOf("conn_${i}_1", "conn_${i}_2", "other_$cIdx"),
                    industry = if (cIdx % 2 == 0) "FinTech" else "SaaS"
                )
            }

            val mySet = dynamicUser.connectionIds.toSet()
            val ranked = testCandidates.map { cand ->
                val mutuals = cand.connectionIds.intersect(mySet).size
                cand.copy(
                    mutualConnectionsCount = mutuals,
                    matchReason = if (mutuals > 0) "$mutuals Mutuals" else "Domain Match"
                )
            }.sortedByDescending { it.mutualConnectionsCount }

            assertEquals(10, ranked.size)
            assertTrue("Top candidate should have >= 2 mutuals", ranked.first().mutualConnectionsCount >= 2)
        }
    }
}
