#!/usr/bin/env python3
import http.server
import socketserver
import os
import urllib.parse

PORT = 3000
BASE_DIR = "/app/applet"
AAB_PATH = "/app/applet/app/build/outputs/bundle/release/app-release.aab"
if not os.path.exists(AAB_PATH):
    AAB_PATH = "/app/applet/.build-outputs/app-release.aab"

APK_PATH = "/app/applet/app-release-v42.apk"
if not os.path.exists(APK_PATH):
    APK_PATH = "/app/applet/app/build/outputs/apk/release/app-release.apk"
if not os.path.exists(APK_PATH):
    APK_PATH = "/app/applet/app/build/outputs/apk/debug/app-debug.apk"

class ThreadedTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

class DownloadHandler(http.server.BaseHTTPRequestHandler):
    protocol_version = "HTTP/1.1"

    def send_cors_headers(self):
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, HEAD, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "*")
        self.send_header("Accept-Ranges", "bytes")

    def do_OPTIONS(self):
        self.send_response(204)
        self.send_cors_headers()
        self.end_headers()

    def send_file_response(self, filepath, filename, content_type="application/octet-stream", head_only=False):
        if not os.path.exists(filepath):
            self.send_error(404, f"File {filename} not found")
            return
        filesize = os.path.getsize(filepath)
        range_header = self.headers.get("Range")
        
        start = 0
        end = filesize - 1
        is_range = False

        if range_header and range_header.startswith("bytes="):
            try:
                parts = range_header[6:].split("-")
                if parts[0]:
                    start = int(parts[0])
                if len(parts) > 1 and parts[1]:
                    end = int(parts[1])
                is_range = True
            except Exception:
                start = 0
                end = filesize - 1
                is_range = False

        if start > end or start >= filesize:
            self.send_response(416)
            self.send_header("Content-Range", f"bytes */{filesize}")
            self.end_headers()
            return

        content_length = end - start + 1

        if is_range:
            self.send_response(206)
            self.send_header("Content-Range", f"bytes {start}-{end}/{filesize}")
        else:
            self.send_response(200)

        self.send_cors_headers()
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(content_length))
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()

        if head_only:
            return

        try:
            with open(filepath, "rb") as f:
                if start > 0:
                    f.seek(start)
                bytes_to_send = content_length
                while bytes_to_send > 0:
                    chunk_size = min(65536, bytes_to_send)
                    chunk = f.read(chunk_size)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
                    bytes_to_send -= len(chunk)
        except (ConnectionResetError, BrokenPipeError):
            pass

    def do_HEAD(self):
        path = urllib.parse.urlparse(self.path).path.lower()
        if path.endswith(".aab") or path in ["/aab", "/download/aab"]:
            self.send_file_response(AAB_PATH, "app-release.aab", "application/octet-stream", head_only=True)
        elif path.endswith(".apk") or path in ["/apk", "/download/apk"]:
            self.send_file_response(APK_PATH, "app-release.apk", "application/vnd.android.package-archive", head_only=True)
        else:
            self.send_response(200)
            self.send_header("Content-Type", "text/html; charset=utf-8")
            self.end_headers()

    def do_GET(self):
        path = urllib.parse.urlparse(self.path).path.lower()
        if path.endswith(".aab") or path in ["/aab", "/download/aab"]:
            self.send_file_response(AAB_PATH, "app-release.aab", "application/octet-stream")
            return
        elif path.endswith(".apk") or path in ["/apk", "/download/apk"]:
            self.send_file_response(APK_PATH, "app-release.apk", "application/vnd.android.package-archive")
            return

        # HTML Landing / Download page
        aab_size_mb = f"{os.path.getsize(AAB_PATH) / (1024 * 1024):.1f} MB" if os.path.exists(AAB_PATH) else "Ready"
        apk_size_mb = f"{os.path.getsize(APK_PATH) / (1024 * 1024):.1f} MB" if os.path.exists(APK_PATH) else "Ready"

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netero - Download AAB & APK</title>
    <style>
        :root {{
            --bg-color: #0b0f19;
            --card-bg: #151d30;
            --card-border: #22304e;
            --primary: #2563eb;
            --primary-hover: #1d4ed8;
            --accent: #00d2ff;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
        }}
        * {{
            box-sizing: border-box;
            margin: 0;
            padding: 0;
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
        }}
        body {{
            background: linear-gradient(135deg, #0b0f19 0%, #111a2e 100%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }}
        .container {{
            max-width: 580px;
            width: 100%;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 20px;
            padding: 36px 32px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}
        .badge {{
            display: inline-flex;
            align-items: center;
            gap: 6px;
            background: rgba(37, 99, 235, 0.2);
            color: #60a5fa;
            border: 1px solid rgba(96, 165, 250, 0.3);
            font-size: 12px;
            font-weight: 600;
            padding: 6px 14px;
            border-radius: 9999px;
            margin-bottom: 20px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }}
        h1 {{
            font-size: 28px;
            font-weight: 800;
            letter-spacing: -0.5px;
            margin-bottom: 10px;
            background: linear-gradient(90deg, #ffffff, #93c5fd);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        p.subtitle {{
            font-size: 15px;
            color: var(--text-muted);
            margin-bottom: 28px;
            line-height: 1.5;
        }}
        .button-group {{
            display: flex;
            flex-direction: column;
            gap: 16px;
        }}
        .btn {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 22px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.2s ease;
            box-shadow: 0 4px 14px rgba(0,0,0,0.25);
        }}
        .btn-aab {{
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: #ffffff;
            border: 1px solid rgba(255,255,255,0.15);
        }}
        .btn-aab:hover {{
            background: linear-gradient(135deg, #1d4ed8, #1e40af);
            transform: translateY(-2px);
            box-shadow: 0 8px 24px rgba(37, 99, 235, 0.4);
        }}
        .btn-apk {{
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-main);
            border: 1px solid var(--card-border);
        }}
        .btn-apk:hover {{
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }}
        .btn-content {{
            display: flex;
            align-items: center;
            gap: 14px;
            text-align: left;
        }}
        .btn-icon {{
            font-size: 24px;
        }}
        .btn-title {{
            font-size: 16px;
            font-weight: 700;
            display: block;
        }}
        .btn-sub {{
            font-size: 12px;
            color: rgba(255, 255, 255, 0.65);
            font-weight: 400;
        }}
        .btn-pill {{
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }}
        .features {{
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid var(--card-border);
            text-align: left;
        }}
        .feature-item {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }}
        .check {{
            color: #10b981;
            font-weight: bold;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="badge">🚀 Production Build Ready</div>
        <h1>Netero App Bundle</h1>
        <p class="subtitle">Directly download the signed Android App Bundle (AAB) ready for Google Play Console or manual distribution.</p>
        
        <div class="button-group">
            <a href="/app-release.aab" class="btn btn-aab" id="downloadAabBtn" download="app-release.aab">
                <div class="btn-content">
                    <span class="btn-icon">📦</span>
                    <div>
                        <span class="btn-title">Download AAB File</span>
                        <span class="btn-sub">Google Play Release Bundle (Signed)</span>
                    </div>
                </div>
                <span class="btn-pill" id="pillAab">{aab_size_mb}</span>
            </a>

            <a href="/app-debug.apk" class="btn btn-apk" id="downloadApkBtn" download="app-debug.apk">
                <div class="btn-content">
                    <span class="btn-icon">📱</span>
                    <div>
                        <span class="btn-title">Download Direct APK</span>
                        <span class="btn-sub">Install directly on Android devices</span>
                    </div>
                </div>
                <span class="btn-pill" id="pillApk">{apk_size_mb}</span>
            </a>
        </div>

        <div class="features">
            <div class="feature-item"><span class="check">✓</span> Fully verified & compiled with Kotlin & Jetpack Compose</div>
            <div class="feature-item"><span class="check">✓</span> Gemini 3.5 AI personalized recommendations & mutual discovery</div>
            <div class="feature-item"><span class="check">✓</span> Realtime manual peer connection requests (no simulation)</div>
            <div class="feature-item"><span class="check">✓</span> Instant copy & paste in chats and Ask AI assistant</div>
        </div>
    </div>
</body>
</html>
"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode("utf-8"))))
        self.end_headers()
        self.wfile.write(html.encode("utf-8"))

def run():
    with ThreadedTCPServer(("0.0.0.0", PORT), DownloadHandler) as httpd:
        print(f"Serving AAB/APK downloads on port {PORT}")
        httpd.serve_forever()

if __name__ == "__main__":
    run()
