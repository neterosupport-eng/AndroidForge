#!/usr/bin/env python3
import http.server
import socketserver
import os
import shutil
import urllib.parse

PORT = 3000

def get_file_paths():
    aab_candidates = [
        "/app/applet/app/build/outputs/bundle/release/app-release.aab",
        "/app/applet/.build-outputs/app-release.aab",
        "app/build/outputs/bundle/release/app-release.aab",
        ".build-outputs/app-release.aab"
    ]
    apk_candidates = [
        "/app/applet/.build-outputs/app-debug.apk",
        "/app/applet/app/build/outputs/apk/debug/app-debug.apk",
        ".build-outputs/app-debug.apk",
        "app/build/outputs/apk/debug/app-debug.apk"
    ]
    aab_path = next((p for p in aab_candidates if os.path.exists(p)), aab_candidates[0])
    apk_path = next((p for p in apk_candidates if os.path.exists(p)), apk_candidates[0])
    return aab_path, apk_path

class DownloadHandler(http.server.BaseHTTPRequestHandler):
    def send_file_response(self, filepath, filename, content_type="application/octet-stream"):
        if not os.path.exists(filepath):
            self.send_error(404, f"File {filename} not found")
            return
        filesize = os.path.getsize(filepath)
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(filesize))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Expose-Headers", "Content-Length, Content-Disposition")
        self.send_header("Cache-Control", "no-cache, no-store, must-revalidate")
        self.end_headers()
        try:
            with open(filepath, "rb") as f:
                shutil.copyfileobj(f, self.wfile, length=262144)
            self.wfile.flush()
        except Exception as e:
            pass

    def do_HEAD(self):
        self.do_GET(head_only=True)

    def do_GET(self, head_only=False):
        aab_path, apk_path = get_file_paths()
        path = urllib.parse.urlparse(self.path).path
        if path in ["/app-release.aab", "/aab", "/download/aab"]:
            self.send_file_response(aab_path, "app-release.aab", "application/octet-stream")
            return
        elif path in ["/app-debug.apk", "/apk", "/download/apk"]:
            self.send_file_response(apk_path, "app-debug.apk", "application/vnd.android.package-archive")
            return

        aab_size_mb = f"{os.path.getsize(aab_path) / (1024 * 1024):.1f} MB" if os.path.exists(aab_path) else "48 MB"
        apk_size_mb = f"{os.path.getsize(apk_path) / (1024 * 1024):.1f} MB" if os.path.exists(apk_path) else "92 MB"

        html = f"""<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Netero - Download Signed AAB & APK</title>
    <style>
        :root {{
            --bg: #0b0f19;
            --card-bg: #151d30;
            --card-border: #22304e;
            --primary: #2563eb;
            --text-main: #f8fafc;
            --text-muted: #94a3b8;
        }}
        * {{ box-sizing: border-box; margin: 0; padding: 0; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }}
        body {{
            background: linear-gradient(135deg, #0b0f19 0%, #111a2e 100%);
            color: var(--text-main);
            min-height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            padding: 24px;
        }}
        .container {{
            max-width: 580px;
            width: 100%;
            background: var(--card-bg);
            border: 1px solid var(--card-border);
            border-radius: 20px;
            padding: 36px 32px;
            box-shadow: 0 20px 50px rgba(0, 0, 0, 0.5);
            text-align: center;
        }}
        .badge {{
            display: inline-flex;
            align-items: center;
            background: rgba(37, 99, 235, 0.2);
            color: #60a5fa;
            border: 1px solid rgba(96, 165, 250, 0.3);
            font-size: 12px;
            font-weight: 600;
            padding: 6px 14px;
            border-radius: 9999px;
            margin-bottom: 20px;
            letter-spacing: 0.5px;
            text-transform: uppercase;
        }}
        h1 {{
            font-size: 28px;
            font-weight: 800;
            margin-bottom: 10px;
            background: linear-gradient(90deg, #ffffff, #93c5fd);
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
        }}
        p.subtitle {{
            font-size: 15px;
            color: var(--text-muted);
            margin-bottom: 28px;
            line-height: 1.5;
        }}
        .button-group {{ display: flex; flex-direction: column; gap: 16px; }}
        .btn {{
            display: flex;
            align-items: center;
            justify-content: space-between;
            padding: 16px 22px;
            border-radius: 14px;
            text-decoration: none;
            font-weight: 600;
            font-size: 16px;
            transition: all 0.2s ease;
        }}
        .btn-aab {{
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: #ffffff;
            border: 1px solid rgba(255,255,255,0.15);
            box-shadow: 0 4px 14px rgba(37, 99, 235, 0.3);
        }}
        .btn-aab:hover {{
            background: linear-gradient(135deg, #1d4ed8, #1e40af);
            transform: translateY(-2px);
        }}
        .btn-apk {{
            background: rgba(255, 255, 255, 0.05);
            color: var(--text-main);
            border: 1px solid var(--card-border);
        }}
        .btn-apk:hover {{
            background: rgba(255, 255, 255, 0.1);
            transform: translateY(-2px);
        }}
        .btn-content {{ display: flex; align-items: center; gap: 14px; text-align: left; }}
        .btn-icon {{ font-size: 24px; }}
        .btn-title {{ font-size: 16px; font-weight: 700; display: block; }}
        .btn-sub {{ font-size: 12px; color: rgba(255, 255, 255, 0.65); font-weight: 400; }}
        .btn-pill {{
            background: rgba(255, 255, 255, 0.2);
            padding: 4px 10px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }}
        .features {{
            margin-top: 28px;
            padding-top: 22px;
            border-top: 1px solid var(--card-border);
            text-align: left;
        }}
        .feature-item {{
            display: flex;
            align-items: center;
            gap: 8px;
            font-size: 13px;
            color: var(--text-muted);
            margin-bottom: 8px;
        }}
        .check {{ color: #10b981; font-weight: bold; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="badge">🚀 Production Build Ready</div>
        <h1>Netero App Bundle</h1>
        <p class="subtitle">Directly download the signed Android App Bundle (AAB) ready for Google Play Console or manual distribution.</p>
        
        <div class="button-group">
            <a href="/app-release.aab" class="btn btn-aab">
                <div class="btn-content">
                    <span class="btn-icon">📦</span>
                    <div>
                        <span class="btn-title">Download AAB File</span>
                        <span class="btn-sub">Google Play Release Bundle (Signed)</span>
                    </div>
                </div>
                <span class="btn-pill">{aab_size_mb}</span>
            </a>

            <a href="/app-debug.apk" class="btn btn-apk">
                <div class="btn-content">
                    <span class="btn-icon">📱</span>
                    <div>
                        <span class="btn-title">Download Direct APK</span>
                        <span class="btn-sub">Install directly on Android devices</span>
                    </div>
                </div>
                <span class="btn-pill">{apk_size_mb}</span>
            </a>
        </div>

        <div class="features">
            <div class="feature-item"><span class="check">✓</span> Fully verified & compiled with Kotlin & Jetpack Compose</div>
            <div class="feature-item"><span class="check">✓</span> Gemini 3.5 AI personalized recommendations & mutual discovery</div>
            <div class="feature-item"><span class="check">✓</span> Realtime manual peer connection requests (no simulation)</div>
            <div class="feature-item"><span class="check">✓</span> Instant copy & paste in chats and Ask AI assistant</div>
        </div>
    </div>
</body>
</html>
"""
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(html.encode("utf-8"))))
        self.end_headers()
        if not head_only:
            try:
                self.wfile.write(html.encode("utf-8"))
            except Exception:
                pass

class ThreadingServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    daemon_threads = True
    allow_reuse_address = True

def run():
    socketserver.TCPServer.allow_reuse_address = True
    httpd = ThreadingServer(("0.0.0.0", PORT), DownloadHandler)
    print(f"Serving AAB/APK downloads on port {PORT}")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()

if __name__ == "__main__":
    run()
