<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/58055983-fb9f-4de6-be32-9ba5acdf7cfa

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Configure the Gemini API key as the Firebase Functions secret `GEMINI_API_KEY`; do not place the Gemini key in the Android app or commit it to source control.
5. Run the app on an emulator or physical device
6. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.

## Release security configuration
For Firebase Functions, configure `NETERO_GMAIL_USER` and `NETERO_GMAIL_APP_PASSWORD`. For Android release signing, configure `NETERO_RELEASE_KEYSTORE`, `NETERO_RELEASE_STORE_PASSWORD`, `NETERO_RELEASE_KEY_ALIAS`, and `NETERO_RELEASE_KEY_PASSWORD`. `GEMINI_API_KEY` is configured only as a Firebase Functions secret. Never commit `.env` or release keystores.


### Production signing
Private signing keystores are intentionally not included in this source package. Configure the four `NETERO_RELEASE_*` signing variables in the build environment.

### Email OTP
OTP delivery and verification run through Firebase Functions. Do not put the Gmail account password/app password in the Android project. Configure the Functions secrets `NETERO_GMAIL_USER` and `NETERO_GMAIL_APP_PASSWORD` and rotate any previously exposed Gmail app password.
