# Build Netero AAB without Android Studio or GitHub

This project includes a small local build bootstrapper.

## Windows
1. Install Java 17+ and Android SDK command-line tools.
2. Make sure `adb`, `sdkmanager`, and `java` are available on PATH (or configure `ANDROID_HOME`/`ANDROID_SDK_ROOT`).
3. Double-click `build-aab.bat` or run it from Command Prompt.
4. Output: `app\\build\\outputs\\bundle\\release\\app-release.aab`

The script downloads Gradle 9.3.1 automatically. Android Studio is not required.

## Important: Play Store signing
If you already have Netero's permanent release keystore, set these environment variables before building:
- `NETERO_RELEASE_KEYSTORE`
- `NETERO_RELEASE_STORE_PASSWORD`
- `NETERO_RELEASE_KEY_ALIAS`
- `NETERO_RELEASE_KEY_PASSWORD`

If they are not set, the project can produce an **unsigned release AAB** for build verification, but Google Play will not accept that unsigned AAB for publishing.

Do not generate a new Play signing key if an existing Netero key has already been used for a published app/update path.
