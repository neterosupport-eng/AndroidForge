#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
GRADLE_VERSION=9.3.1
CACHE="$HOME/.netero-gradle"
DIST="$CACHE/gradle-$GRADLE_VERSION"
if [[ ! -x "$DIST/bin/gradle" ]]; then
  mkdir -p "$CACHE"
  ZIP="$CACHE/gradle-$GRADLE_VERSION-bin.zip"
  echo "Downloading Gradle $GRADLE_VERSION..."
  curl -fL "https://services.gradle.org/distributions/gradle-$GRADLE_VERSION-bin.zip" -o "$ZIP"
  unzip -q -o "$ZIP" -d "$CACHE"
fi
"$DIST/bin/gradle" bundleRelease --stacktrace --no-daemon
echo
echo "AAB: $(pwd)/app/build/outputs/bundle/release/app-release.aab"
