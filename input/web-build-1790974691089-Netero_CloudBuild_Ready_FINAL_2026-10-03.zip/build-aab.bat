@echo off
setlocal EnableExtensions

REM Netero AAB builder - does not require Android Studio or GitHub.
REM Requires Java 17+ and Android SDK command-line tools.

set "ROOT=%~dp0"
set "GRADLE_VERSION=9.3.1"
set "GRADLE_HOME=%USERPROFILE%\.netero-gradle\gradle-%GRADLE_VERSION%"
set "GRADLE_ZIP=%USERPROFILE%\.netero-gradle\gradle-%GRADLE_VERSION%-bin.zip"

where java >nul 2>&1
if errorlevel 1 (
  echo ERROR: Java is not installed or not on PATH.
  echo Install Java 17 and run this again.
  exit /b 1
)

if not exist "%GRADLE_HOME%\bin\gradle.bat" (
  echo Downloading Gradle %GRADLE_VERSION%...
  if not exist "%USERPROFILE%\.netero-gradle" mkdir "%USERPROFILE%\.netero-gradle"
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Invoke-WebRequest -UseBasicParsing 'https://services.gradle.org/distributions/gradle-%GRADLE_VERSION%-bin.zip' -OutFile '%GRADLE_ZIP%'"
  if errorlevel 1 (
    echo ERROR: Could not download Gradle.
    exit /b 1
  )
  echo Extracting Gradle...
  powershell -NoProfile -ExecutionPolicy Bypass -Command "Expand-Archive -Force '%GRADLE_ZIP%' '%USERPROFILE%\.netero-gradle'"
  if errorlevel 1 exit /b 1
)

cd /d "%ROOT%"
call "%GRADLE_HOME%\bin\gradle.bat" bundleRelease --stacktrace --no-daemon
if errorlevel 1 (
  echo.
  echo BUILD FAILED.
  exit /b 1
)

echo.
echo ========================================
echo AAB BUILD COMPLETE
echo ========================================
echo File: %ROOT%app\build\outputs\bundle\release\app-release.aab
echo.
endlocal
