# Netero storage quota

- Free users: 500 MiB total attachment storage.
- Netero Pro users: attachment quota is bypassed.
- Chat and Room attachments reserve quota before upload and commit it only after successful cloud delivery.
- Failed uploads release the reservation.
- A single file remains limited by Firebase Storage rules to under 500 MiB.
- Profile photos are not charged against the attachment quota.

The quota is enforced in the app using an atomic Firestore transaction on `users/{authUid}` (`storageUsedBytes` + `storageReservedBytes`). The Firestore user-document rules already allow the authenticated owner to update their own document.

For launch, deploy `firestore.rules`, `storage.rules`, and `functions/` to the live Firebase project and perform the two-device upload tests in `FIREBASE_BACKEND_DEPLOYMENT.md`.
