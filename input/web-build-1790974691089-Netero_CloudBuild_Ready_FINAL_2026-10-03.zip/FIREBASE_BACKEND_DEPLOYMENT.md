# Netero production Firebase deployment checklist

## Authentication / email OTP
Netero keeps the existing user-facing experience: the person enters a Gmail/email address and receives a six-digit Netero code. Firebase Authentication is used only for an invisible anonymous session required by the callable backend; there is no Firebase Email/Password, Google Sign-In, or Phone Auth UI in the app.

OTP generation, hashing, rate limiting, persistence and verification run in Firebase Functions. The Android package contains no Gmail account password/app password and does not compare a locally generated OTP.

Configure the backend secrets before first deploy:

```bash
firebase functions:secrets:set NETERO_GMAIL_USER
firebase functions:secrets:set NETERO_GMAIL_APP_PASSWORD
firebase functions:secrets:set GEMINI_API_KEY
```

Rotate any Gmail app password that was ever stored in an Android/source artifact before this hardening.

## Deploy
From the project root on the computer that is logged into the owner Firebase project:

```bash
npm install -g firebase-tools
firebase login
firebase use netero-network
npm --prefix functions install
firebase deploy --only firestore:rules,storage,functions
```

## Storage / attachments
Chat and Room attachments are selected as Android content URIs and streamed to Firebase Storage with `putStream`; the full document is not loaded into a ByteArray. Downloads use Firebase Storage `getFile()` into app cache before opening. Profile photos are downscaled/compressed before upload.

The Storage rules restrict chat files to the sender or recipient path and room files to room members/admins. Firestore rules are separate and protect the database documents.

## FCM
FCM auto-init is enabled in the Android manifest. Notification documents under `users/{uid}/notifications` trigger the `sendNeteroNotification` Cloud Function, which sends to the saved token and clears an invalid token.

## Rooms
Room membership, admin/speaker roles and admin-only chat settings are server-authoritative through `mutateNeteroRoom`. The Android UI may display local state optimistically, but the persisted room document/listener is the source of truth.

## Asteron
The Android app calls the `asteronAi` Firebase callable; the Gemini key is server-side only. Profile public-link research is performed by `asteronProfileResearch` using publicly available information. The implementation does not claim access to private/logged-in/blocked pages.

## Smoke tests required after deploy
Use two real test devices/accounts and verify text, image, PDF and office-document chat delivery; recipient opening/downloading; push notifications after background/restart; profile photo propagation; Room discussion attachments; Room role changes in realtime; account deletion; and rules isolation so one user cannot read another user's private chat data.

Source inspection can verify code paths and configuration, but it cannot substitute for the live Firebase deployment and physical-device smoke test.
