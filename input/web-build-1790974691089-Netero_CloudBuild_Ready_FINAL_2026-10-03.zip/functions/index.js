const { onDocumentCreated, onDocumentWritten } = require("firebase-functions/v2/firestore");
const crypto = require("crypto");
const { onCall, HttpsError } = require("firebase-functions/v2/https");
const { defineSecret } = require("firebase-functions/params");
const { initializeApp } = require("firebase-admin/app");
const { getFirestore } = require("firebase-admin/firestore");
const { getMessaging } = require("firebase-admin/messaging");
const nodemailer = require("nodemailer");

initializeApp();
const db = getFirestore();
const geminiApiKey = defineSecret("GEMINI_API_KEY");
const gmailUser = defineSecret("NETERO_GMAIL_USER");
const gmailAppPassword = defineSecret("NETERO_GMAIL_APP_PASSWORD");
const MODEL = "gemini-3.8-flash";

async function callGemini({prompt, systemInstruction, webResearch = false, imageBase64 = null, mimeType = "image/jpeg"}) {
  const parts = [];
  if (prompt) parts.push({text: prompt});
  if (imageBase64) parts.push({inline_data: {mime_type: mimeType, data: imageBase64}});
  const body = {
    systemInstruction: {parts: [{text: systemInstruction || "You are Asteron AI, Netero's professional networking intelligence engine. Be accurate, concise and never invent facts."}]},
    contents: [{parts}],
  };
  if (webResearch) body.tools = [{google_search: {}}];

  const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/${MODEL}:generateContent`, {
    method: "POST",
    headers: {"Content-Type": "application/json", "x-goog-api-key": geminiApiKey.value()},
    body: JSON.stringify(body),
  });
  const text = await response.text();
  if (!response.ok) throw new Error(`Gemini ${response.status}: ${text.slice(0, 500)}`);
  const json = JSON.parse(text);
  const candidates = json.candidates || [];
  const out = candidates[0]?.content?.parts?.filter(p => !p.thought && p.text).map(p => p.text).join("").trim() || "";
  return {text: out, groundingMetadata: json.groundingMetadata || null};
}


function normaliseEmail(value) {
  return String(value || "").trim().toLowerCase();
}

function hashOtp(email, code, salt) {
  return crypto.createHash("sha256").update(`${email}:${salt}:${code}`).digest("hex");
}

function createMailer() {
  const user = gmailUser.value();
  const pass = gmailAppPassword.value();
  if (!user || !pass) throw new Error("Netero Gmail mail secrets are not configured.");
  return nodemailer.createTransport({
    host: "smtp.gmail.com",
    port: 465,
    secure: true,
    auth: { user, pass },
    connectionTimeout: 15000,
    greetingTimeout: 15000,
    socketTimeout: 20000,
  });
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

exports.sendNeteroOtp = onCall({ secrets: [gmailUser, gmailAppPassword], timeoutSeconds: 30 }, async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const email = normaliseEmail(request.data?.email);
  if (!email || !email.includes("@") || email.length > 254) throw new HttpsError("invalid-argument", "Valid email required.");

  const uid = request.auth.uid;
  const emailKey = crypto.createHash("sha256").update(email).digest("hex");
  const ref = db.collection("netero_otp_challenges").doc(`${uid}_${emailKey}`);
  const current = await ref.get();
  const now = Date.now();
  if (current.exists) {
    const data = current.data() || {};
    const sentAt = Number(data.sentAt || 0);
    const hourlyCount = Number(data.hourlyCount || 0);
    const hourStart = Number(data.hourStart || now);
    if (now - sentAt < 30_000) throw new HttpsError("resource-exhausted", "Please wait before requesting another code.");
    const activeHourCount = now - hourStart < 60 * 60 * 1000 ? hourlyCount : 0;
    if (activeHourCount >= 5) throw new HttpsError("resource-exhausted", "Too many verification codes requested. Try again later.");
  }

  const code = String(crypto.randomInt(100000, 1000000));
  const salt = crypto.randomBytes(16).toString("hex");
  const sentAt = now;
  const previous = current.data() || {};
  const hourStart = now - Number(previous.hourStart || 0) < 60 * 60 * 1000 ? Number(previous.hourStart) : now;
  const hourlyCount = now - Number(previous.hourStart || 0) < 60 * 60 * 1000 ? Number(previous.hourlyCount || 0) + 1 : 1;
  await ref.set({ codeHash: hashOtp(email, code, salt), salt, email, uid, sentAt, hourStart, hourlyCount, expiresAt: now + 10 * 60 * 1000, attempts: 0 }, { merge: true });

  try {
    const transporter = createMailer();
    await transporter.sendMail({
      from: `Netero Security <${gmailUser.value()}>`,
      to: email,
      subject: `${code} is your Netero verification code`,
      text: `Your Netero verification code is ${code}. Valid for 10 minutes. Never share this code with anyone.`,
      html: `<div style="font-family:Arial,sans-serif;max-width:520px;margin:auto;padding:32px;background:#0f172a;color:#f8fafc;border-radius:16px"><h1 style="color:#38bdf8;letter-spacing:4px">NETERO</h1><p>Here is your single-use verification code:</p><div style="font:800 40px monospace;letter-spacing:10px;color:#38bdf8;padding:12px 20px;background:#111827;border-radius:8px">${code}</div><p style="color:#94a3b8">This code is valid for 10 minutes. Never share it with anyone.</p></div>`,
    });
    return { ok: true };
  } catch (error) {
    await ref.delete().catch(() => {});
    console.error("Netero OTP email send failed", error);
    throw new HttpsError("unavailable", "Unable to send verification email.");
  }
});

exports.verifyNeteroOtp = onCall(async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const email = normaliseEmail(request.data?.email);
  const code = String(request.data?.code || "").trim();
  if (!email || !/^\d{6}$/.test(code)) throw new HttpsError("invalid-argument", "Invalid verification code.");
  const uid = request.auth.uid;
  const emailKey = crypto.createHash("sha256").update(email).digest("hex");
  const ref = db.collection("netero_otp_challenges").doc(`${uid}_${emailKey}`);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("failed-precondition", "Verification code expired. Request a new code.");
  const data = snap.data() || {};
  const expiresAt = Number(data.expiresAt || 0);
  const attempts = Number(data.attempts || 0);
  if (Date.now() > expiresAt) { await ref.delete().catch(() => {}); throw new HttpsError("failed-precondition", "Verification code expired. Request a new code."); }
  if (attempts >= 5) { await ref.delete().catch(() => {}); throw new HttpsError("resource-exhausted", "Too many incorrect attempts. Request a new code."); }
  const expected = String(data.codeHash || "");
  const actual = hashOtp(email, code, String(data.salt || ""));
  if (expected.length !== actual.length || !crypto.timingSafeEqual(Buffer.from(expected), Buffer.from(actual))) {
    await ref.set({ attempts: attempts + 1 }, { merge: true });
    throw new HttpsError("permission-denied", "Incorrect verification code.");
  }
  await Promise.all([
    ref.delete(),
    db.collection("users").doc(uid).set({ verifiedEmail: email, emailVerifiedAt: Date.now() }, { merge: true }),
  ]);
  return { ok: true };
});

exports.sendNeteroSupportEmail = onCall({ secrets: [gmailUser, gmailAppPassword], timeoutSeconds: 30 }, async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const userEmail = normaliseEmail(request.data?.userEmail);
  const userName = String(request.data?.userName || "Netero Member").slice(0, 160);
  const ticketId = String(request.data?.ticketId || "").slice(0, 80);
  const subject = String(request.data?.subject || "Support request").slice(0, 200);
  const message = String(request.data?.message || "").slice(0, 10000);
  if (!userEmail || !ticketId || !message) throw new HttpsError("invalid-argument", "Incomplete support request.");
  const userSnap = await db.collection("users").doc(request.auth.uid).get();
  const verifiedEmail = normaliseEmail(userSnap.get("verifiedEmail"));
  if (!verifiedEmail || verifiedEmail !== userEmail) throw new HttpsError("permission-denied", "Use the verified Netero email address for support.");
  const transporter = createMailer();
  await transporter.sendMail({
    from: `Netero Support <${gmailUser.value()}>`,
    to: userEmail,
    bcc: gmailUser.value(),
    subject: `[Ticket #${ticketId}] NETERO Support: We received your inquiry - ${subject}`,
    text: `Hi ${userName},\n\nWe received your support inquiry (Ticket #${ticketId}).\n\nSubject: ${subject}\nMessage: ${message}\n\nBest,\nThe NETERO Support Team`,
    html: `<div style="font-family:Arial,sans-serif;max-width:580px;margin:auto;padding:28px;background:#0f172a;color:#f8fafc;border-radius:16px"><h1 style="color:#38bdf8">NETERO HELP DESK</h1><p>Hi <strong>${escapeHtml(userName)}</strong>,</p><p>We received your support inquiry.</p><div style="background:#1e293b;padding:16px;border-radius:10px"><strong>Ticket #${escapeHtml(ticketId)}</strong><br>${escapeHtml(subject)}<br><p>${escapeHtml(message)}</p></div><p>Our support team will reply to your email address.</p></div>`,
  });
  return { ok: true };
});


exports.asteronAi = onCall({secrets: [geminiApiKey], timeoutSeconds: 120, memory: "512MiB"}, async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const data = request.data || {};
  const operation = String(data.operation || "generateText");
  const prompt = String(data.prompt || "").slice(0, 30000);
  if (!prompt && operation !== "businessCard") throw new HttpsError("invalid-argument", "Prompt is required.");

  if (operation === "businessCard") {
    const imageBase64 = String(data.imageBase64 || "");
    if (!imageBase64 || imageBase64.length > 12 * 1024 * 1024) throw new HttpsError("invalid-argument", "Invalid image payload.");
    const ocrText = String(data.ocrText || "").slice(0, 12000);
    const cardPrompt = `Analyze this image for Netero. First determine whether it is a genuine professional business/visiting card. Reject credit/debit/payment cards, code/screens, receipts and arbitrary objects. Never fabricate contact details. Raw OCR text:\n${ocrText}\nReturn strictly valid JSON with isBusinessCard, and if true: name, jobTitle, company, phone, email, linkedin, tags. If payment card: isSensitivePaymentCard=true. If code/non-card: isCodeSnippet=true.`;
    const result = await callGemini({prompt: cardPrompt, systemInstruction: "You are Netero's business-card verification and extraction engine. Return only valid JSON.", imageBase64, mimeType: String(data.mimeType || "image/jpeg")});
    try { return JSON.parse(result.text.replace(/^```json\s*/i, "").replace(/```$/i, "").trim()); }
    catch (_) { return {isBusinessCard: false}; }
  }

  const result = await callGemini({prompt, systemInstruction: String(data.systemInstruction || ""), webResearch: Boolean(data.webResearch)});
  return {text: result.text, groundingMetadata: result.groundingMetadata};
});



// Background public-profile intelligence. Runs only when a user's professional
// links change and stores a compact research snapshot on their Netero profile.
// It never requires or attempts to access private/authenticated pages.
exports.asteronProfileResearch = onDocumentWritten(
  { document: "netero_profiles/{userId}", secrets: [geminiApiKey], timeoutSeconds: 120, memory: "512MiB" },
  async (event) => {
    const before = event.data?.before?.data() || {};
    const after = event.data?.after?.data() || {};
    const ref = event.data?.after?.ref;
    if (!ref || !event.data?.after?.exists) return;

    const links = {
      linkedin: String(after.linkedinUrl || after.linkedin || "").trim(),
      portfolio: String(after.portfolioUrl || after.portfolio || "").trim(),
      website: String(after.website || "").trim(),
      business: String(after.businessUrl || after.companyUrl || "").trim(),
    };
    const linkValues = Object.values(links).filter(Boolean);
    if (linkValues.length === 0) return;

    const sourceKey = crypto.createHash("sha256")
      .update(JSON.stringify(links))
      .digest("hex");
    const previousKey = String(after.asteronResearch?.sourceKey || "");
    const beforeLinks = {
      linkedin: String(before.linkedinUrl || before.linkedin || "").trim(),
      portfolio: String(before.portfolioUrl || before.portfolio || "").trim(),
      website: String(before.website || "").trim(),
      business: String(before.businessUrl || before.companyUrl || "").trim(),
    };
    const beforeKey = crypto.createHash("sha256")
      .update(JSON.stringify(beforeLinks))
      .digest("hex");
    if (previousKey === sourceKey || beforeKey === sourceKey) return;

    const prompt = `
Research this Netero professional using only publicly available information.
Use the supplied professional links as the primary sources when they are publicly accessible; use broader web search only to corroborate or fill obvious gaps.
Never claim to have accessed private, logged-in, paywalled, or blocked pages. Never invent credentials, employment, skills, projects, clients, education, or achievements.

Netero profile facts:
Name: ${String(after.fullName || after.name || "")}
Headline: ${String(after.headline || "")}
Role: ${String(after.jobTitle || "")}
Company: ${String(after.company || "")}
Industry: ${String(after.industry || "")}
Bio: ${String(after.bio || "")}
Skills: ${Array.isArray(after.skills) ? after.skills.join(", ") : String(after.skills || "")}

Public links:
LinkedIn: ${links.linkedin || "N/A"}
Portfolio: ${links.portfolio || "N/A"}
Website: ${links.website || "N/A"}
Business/Company: ${links.business || "N/A"}

Return concise JSON only:
{
  "summary": "2-4 sentence professional summary grounded in evidence",
  "expertise": ["up to 8 evidence-based areas"],
  "projects": ["up to 6 publicly evidenced projects/products"],
  "companySummary": "what the company does, if applicable",
  "sourceNotes": ["brief notes identifying which supplied/public sources support important findings"]
}
`.trim();

    try {
      const result = await callGemini({
        prompt,
        systemInstruction: "You are Asteron AI's public professional research engine. Use public web information carefully, distinguish supplied Netero facts from researched findings, and return strictly valid JSON with no fabricated claims.",
        webResearch: true,
      });
      const clean = String(result.text || "").replace(/^```json\s*/i, "").replace(/```$/i, "").trim();
      const parsed = JSON.parse(clean);
      await ref.set({
        asteronResearch: {
          sourceKey,
          researchedAt: new Date().toISOString(),
          ...parsed,
        },
      }, { merge: true });
    } catch (error) {
      console.error("Asteron background profile research failed", event.params.userId, error);
    }
  }
);

exports.sendNeteroNotification = onDocumentCreated(
  "users/{userId}/notifications/{notificationId}",
  async (event) => {
    const userId = event.params.userId;
    const data = event.data?.data() || {};
    if (!userId) return;
    const userSnap = await db.collection("users").doc(userId).get();
    const token = userSnap.get("fcmToken");
    if (!token) return;
    const title = String(data.title || "Netero");
    const body = String(data.body || "You have a new update in Netero.");
    try {
      await getMessaging().send({token, notification: {title, body}, data: {type: String(data.type || "GENERAL"), senderId: String(data.senderId || ""), notificationId: event.params.notificationId}, android: {priority: "high", notification: {channelId: "netero_default_channel"}}});
    } catch (error) {
      const code = error?.code || "";
      if (code.includes("registration-token-not-registered") || code.includes("invalid-registration-token")) await userSnap.ref.set({fcmToken: null}, {merge: true});
      else console.error("Netero FCM send failed", error);
    }
  }
);


// Secure server-side connection acceptance. The client never writes another
// user's protected connection document directly.
exports.sendNeteroConnectionRequest = onCall(async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const senderId = request.auth.uid;
  const recipientId = String(request.data?.recipientId || "").trim();
  if (!recipientId || recipientId === senderId) throw new HttpsError("invalid-argument", "Invalid recipient.");
  const recipientProfile = await db.collection("netero_profiles").doc(recipientId).get();
  if (!recipientProfile.exists) throw new HttpsError("not-found", "Netero member not found.");
  const senderProfile = await db.collection("netero_profiles").doc(senderId).get();
  const sp = senderProfile.data() || {};
  const data = request.data || {};
  const isQrScan = Boolean(data.isQrScan);
  const message = String(data.message || "I'd like to connect with you.").slice(0, 1000);
  const senderName = String(sp.fullName || data.senderName || "Netero Member").slice(0, 160);
  const requestData = {
    senderName,
    senderTitle: String(sp.jobTitle || data.senderTitle || "").slice(0, 160),
    senderCompany: String(sp.company || data.senderCompany || "").slice(0, 160),
    message,
    timeAgo: "Just now",
    avatarInitial: String((senderName.charAt(0) || "U").toUpperCase()),
    avatarBgHex: Number(data.avatarBgHex || 0xFF007AFF),
    timestamp: Date.now(),
    isQrScan,
    senderId,
    recipientId,
  };
  const requestRef = db.collection("users").doc(recipientId).collection("requests").doc(senderId);
  const existing = await requestRef.get();
  if (existing.exists) return {ok:true, alreadyExists:true};
  const title = isQrScan ? "QR Code Scanned" : "New Connection Request";
  const body = isQrScan
    ? `${senderName} just scanned your QR. Do you want to connect back with them?`
    : `${senderName}: \"${message.slice(0, 60)}\"`;
  const batch = db.batch();
  batch.set(requestRef, requestData);
  batch.set(db.collection("users").doc(recipientId).collection("notifications").doc(), {
    type: isQrScan ? "QR_SCAN" : "REQUEST",
    title, body, senderId, recipientId, timestamp: Date.now()
  });
  await batch.commit();
  return {ok:true, alreadyExists:false};
});

exports.acceptNeteroConnection = onCall(async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const me = request.auth.uid;
  const senderId = String(request.data?.senderId || "").trim();
  if (!senderId || senderId === me) throw new HttpsError("invalid-argument", "Invalid sender.");

  const requestRef = db.collection("users").doc(me).collection("requests").doc(senderId);
  const requestSnap = await requestRef.get();
  if (!requestSnap.exists) throw new HttpsError("not-found", "Connection request not found.");
  const req = requestSnap.data() || {};
  if (String(req.senderId || senderId) !== senderId || String(req.recipientId || me) !== me) {
    throw new HttpsError("permission-denied", "Invalid connection request.");
  }

  const [meProfileSnap, senderProfileSnap] = await Promise.all([
    db.collection("netero_profiles").doc(me).get(),
    db.collection("netero_profiles").doc(senderId).get(),
  ]);
  const meProfile = meProfileSnap.data() || {};
  const senderProfile = senderProfileSnap.data() || {};
  const now = new Date().toISOString();
  const baseA = {
    name: String(senderProfile.fullName || req.senderName || "Netero Member"),
    jobTitle: String(senderProfile.jobTitle || req.senderTitle || ""),
    company: String(senderProfile.company || req.senderCompany || ""),
    email: String(senderProfile.email || ""),
    phone: String(senderProfile.phone || ""),
    linkedin: String(senderProfile.linkedinUrl || ""),
    source: req.isQrScan ? "QR Reciprocal" : "Accepted Request",
    dateConnected: now,
    notes: String(req.message || "Connected on Netero network."),
    tags: ["MUTUAL"],
    peerUid: senderId,
  };
  const baseB = {
    name: String(meProfile.fullName || "Netero Member"),
    jobTitle: String(meProfile.jobTitle || ""),
    company: String(meProfile.company || ""),
    email: String(meProfile.email || ""),
    phone: String(meProfile.phone || ""),
    linkedin: String(meProfile.linkedinUrl || ""),
    source: req.isQrScan ? "QR Scan" : "Accepted Request",
    dateConnected: now,
    notes: String(req.message || "Connected on Netero network."),
    tags: ["MUTUAL"],
    peerUid: me,
  };
  const batch = db.batch();
  batch.set(db.collection("users").doc(me).collection("connections").doc(senderId), baseA, {merge:true});
  batch.set(db.collection("users").doc(senderId).collection("connections").doc(me), baseB, {merge:true});
  batch.delete(requestRef);
  batch.set(db.collection("users").doc(senderId).collection("notifications").doc(), {
    type:"ACCEPT", title:"Connected!", body:`${String(meProfile.fullName || "Someone")} connected back with you. You can now chat.`, senderId:me, recipientId:senderId, timestamp:Date.now()
  });
  await batch.commit();
  return {ok:true, otherUserId:senderId};
});

// Secure message delivery + the one-message-until-reply rule.
exports.sendNeteroMessage = onCall(async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const senderId = request.auth.uid;
  const recipientId = String(request.data?.recipientId || "").trim();
  const messageId = String(request.data?.messageId || "").trim();
  const text = String(request.data?.text || "");
  if (!recipientId || !messageId || !text.trim() || recipientId === senderId) throw new HttpsError("invalid-argument", "Invalid message.");

  const [senderConn, recipientConn] = await Promise.all([
    db.collection("users").doc(senderId).collection("connections").doc(recipientId).get(),
    db.collection("users").doc(recipientId).collection("connections").doc(senderId).get(),
  ]);
  const mutual = senderConn.exists && recipientConn.exists && ((senderConn.data()?.tags || []).includes("MUTUAL") || (recipientConn.data()?.tags || []).includes("MUTUAL"));
  if (!mutual) {
    const prior = await db.collection("users").doc(senderId).collection("chats")
      .where("recipientId", "==", recipientId).limit(2).get();
    if (!prior.empty) throw new HttpsError("failed-precondition", "Wait for the other person to reply before sending another message.");
  }

  const sentAt = Number(request.data?.sentAtMillis || Date.now());
  const attachmentUrl = String(request.data?.attachmentUrl || "");
  const attachmentType = String(request.data?.attachmentType || "");
  const attachmentName = String(request.data?.attachmentName || "");
  const attachmentMimeType = String(request.data?.attachmentMimeType || "");
  const senderName = String(request.data?.senderName || "Someone");
  const common = {text, sentAtMillis:sentAt, senderId, recipientId, attachmentUrl, attachmentType, attachmentName, attachmentMimeType};
  const batch = db.batch();
  batch.set(db.collection("users").doc(senderId).collection("chats").doc(messageId), {...common, contactId:recipientId, timestamp:"Just now", isFromMe:true, status:"Delivered", hiddenForUserIds:[]}, {merge:true});
  batch.set(db.collection("users").doc(recipientId).collection("chats").doc(messageId), {...common, contactId:senderId, timestamp:"Just now", isFromMe:false, status:"Delivered", hiddenForUserIds:[]}, {merge:true});
  batch.set(db.collection("users").doc(recipientId).collection("notifications").doc(), {type:"MESSAGE", title:`New Message from ${senderName}`, body:text.slice(0,80), senderId, recipientId, timestamp:Date.now()});
  await batch.commit();
  return {ok:true, mutual};
});

// Server-authoritative room membership mutations. This avoids relying on a
// client's ability to rewrite another member's room state.
exports.mutateNeteroRoom = onCall(async (request) => {
  if (!request.auth?.uid) throw new HttpsError("unauthenticated", "Authentication required.");
  const uid = request.auth.uid;
  const roomId = String(request.data?.roomId || "").trim();
  const action = String(request.data?.action || "").trim();
  if (!roomId || !action) throw new HttpsError("invalid-argument", "Room and action are required.");
  const ref = db.collection("netero_rooms").doc(roomId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Room not found.");
  const data = snap.data() || {};
  let room = {};
  try { room = JSON.parse(String(data.room_json || "{}")); } catch (_) {}
  const members = Array.isArray(room.members) ? room.members : [];
  const speakers = Array.isArray(room.speakers) ? room.speakers : [];
  const adminIds = Array.isArray(data.adminIds) ? data.adminIds : [String(data.adminId || "")];
  const isAdmin = String(data.adminId || "") === uid || adminIds.includes(uid) || members.some(m => String(m.id) === uid && m.isAdmin);
  const meProfileSnap = await db.collection("netero_profiles").doc(uid).get();
  const meProfile = meProfileSnap.data() || {};
  const member = {id:uid,name:String(meProfile.fullName || "Netero Member"),jobTitle:String(meProfile.jobTitle || "Professional"),company:String(meProfile.company || "Netero"),category:String(meProfile.industry || "General"),isConnected:false,avatarInitial:String((meProfile.fullName || "U").charAt(0).toUpperCase()),avatarBgHex:4280634367,isAdmin:false,isSpeaker:false};

  if (action === "join") {
    if (String(data.type || room.type || "PUBLIC") !== "PUBLIC" && String(data.adminId || room.adminId || "") !== uid) throw new HttpsError("failed-precondition", "This room requires admin approval.");
    if (!members.some(m => String(m.id) === uid)) members.push(member);
    room.members = members; room.memberCount = members.length; room.isJoined = false; room.isJoinRequested = false;
  } else if (action === "requestJoin") {
    if (String(data.type || room.type || "PUBLIC") === "PUBLIC") throw new HttpsError("failed-precondition", "Public rooms do not require approval.");
    const requests = Array.isArray(room.joinRequests) ? room.joinRequests : [];
    if (!requests.some(r => String(r.id) === uid)) requests.push({id:uid,name:member.name,jobTitle:member.jobTitle,avatarInitial:member.avatarInitial,avatarBgHex:member.avatarBgHex});
    room.joinRequests = requests;
    await db.collection("users").doc(String(data.adminId || room.adminId || "")).collection("notifications").add({type:"ROOM_JOIN_REQUEST",title:"Room Join Request",body:`${member.name} has requested to join ${String(room.name || "your room")}.`,senderId:uid,recipientId:String(data.adminId || room.adminId || ""),timestamp:Date.now()});
  } else if (action === "leave") {
    room.members = members.filter(m => String(m.id) !== uid); room.speakers = speakers.filter(s => String(s.id) !== uid); room.memberCount = room.members.length;
  } else if (action === "makeSpeaker" || action === "removeSpeaker" || action === "toggleAdmin" || action === "approveJoin") {
    if (!isAdmin) throw new HttpsError("permission-denied", "Only room admins can change room roles.");
    const targetId = String(request.data?.targetId || "").trim();
    if (!targetId) throw new HttpsError("invalid-argument", "Target member required.");
    if (action === "makeSpeaker") {
      const m = members.find(x => String(x.id) === targetId); if (!m) throw new HttpsError("not-found", "Member not found.");
      m.isSpeaker = true; if (!speakers.some(s => String(s.id) === targetId)) speakers.push({...m});
    } else if (action === "removeSpeaker") {
      room.speakers = speakers.filter(s => String(s.id) !== targetId); room.members = members.map(m => String(m.id) === targetId ? {...m,isSpeaker:false} : m);
    } else if (action === "toggleAdmin") {
      const targetMember = members.find(m => String(m.id) === targetId);
      if (!targetMember) throw new HttpsError("not-found", "Target must be a room member before becoming an admin.");
      if (targetId === uid && String(data.adminId || "") === uid) {
        throw new HttpsError("failed-precondition", "The room creator cannot remove their owner role.");
      }
      const nextAdmin = !Boolean(targetMember.isAdmin);
      room.members = members.map(m => String(m.id) === targetId ? {...m,isAdmin:nextAdmin} : m);
      room.speakers = speakers.map(s => String(s.id) === targetId ? {...s,isAdmin:nextAdmin} : s);
    } else {
      const pending = (room.joinRequests || []).find(x => String(x.id) === targetId); if (!pending) throw new HttpsError("not-found", "Join request not found.");
      room.joinRequests = (room.joinRequests || []).filter(x => String(x.id) !== targetId);
      if (!members.some(m => String(m.id) === targetId)) members.push({...pending,company:"Unknown",category:"Member",isConnected:false,isAdmin:false,isSpeaker:false});
      room.members = members; room.memberCount = members.length;
      await db.collection("users").doc(targetId).collection("notifications").add({type:"ROOM_JOIN_APPROVED",title:"Room Request Approved",body:`Your request to join ${String(room.name || "the room")} was approved.`,senderId:uid,recipientId:targetId,timestamp:Date.now()});
    }
  } else {
    throw new HttpsError("invalid-argument", "Unsupported room action.");
  }

  const next = {...data, room_json:JSON.stringify({...room, isJoined:false, isJoinRequested:false, discussions:[]}), memberIds:(room.members || []).map(m => m.id), memberCount:(room.members || []).length, adminIds:[String(data.adminId || room.adminId || ""), ...(room.members || []).filter(m => m.isAdmin).map(m=>m.id)].filter(Boolean)};
  await ref.set(next, {merge:true});
  return {ok:true};
});
