try {
  val existingHandler = Thread.getDefaultUncaughtExceptionHandler()
  Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
    val msg = throwable?.message ?: ""
    if (thread.name.startsWith("AWT-EventQueue") || msg.contains("ksp.com.intellij")) {
      // Suppress harmless KSP internal decompiler notification on headless AWT thread
      return@setDefaultUncaughtExceptionHandler
    }
    existingHandler?.uncaughtException(thread, throwable) ?: throwable.printStackTrace()
  }
} catch (_: Throwable) {}

pluginManagement {
  repositories {
    google {
      content {
        includeGroupByRegex("com\\.android.*")
        includeGroupByRegex("com\\.google.*")
        includeGroupByRegex("androidx.*")
      }
    }
    mavenCentral()
    gradlePluginPortal()
  }
}


dependencyResolutionManagement {
  repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
  repositories {
    google()
    mavenCentral()
  }
}

rootProject.name = "Netero"

include(":app")
