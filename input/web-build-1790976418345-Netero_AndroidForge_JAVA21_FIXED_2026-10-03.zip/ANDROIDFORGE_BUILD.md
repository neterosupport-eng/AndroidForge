# Netero AndroidForge build variant

This ZIP is prepared for AndroidForge cloud builds. It keeps the application source and runtime dependencies intact while removing optional visual-test/build plugins and the nonstandard local Gradle wrapper so AndroidForge can select its own compatible Gradle toolchain.
